build.xml is an ant build file, you have to use the graph target to 
update ExotaskIncDecMulDivGraph.java file after any change to the
IncDec_MulDiv.etk file.