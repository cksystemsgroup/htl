/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingDataParser;

/**
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLCommunicatorAnnotation extends ExotaskTimingData {

	/**
	 * The name of the XML element
	 */
	public static final String XML_NODE = "Timing";
	/**The name of the program XML attribute */
	public static final String XML_ATTRIB_PROGRAM = "program";
	/**
	 * The name of the XML attribute
	 */
	public static final String XML_ATTRIB_PERIOD = "period";
	
	//private members
	private long period;//the period of the communicator
	/**The name of the program that contains the communicator*/
	private String program;
	
	/**
	 * Create a new communicator annotation
	 * @param pPeriod the period of the communicator annotation
	 * @pProgram the name of the program that contains the communicator
	 */
	public HTLCommunicatorAnnotation(long pPeriod, String pProgram){
		period = pPeriod;
		program = pProgram;
	}
	
	/**
	 * Get the period of the communicator.
	 * @return the period of the communicator.
	 */
	public long getPeriod(){
		return period;
	}
	
	/**
	 * Set the periof of the communicator
	 * @param pPeriod
	 */
	public void setPeriod(long pPeriod){
		period = pPeriod;
	}
	
	/**
	 * Get the program that contains the communicator
	 * @return
	 */
	public String getProgram(){
		return program;
	}
	
	/**
	 * Set the program that contains the communicator.
	 * @param pProgram
	 */
	public void setProgram(String pProgram){
		program= pProgram;
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		code.append("new " + HTLCommunicatorAnnotation.class.getName() + "(" + period + "L" );
		code.append(", \"").append(program).append("\"");
		code.append(")");
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		
		xml.append("<").append(XML_NODE).append(" ");
		xml.append(XML_ATTRIB_PERIOD).append(" = '").append(ExotaskTimingDataParser.formatTime(period)).append("' ");
		xml.append(XML_ATTRIB_PROGRAM).append(" = '").append(program).append("'");
		xml.append("/>");
		
		return xml.toString();
	}

	public String toString(){
		return "Period = " + ExotaskTimingDataParser.formatTime(period) + "; Program = "+program;
	}
	
	public Object clone(){
		return new HTLCommunicatorAnnotation(period, program);
	}
	
	public boolean equals(Object o){
		if(o instanceof HTLCommunicatorAnnotation){
			HTLCommunicatorAnnotation c = (HTLCommunicatorAnnotation)o;
			return c.period==period && c.program.equalsIgnoreCase(program);
		}
		else
			return false;
	}
}
