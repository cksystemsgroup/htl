/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.timing.htl;

import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;

/**
 * The ExotaskTimingData that HTL assigns to connections when those connections have a
 *   communicator as either source or sink.  In the HTL model, no connection can directly
 *   connect two communicators.
 */
public class HTLConnectionAnnotation extends HTLAnnotation {
  /** The communicator instance that is either read or written by this connection */
  private int instance;
  
  /** Flag indicating that this connection writes a communicator, rather than reading it */ 
  private boolean writesCommunicator;
  
  /**
   * Create a new HTLConnectionAnnotation annotation
   * @param instance the instance of the communicator that this connection either reads or writes
   * @param writesCommunicator true if this connection writes the communicator rather than reading it
   * @param mode the mode to which this ExotaskSpecificationElement belongs
   */
  public HTLConnectionAnnotation(int instance, boolean writesCommunicator, HTLModeAssignment[] pModeAssignments)
  {
    super(pModeAssignments);
    this.instance = instance;
    this.writesCommunicator = writesCommunicator;
  }

  // @see com.ibm.realtime.exotasks.specification.ExotaskTimingData#generateSource()
  public String generateSource()
  {
    StringBuffer ans = new StringBuffer().append("new ").append(HTLConnectionAnnotation.class.getName());
    ans.append("(").append(instance).append(", ").append(writesCommunicator).append(", ");
    ans.append(super.generateSource()).append(")");
    return ans.toString();
  }

  /**
   * @return the instance that this connection either reads or writes
   */
  public int getInstance()
  {
    return instance;
  }
  
  /**
   * Set the instance
   * @param pInstance
   */
  public void setInstance(int pInstance){
	  instance = pInstance;
  }
  
  /**
   * @return the flag indicating whether or not this connection writes a communicator rather
   *   than reading it
   */
  public boolean writesCommunicator()
  {
    return writesCommunicator;
  }
  
  /**
   * Set if the connection writes or reads a communicator.
   * @param pWritesCommunicator
   */
  public void setWritesCommunicator(boolean pWritesCommunicator)
  {
    writesCommunicator = pWritesCommunicator;
  }
  
  /**
   * Convenience method to get the communicator end of the underlying connection
   * @param conn the underlying connection specification
   * @return the ExotaskCommunicatorSpecification at the appropriate end of the underlying
   *   connection
   */
  public ExotaskTaskSpecification getCommunicator(ExotaskConnectionSpecification conn)
  {
    return (ExotaskTaskSpecification) (writesCommunicator ? conn.getOutput() : conn.getInput());
  }

  /**
   * Convenience method to get the non-communicator (ordinary task) end of the underlying connection
   * @param conn the underlying connection specification
   * @return the ExotaskTaskSpecification at the appropriate end of the underlying
   *   connection
   */
  public ExotaskTaskSpecification getTask(ExotaskConnectionSpecification conn)
  {
    return (writesCommunicator ? conn.getInput() : conn.getOutput());
  }
  
  // @see com.ibm.realtime.exotasks.specification.ExotaskTimingData#generateXML()
  public String generateXML()
  {
    StringBuilder ans = new StringBuilder("<Timing instance='").append(instance);
    ans.append("' writesCommunicator='").append(writesCommunicator);
    ans.append("'>\n");
    
    ans.append(super.generateXML());
    
    ans.append("  </Timing>");
    return ans.toString();
  }
  
  public String toString(){
	  return "Instance="+instance + " WritesCommunicator="+writesCommunicator+
	  " " + super.toString();
  }
  
  public Object clone(){
	  return new HTLConnectionAnnotation(instance, writesCommunicator, cloneModeAssignments());
  }
}
