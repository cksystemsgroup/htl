/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import java.util.ArrayList;
import java.util.Iterator;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModuleList extends ExotaskTimingData {
	
	/**
	 * The name of the XML TAG
	 */
	public static final String XML_NODE = "ModuleList";

	//the list of modules in the program
	private ArrayList modules;
	
	/**
	 * Create a new program ExotaskGraphAnnotation
	 * @param pModules - the list of modules in the new program
	 */
	public HTLModuleList(HTLModule[] pModules){
		
		modules = new ArrayList();
		//add modules to the list of modules
		for(int i=0; i<pModules.length; i++){
			HTLModule M = pModules[i];
			if(M != null)
				modules.add(M);
		}
	}
		
	/**
	 * Get the list of modules in the program.
	 * @return the list of modules in the program
	 */
	public ArrayList getModules(){
		return modules;
	}
		
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		
		code.append("new " + HTLModuleList.class.getName() +
				"(new " + HTLModule.class.getName()+ "[]{");
		
		//add modules
		HTLModule M;
		Iterator it = modules.iterator();
		while(it.hasNext()){
			M = (HTLModule)it.next();
			code.append(M.generateSource() + ", ");
		}
		
		if(modules.size() > 0)
			 //remove the last ", "
			 code.replace(code.length()-2, code.length(), "");
		
		code.append("})");
		
		return code.toString();
	}
	
	/**
	 * Get the list of module names in the mode list.
	 * @return
	 */
	public String[] getModuleNames(){
		String[] names = new String[modules.size()];
		
		for(int i=0; i < modules.size(); i++)
			names[i] = ((HTLModule)modules.get(i)).getName();
		
		return names;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		
		xml.append("  <"+XML_NODE+">\n");
		
		//add modules
		HTLModule M;
		Iterator it = modules.iterator();
		while(it.hasNext()){
			M = (HTLModule)it.next();
			xml.append(M.generateXML() + "\n");
		}
		
		xml.append("  </"+XML_NODE+">");
		
		return xml.toString();
	}
	
	/**
	 * String representation of the class.
	 */
	public String toString(){
		StringBuffer buff = new StringBuffer();
		for(int i=0; i<modules.size(); i++){
			HTLModule m = (HTLModule)modules.get(i);
			buff.append(m.toString());
			
			if(i<(modules.size()-1))
				buff.append(" ");
		}
		
		return buff.toString();
	}

	public Object clone(){
		HTLModule[] modules = new HTLModule[this.modules.size()];
		for(int i=0; i<modules.length; i++)
			modules[i] = (HTLModule)((HTLModule)this.modules.get(i)).clone();
		
		return new HTLModuleList(modules);
	}
}
