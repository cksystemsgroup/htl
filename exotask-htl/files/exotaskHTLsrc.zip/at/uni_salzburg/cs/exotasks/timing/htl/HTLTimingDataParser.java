/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.timing.htl;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ibm.realtime.exotasks.specification.ExotaskValidationException;
import com.ibm.realtime.exotasks.timing.ExotaskGlobalTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingDataParser;

/**
 * Provide the XML parsing adjunct for exotask graphs translated from HTL or conforming to HTL
 * semantics.  Augments the XML grammar as follows (informal notation).
 *
 * <p><b>&lt;TimingProvider kind='HTL'
 * parser='at.uni_salzburg.cs.exotasks.timing.htl.HTLTimingDataParser'/&gt</b> indicates the use
 * of this timing package.
 * 
 * <p>All <b>&lt;Timing/&gt;</b> timing elements have an optional <b>mode=</b> attribute giving the
 * name of the mode to which the graph specification element belongs.  If this is omitted, the
 * null mode name is used, which works as long as there is only one mode in the graph.
 *
 * <p>For <b>&lt;Task&gt</b>, <b>&lt;Communicator&gt</b>, <b>GraphInput</b> and <b>GraphOutput</b>
 * elements, <b>&lt;Timing period='...' mode='...'/&gt</b> provides the period of 
 * execution.  The period attribute may not be omitted, nor may the annotation as a whole.
 * 
 * <p>For <b>&lt;Predicate&gt</b> elements, <b>&lt;Timing mode='...' targetMode='...'/&gt</b> 
 * indicates the mode that this predicate switches to if true.  The <b>mode</b> attribute is not
 * optional in this case, since the graph necessarily has multiple modes.
 *
 * <p>For <b>&lt;Connection&gt</b> elements, <b>&lt;Timing instance='...'
 *   writesCommunicator='...' mode='...'/&gt</b> indicates which communicator instance is intended 
 *   when a connectionf either writes or reads a communicator, and also indicates whether the 
 *   communicator is read or written.  The timing annotation should be absent on connections that
 *   directly connect ordinary tasks.  If writesCommunicator is omitted, it defaults to 'false'; 
 *   note that this has only a 50% chance of being correct.
 */
public class HTLTimingDataParser extends ExotaskTimingDataParser
{	
  // @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduleDataParser#parseGraphAnnotation(org.w3c.dom.Element)
  public ExotaskGlobalTimingData parseGraphAnnotation(Element element)
      throws ExotaskValidationException
  {
	  
	  if(element.getNodeName().equals(HTLExotaskGraphAnnotation.XML_NODE))
	  {
		  String slowDownStr = element.getAttribute(HTLExotaskGraphAnnotation.XML_ATTRIB_SLOWDOWN);
		  int slowDown = 1;
		  try{
			  slowDown = Integer.parseInt(slowDownStr);
		  }
		  catch(Exception e){}
		  
		  //parse programs
		  HTLProgramList programs;
		  NodeList nodes = element.getElementsByTagName(HTLProgramList.XML_NODE);
		  if(nodes.getLength() != 1){
			  throw new ExotaskValidationException("None or more then one list of programs is declared!");
		  }
		  else{
			  programs = parseHTLPrograms((Element)nodes.item(0));
		  }
		  
		  //parese modules
		  HTLModuleList modules;
		  //parse modules
		  nodes = element.getElementsByTagName(HTLModuleList.XML_NODE);
		  if(nodes.getLength() != 1){
			  throw new ExotaskValidationException("None or more then one list of modules is declared!");
		  }
		  else{
			  modules = parseHTLModules((Element)nodes.item(0));
		  }
		  
		  //parse modes
		  HTLModeList modes;
		  nodes = element.getElementsByTagName(HTLModeList.XML_NODE);
		  if(nodes.getLength() != 1){
			  throw new ExotaskValidationException("None or more then one list of modes is declared!");
		  }
		  else{
			  modes = parseHTLModes((Element)nodes.item(0));
		  }
		  
		  return new HTLExotaskGraphAnnotation(programs, modules, modes, slowDown);
	  }
	  else
		  throw new ExotaskValidationException("Invalid timing data. " + HTLModuleList.XML_NODE + " element "+
				  "was expected.");
  }
  
  /**
   * Parse an HTL program list element
   * @param element
   * @return
   */
  private HTLProgramList parseHTLPrograms(Element element) throws ExotaskValidationException{
	  NodeList programNodes = element.getElementsByTagName(HTLProgram.XML_NODE);
	  HTLProgram[] programs = new HTLProgram[programNodes.getLength()];
	  
	  for(int i=0; i<programs.length; i++){
		  programs[i] = parseProgram((Element)programNodes.item(i));
	  }
	  
	  return new HTLProgramList(programs);
  }
	/**
	 * Parse a program node
	 * @param node
	 * @return
	 */
	private HTLProgram parseProgram(Element node)
		throws ExotaskValidationException{
		
		//get attributes
		String name = node.getAttribute(HTLProgram.XML_ATTRIB_NAME);
		
		if(name==null || name.equals("")){
		     throw new ExotaskValidationException("No name was specified for program.");
		}
		
		return new HTLProgram(name);
	}
  
  /**
   * Parse an HTL modules list element
   * @param element
   * @return
   */
  private HTLModuleList parseHTLModules(Element element) throws ExotaskValidationException{
	  NodeList moduleNodes = element.getElementsByTagName(HTLModule.XML_NODE);
	  HTLModule[] modules = new HTLModule[moduleNodes.getLength()];
	  
	  for(int i=0; i<modules.length; i++){
		  modules[i] = parseModule((Element)moduleNodes.item(i));
	  }
	  
	  return new HTLModuleList(modules);
  }
	/**
	 * Parse a module node
	 * @param node
	 * @return
	 */
	private HTLModule parseModule(Element node)
		throws ExotaskValidationException{
		
		//get attributes
		String name = node.getAttribute(HTLModule.XML_ATTRIB_NAME);
		
		if(name==null || name.equals("")){
		     throw new ExotaskValidationException("No name was specified for module.");
		}
			
		String start = node.getAttribute(HTLModule.XML_ATTRIB_START);
		
		if(start==null || start.equals("")){
		     throw new ExotaskValidationException("No start mode was specified for module "+name);
		}
		
		String program = node.getAttribute(HTLModule.XML_ATTRIB_PROGRAM);
		if(program==null || program.equals("")){
			program = "";
		}
		
		return new HTLModule(name, start, program);
	}
	
	/**
	 * Parse the list of modes
	 * @param node
	 * @return
	 */
	private HTLModeList parseHTLModes(Element element) throws ExotaskValidationException
	{
		NodeList modeNodes = element.getElementsByTagName(HTLMode.XML_NODE);
		HTLMode[] modes = new HTLMode[modeNodes.getLength()];
	  
		for(int i=0; i<modes.length; i++){
			modes[i] = parseMode((Element)modeNodes.item(i));
		}
	  
		return new HTLModeList(modes);
	}
	
	/**
	 * Parse a mode.
	 * @param node
	 * @return
	 */
	private HTLMode parseMode(Element node)
		throws ExotaskValidationException{
		//get attributes
		String name = node.getAttribute(HTLMode.XML_ATTRIB_NAME);
				
		if(name==null || name.equals("")){
		     throw new ExotaskValidationException("No name was specified for mode.");
		}
				
		long period = 0;
		try{
			String strPeriod = node.getAttribute(HTLMode.XML_ATTRIB_PERIOD);
			
			if(strPeriod==null || strPeriod.equals("")){
				throw new ExotaskValidationException("No period was specified for mode " +name);
			}
			period = parseTime(strPeriod);
		}
		catch(NumberFormatException e){
			throw new ExotaskValidationException("Invalid period format on " +name);
		}
		
		String module = node.getAttribute(HTLMode.XML_ATTRIB_MODULE);
		
		if(module==null || module.equals("")){
		     throw new ExotaskValidationException("No module was specified for mode "+name+".");
		}
		
		String refine = node.getAttribute(HTLMode.XML_ATTRIB_REFINE);
		if(refine==null || refine.equals("")){
			refine = "";
		}
		
		return new HTLMode(name, period, module, refine);
	}

  // @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduleDataParser#parseTaskAnnotation(org.w3c.dom.Element)
  public ExotaskTimingData parseTaskAnnotation(Element element, String locus)
      throws ExotaskValidationException
  {
	//get the mode
    String mode = element.getAttribute("mode");
    if (mode == null || mode.length() == 0) {
      mode = "";
    }
    
    //get the target mode
    String targetMode = element.getAttribute("targetMode");
    if (targetMode != null && targetMode.length() == 0) {
      targetMode = null;
    }
    
    NodeList nodes = element.getElementsByTagName(HTLModeAssignment.XML_NODE);
    HTLModeAssignment[] modeAssignments = new HTLModeAssignment[nodes.getLength()];
    
    for(int i=0; i<modeAssignments.length; i++){
  	  modeAssignments[i] = parseInvocation((Element)nodes.item(i), locus);
    }
    
    //get the period
    String periodStr = element.getAttribute(HTLCommunicatorAnnotation.XML_ATTRIB_PERIOD);
    if(periodStr == null)
    	periodStr = "";
    
    //get the instance
    String instanceStr = element.getAttribute("instance");
    Element parent = (Element)element.getParentNode(); 
    if (parent != null && 
    		"Connection".toUpperCase().equals(parent.getNodeName().toUpperCase())) {
    	//parse connection
    	int instance = -1;
    
    	try {
    		instance = Integer.parseInt(instanceStr);
    	} catch (NumberFormatException e) {
    		
    	}
    	
    	/* The instances may also be too large or in conflict with uses elsewhere but we can't check
         *  for that here.  The check can be made prior to scheduling in the scheduler, which necessarily
         *  knows the timing model employed.
         */
        return new HTLConnectionAnnotation(instance, 
            "true".equals(element.getAttribute("writesCommunicator")), modeAssignments);
    }
    else if (targetMode != null) {
    	//parse a mode switch
      return new HTLModeSwitch(modeAssignments, targetMode);
    } else if(!periodStr.equals("")){
    	//this is a communicator annotation
    	long period = parseTime(periodStr);
    	if(period == 0){
    		//throw new ExotaskValidationException("["+locus+"]"+"Zero or no period for communicator.");
    	}

    	String program = element.getAttribute(HTLCommunicatorAnnotation.XML_ATTRIB_PROGRAM);
    	if(program == null)
    		program = "";
    	
    	return new HTLCommunicatorAnnotation(period, program);
    }
    else{   	
    	String parentTask = element.getAttribute(HTLTaskAnnotation.XML_ATTRIB_PARENT);
    	if(parentTask == null)
    		parentTask = "";
      //this is a Task annotation    	  
      return new HTLTaskAnnotation(modeAssignments, 
    		  "true".equals(element.getAttribute(HTLTaskAnnotation.XML_ATTRIB_IS_ABSTRACT)), parentTask);
    }
  }
  
  public HTLModeAssignment parseInvocation(Element element, String locus) throws ExotaskValidationException{
	  	  
	  String mode = element.getAttribute(HTLModeAssignment.XML_ATTRIB_MODE);
	  if(mode == null || mode.equals("")){
		  throw new ExotaskValidationException("No mode specified for invocation at "+locus);
	  }
	  
	  return new HTLModeAssignment(mode);
  }

  // @see com.ibm.realtime.exotasks.tools.ExotaskTimingDataParser#parseConnectionAnnotation(org.w3c.dom.Element)
  public ExotaskTimingData parseConnectionAnnotation(Element element, String locus)
      throws ExotaskValidationException
  {
    return parseTaskAnnotation(element, locus);
  }
}
