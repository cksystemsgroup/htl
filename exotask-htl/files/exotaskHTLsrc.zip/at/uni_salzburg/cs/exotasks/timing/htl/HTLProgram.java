/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * This class represents an HTL program.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLProgram extends ExotaskTimingData {
	
	/**The program XML tag.*/
	public static final String XML_NODE = "Program";
	/**The name of the name attribute.*/
	public static final String XML_ATTRIB_NAME = "name";
	
	/**Name of the program*/
	private String name;
	
	/**
	 * Create a new HTL program.
	 * @param pName the name of the HTL program
	 */
	public HTLProgram(String pName){
		this.name = pName;
	}
	
	/**
	 * Get the name of the program.
	 * @return the name of the program
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * Set the name of the program
	 * @param pName the new name of the program
	 */
	public void setName(String pName){
		name = pName;
	}

	/**
	 * Generate source.
	 * @return generated source
	 */
	public String generateSource() {
		StringBuffer buffer = new StringBuffer();
		
		buffer.append("new ").append(HTLProgram.class.getName());
		buffer.append("(\"").append(name).append("\")");
		
		return buffer.toString();
	}

	/**
	 * Generate XML.
	 * @return generated XML
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		xml.append("    <").append(XML_NODE).append(" ");
		xml.append(XML_ATTRIB_NAME).append(" = '").append(name).append("'");
		xml.append("/>");
		return xml.toString();
	}
	
	public String toString(){
		return name;
	}
	
	public Object clone(){
		return new HTLProgram(name);
	}
}
