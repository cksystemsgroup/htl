/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import java.util.ArrayList;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModeList extends ExotaskTimingData {
	
	/**
	 * The name of the mode list XML element
	 */
	public static final String XML_NODE = "ModeList";
	
	/*private memebers*/
	private ArrayList modes; //the list of modes
	
	/**
	 * Create a new HTLModeList.
	 * @param pModes the modes that are in the list.
	 */
	public HTLModeList(HTLMode[] pModes){
		modes = new ArrayList(pModes.length);
		for(int i=0; i<pModes.length; i++)
			if(pModes[i]!=null)
				modes.add(pModes[i]);
	}
	
	/**
	 * Get the list of mode names in the mode list.
	 * @return
	 */
	public String[] getModeNames(){
		String[] names = new String[modes.size()];
		
		for(int i=0; i < modes.size(); i++)
			names[i] = ((HTLMode)modes.get(i)).getName();
		
		return names;
	}
	
	/**
	 * Get the modes in the list.
	 * @return the modes in the list.
	 */
	public ArrayList getModes(){
		return modes;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		code.append("new "+HTLModeList.class.getName()+"(");
		
		//create the list of modes
		code.append("new " + HTLMode.class.getName() + "[]{");
		for(int i=0; i<modes.size(); i++){
			HTLMode m = (HTLMode)modes.get(i);
			code.append(m.generateSource());
			if(i<(modes.size()-1)){
				code.append(", ");
			}
		}
		code.append("}");
		code.append(")");
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		xml.append("  <"+XML_NODE+">\n");
		
		//generate XML for modes
		for(int i=0; i<modes.size(); i++){
			HTLMode m = (HTLMode)modes.get(i);
			xml.append(m.generateXML());
			xml.append("\n");
		}
		
		xml.append("  </"+XML_NODE+">");
		return xml.toString();
	}
	
	/**
	 * String representation of the class.
	 */
	public String toString(){
		StringBuffer buff = new StringBuffer();
		for(int i=0; i<modes.size(); i++){
			HTLMode m = (HTLMode)modes.get(i);
			buff.append(m.toString());
			
			if(i<(modes.size()-1))
				buff.append(" ");
		}
		
		return buff.toString();
	}

	public Object clone(){
		HTLMode[] modes = new HTLMode[this.modes.size()];
		
		for(int i=0; i<modes.length; i++)
			modes[i] = (HTLMode)((HTLMode)this.modes.get(i)).clone();
		
		return new HTLModeList(modes);
	}
}
