/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * This class represents a module.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 * 
 *  
 **/
public class HTLModule extends ExotaskTimingData {

	/**
	 * Module XML TAG
	 */
	public static final String XML_NODE = "Module";
	public static final String XML_ATTRIB_NAME = "name";
	public static final String XML_ATTRIB_START = "start";
	public static final String XML_ATTRIB_PROGRAM = "program";
	
	//The name of the module
	private String name;
	//The name of the start mode.
	private String startMode;
	//Program in which the module is defined
	private String program;
	
	/**
	 * Create a new module
	 * @param pName the name of the module
	 * @param pStartMode the name of the start mode of the module
	 * @param pProgram the program in which the modules is defined 
	 */
	public HTLModule(String pName, String pStartMode, String pProgram){
		name = pName;
		startMode = pStartMode;
		program = pProgram;
	}
	
	/**
	 * Get the name of the module.
	 * @return the name of the module
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * Get the name of the start mode.
	 * @return the name of the start mode
	 */
	public String getStartMode(){
		return startMode;
	}
		
	/**
	 * Get the program in which the module is defined
	 * @return program name
	 */
	public String getProgram(){
		return program;
	}
	
	/**
	 * Set the name of the program in which the module is defined
	 * @param pProgram
	 */
	public void setProgram(String pProgram){
		program = pProgram;
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		code.append("new "+HTLModule.class.getName()+"(\""+name+"\", \""+
				startMode+"\", \""+program+"\")");
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		
		StringBuffer xml = new StringBuffer();
		
		xml.append("    <"+XML_NODE+" "+XML_ATTRIB_NAME+" = '"+name+"' "+
				XML_ATTRIB_START+" = '"+startMode+"' "+
				XML_ATTRIB_PROGRAM + " = '"+program+"'/>");
		
		return xml.toString();
	}

	public String toString(){
		return "{"+name+","+startMode+", "+program+"}";
	}
	
	public Object clone(){
		return new HTLModule(name, startMode, program);
	}
}
