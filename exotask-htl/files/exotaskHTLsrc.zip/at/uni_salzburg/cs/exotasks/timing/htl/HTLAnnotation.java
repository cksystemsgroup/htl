/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import java.util.ArrayList;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * The base class for all <Timing> elements in the HTL timing grammar.  Records a mode
 *   membership
 */
public abstract class HTLAnnotation extends ExotaskTimingData
{
	//	private memebers
	private ArrayList modeAssignments;

  /**
   * Make a new HTLAnnotation
   * @param mode the mode to which this ExotaskSpecificationElement belongs
   */
  HTLAnnotation(HTLModeAssignment[] pModeAssignments)
  {
	  modeAssignments = new ArrayList(pModeAssignments.length);
      for(int i=0; i<pModeAssignments.length; i++){
    	  modeAssignments.add(pModeAssignments[i]);
      }
  }

  /**
	 * Get the modeAssignments in the list.
	 * @return the modeAssignments in the list
	 */
	public ArrayList getModes(){
		return modeAssignments;
	}
	
	/**
	 * Get the names of the modes assigned to the task.
	 * @return
	 */
	public String[] getModeNames(){
		String[] modeNames = new String[modeAssignments.size()];
		
		for(int i=0; i<modeNames.length; i++)
			modeNames[i] = ((HTLModeAssignment)modeAssignments.get(i)).getMode();
		
		return modeNames;
	}
	
	/**
	 * Set mode assignments.
	 * @param pModeNames
	 */
	public void setModeNames(String[] pModeNames){
		modeAssignments.clear();
		for(int i=0; i<pModeNames.length; i++)
			modeAssignments.add(new HTLModeAssignment(pModeNames[i]));
	}
	
	/**
	 * Test to see if the element is assigned to the specified mode.
	 * @param pMode
	 * @return
	 */
	public boolean isAssignedTo(String pMode){
		for(int i=0; i<modeAssignments.size(); i++){
			if(((HTLModeAssignment)modeAssignments.get(i)).getMode().equals(pMode)){
				return true;
			}
		}
		
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		
		code.append("new ").append(HTLModeAssignment.class.getName()).append("[]{");
		
		for(int i=0; i<modeAssignments.size(); i++){
			HTLModeAssignment inv = (HTLModeAssignment)modeAssignments.get(i);
			code.append(inv.generateSource());
			if(i < modeAssignments.size()-1){
				code.append(", ");
			}
		}
		
		code.append("}");
		
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		
		for(int i=0; i<modeAssignments.size(); i++){
			HTLModeAssignment inv = (HTLModeAssignment)modeAssignments.get(i);
			xml.append(inv.generateXML()).append("\n");
		}
		
		return xml.toString();
	}
	
	public String toString(){
		StringBuffer buff = new StringBuffer();
		
		buff.append("Assigned to: ");
		for(int i=0; i<modeAssignments.size(); i++){
			buff.append(((HTLModeAssignment)modeAssignments.get(i)).getMode());
			if(i<(modeAssignments.size()-1)){
				buff.append(", ");
			}
		}
		
		return buff.toString();
	}
	
	/**
	 * Clone the list of mode assignments.
	 * @return
	 */
	public HTLModeAssignment[] cloneModeAssignments(){
		HTLModeAssignment[] modeAssignments = new HTLModeAssignment[this.modeAssignments.size()];
		for(int i=0; i<modeAssignments.length; i++)
			modeAssignments[i] = (HTLModeAssignment)((HTLModeAssignment)this.modeAssignments.get(i)).clone();
		
		return modeAssignments;
	}
}
