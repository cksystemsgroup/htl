/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.timing.htl;


/**
 * The ExotaskTimingData that HTL assigns to tasks, including communicators.  In an
 *   ExotaskGraphSpecification corresponding to an HTL mode, all tasks will inherit the mode's 
 *   period.  When the ExotaskGraphSpecification represents multiple
 *   HTL modes composed in parallel, more than one period may be present.
 */
public class HTLTaskAnnotation extends HTLAnnotation{
  
  public static final String XML_NODE="Timing";
  public static final String XML_ATTRIB_IS_ABSTRACT = "isAbstract";
  public static final String XML_ATTRIB_PARENT = "parent";
	
  private boolean isAbstract;
  private String parentTask;
	
  /**
   * Create a new HTLTaskAnnotation
   * @param pModeAssignments
   * @param pIsAbstract
   */
  public HTLTaskAnnotation(HTLModeAssignment[] pModeAssignments, boolean pIsAbstract, String pParentTask){
    super(pModeAssignments);
    isAbstract = pIsAbstract;
    parentTask = pParentTask;
  }
	
	/**
	 * Get if task is abstract.
	 * @return true if task is abstract
	 */
	public boolean IsAbstract(){
		return isAbstract;
	}
	
	/**
	 * Set the abstract property of a task.
	 * @param pIsAbstract true if the task is abstract
	 */
	public void setAbstract(boolean pIsAbstract){
		isAbstract = pIsAbstract;
	}
	
	/**
	 * Get the name of the parent task.
	 * @return
	 */
	public String getParentTask(){
		return parentTask;
	}
	
	/**
	 * Set the name of the parent task.
	 */
	public void setParentTask(String pParentTask){
		parentTask = pParentTask;
	}
	

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		
		code.append("new ").append(HTLTaskAnnotation.class.getName()).append("(");
		code.append(super.generateSource());
		code.append(", ").append(isAbstract);
		code.append(", \"").append(parentTask).append("\"");
		code.append(")");
		
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		xml.append("<").append(XML_NODE);
		xml.append(" ");
		xml.append(XML_ATTRIB_IS_ABSTRACT).append(" = '").append(isAbstract).append("'");
		xml.append(" ");
		xml.append(XML_ATTRIB_PARENT).append(" = '").append(parentTask).append("'");
		xml.append(">\n");
		xml.append(super.generateXML());
		xml.append("  </").append(XML_NODE).append(">");
		return xml.toString();
	}
	
	public String toString(){
		StringBuffer buff = new StringBuffer();
		if(isAbstract)
			buff.append("Abstract ");
		if(!parentTask.equals("")){
			buff.append("ParentTask: ").append(parentTask).append(" ");
		}
		buff.append(super.toString());
		
		return buff.toString();
	}
	
	public Object clone(){
		return new HTLTaskAnnotation(cloneModeAssignments(), isAbstract, parentTask);
	}
}
