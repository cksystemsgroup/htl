/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * 
 * This class represents a mode assigment. 
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModeAssignment extends ExotaskTimingData {

	/**
	 * The name of the XML element.
	 */
	public static final String XML_NODE = "ModeAssignment";
	/**
	 * The name of the mode attribute.
	 */
	public static final String XML_ATTRIB_MODE = "mode";
	
	private String mode; //the name of the mode in which the task is invoked
	
	/**
	 * Create a new invocation.
	 * @param pMode the name of the mode in which the task is invoked.
	 */
	public HTLModeAssignment(String pMode){
		mode = pMode;
	}
	
	/**
	 * Get the mode in which the task will be invoked.
	 * @return the name of the mode in which the task is invoked.
	 */
	public String getMode(){
		return mode;
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		code.append("new ").append(HTLModeAssignment.class.getName()).append("(");
		code.append("\"").append(mode).append("\"").append(")");
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		
		xml.append("    <").append(XML_NODE).append(" ");
		xml.append(XML_ATTRIB_MODE).append(" = '").append(mode).append("'/>");
		
		return xml.toString();
	}
	
	public String toString(){
		return mode;
	}

	public Object clone(){
		return new HTLModeAssignment(mode);
	}
}
