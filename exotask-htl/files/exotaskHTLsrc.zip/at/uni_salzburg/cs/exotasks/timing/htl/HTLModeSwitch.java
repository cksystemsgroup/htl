/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.timing.htl;

/**
 * Annotation for an ExotaskPredicateSpecification labelling the predicate as a mode switch
 *   and providing the target mode
 */
public class HTLModeSwitch extends HTLAnnotation
{
  /** The mode to which this mode switch switches */
  private String targetMode;

  /**
   * Make a new mode switch annotation
   * @param thisMode the mode that this predicate is in
   * @param targetMode the mode that this mode switch switches to
   */
  public HTLModeSwitch(HTLModeAssignment[] pModeAssignments, String targetMode)
  {
    super(pModeAssignments);
    this.targetMode = targetMode;
  }

  // @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
  public String generateSource()
  {
    StringBuffer ans = new StringBuffer().append("new ").append(HTLModeSwitch.class.getName());
    ans.append("(").append(super.generateSource()).append(", ");
    ans.append("\"").append(getTargetMode()).append("\"");
    return ans.append(")").toString();
  }

  // @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
  public String generateXML()
  {
    StringBuffer ans = new StringBuffer("<Timing");
    ans.append(" targetMode='").append(getTargetMode()).append("'>\n");
    ans.append(super.generateXML());
    ans.append("  </Timing>");
    return ans.toString();
  }

  /**
   * Get the target mode
   * @return the target mode
   */
  public String getTargetMode()
  {
    return targetMode;
  }

  /**
   * Set target mode.
   * @return
   */
  public void setTargetMode(String pTarget)
  {
    targetMode = pTarget;
  }
  
  public String toString(){
	  return super.toString()+"; Target Mode="+targetMode;
  }
  
  public Object clone(){
	  return new HTLModeSwitch(cloneModeAssignments(), targetMode);
  }
}
