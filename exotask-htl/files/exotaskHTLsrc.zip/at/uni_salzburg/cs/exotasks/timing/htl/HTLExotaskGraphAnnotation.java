/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.ibm.realtime.exotasks.specification.ExotaskCommunicatorSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskPredicateSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;
import com.ibm.realtime.exotasks.timing.ExotaskGlobalTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * For the moment only the single program is implemented.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLExotaskGraphAnnotation extends ExotaskGlobalTimingData {

	/**
	 * The name of the XML TAG
	 */
	public static final String XML_NODE = "TimingProvider";
	/**
	 * The name of the attribute that represents the kind of grammer
	 */
	public static final String XML_ATTRIB_KIND = "kind";
	/**
	 * The attribute that specifies that the HTLTimingParser should be used
	 */
	public static final String XML_ATTRIB_PARSER = "parser";
	/**
	 * The attribute that specifies the slow down factor
	 */
	public static final String XML_ATTRIB_SLOWDOWN = "slowdownFactor";
	
	//private members
	private HTLModuleList modules;
	private HTLModeList modes;
	private HTLProgramList programs;
	private int slowdownFactor;
	
	/**
	 * Create a new graph annotation.
	 * @param pModules the list of modules in the HTL program.
	 * @param modes the list of modes in the HTL program.
	 */
	public HTLExotaskGraphAnnotation(HTLProgramList pPrograms, HTLModuleList pModules, HTLModeList pModes, int slowdownFactor){
		modules = pModules;
		modes = pModes;
		programs = pPrograms;
		this.slowdownFactor = slowdownFactor;
	}
	
	/**
	 * Get the list of programs.
	 * @return the list of modules.
	 */
	public HTLProgramList getHTLProgramList(){
		return programs;
	}
	
	/**
	 * Get the list of modules.
	 * @return the list of modules.
	 */
	public HTLModuleList getHTLModuleList(){
		return modules;
	}
	
	/**
	 * Get the list of modes.
	 * @return the list of modes.
	 */
	public HTLModeList getHTLModeList(){
		return modes;
	}
	
	public int getSlowDownFactor(){
		return slowdownFactor;
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		
		code.append("new " + HTLExotaskGraphAnnotation.class.getName() + "(");
		code.append(programs.generateSource());
		code.append(", ");
		code.append(modules.generateSource());
		code.append(", ").append(modes.generateSource());
		code.append(", ").append(slowdownFactor);
		code.append(")");
		
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		
		xml.append("<"+XML_NODE);
		xml.append(" " + XML_ATTRIB_KIND + " = 'htl'");
		xml.append(" " + XML_ATTRIB_PARSER + " = '");
		xml.append(HTLTimingDataParser.class.getName() + "'");
		xml.append(" " + XML_ATTRIB_SLOWDOWN + " = '"+slowdownFactor+"'");
		if(getGraphics()!=null)
			xml.append(" graphics='"+getGraphics()+"'");
		xml.append(">\n");
		
		//add programs
		xml.append(programs.generateXML());

		xml.append("\n");

		
		//add modules
		xml.append(modules.generateXML());

		xml.append("\n");
		
		//add modes
		xml.append(modes.generateXML());
		xml.append("\n");
		
		xml.append("</"+XML_NODE+">");
		
		return xml.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskGlobalTimingData#completeComposition(com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification, com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification, com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification)
	 */
	public void completeComposition(ExotaskGraphSpecification composed, ExotaskGraphSpecification one, ExotaskGraphSpecification two) throws ExotaskValidationException
	{
		//combine the timings of the two graphs
		Map programs = getPrograms(one, two);
		Map modules = getModules(one, two, programs);
		Map modes = getModes(one, two, programs, modules);
		Map commAnnot = getCommunicatorAnnotations(one, two, modes);
		Map connAnnot = getConnectionAnnotations(one, two, modes);
		Map predicateAnnot = getPredicateAnnotations(one, two, modes);
		Map taskAnnot = getTaskAnnotations(one, two, modes);
		
		//update the timing of the new graph
		updateComposedGlobalTiming(programs, modules, modes, composed, ((HTLExotaskGraphAnnotation)one.getTimingData()).slowdownFactor);
		updateConnectionAnnotations(connAnnot, composed);
		updateTaskAnnotations(taskAnnot, commAnnot, predicateAnnot, composed);
	}
	
	/**
	 * Set the timing for the combined connections.
	 * @param connectionAnnotations
	 * @param composed
	 */
	private void updateConnectionAnnotations(Map connectionAnnotations, ExotaskGraphSpecification composed){
		Set connections = composed.getConnections();
		Iterator it = connections.iterator();
		while(it.hasNext()){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			c.setTimingData((ExotaskTimingData)connectionAnnotations.get(c.getName()));
		}
	}

	/**
	 * Set the timing for all the tasks.
	 * @param taskAnot
	 * @param commAnnot
	 * @param predicateAnnot
	 * @param composed
	 */
	private void updateTaskAnnotations(Map taskAnnot, Map commAnnot, Map predicateAnnot, ExotaskGraphSpecification composed){
		Set tasks = composed.getTasks();
		Iterator it = tasks.iterator();
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			
			if(t instanceof ExotaskCommunicatorSpecification){
				t.setTimingData((HTLCommunicatorAnnotation)commAnnot.get(t.getName()));
			}
			else if(t instanceof ExotaskPredicateSpecification){
				t.setTimingData((HTLModeSwitch)predicateAnnot.get(t.getName()));
			}
			else{
				t.setTimingData((HTLTaskAnnotation)taskAnnot.get(t.getName()));
			}
		}
	} 
	
	/**
	 * Set the composed global timing to the composed graph.
	 * @param programs
	 * @param module
	 * @param modes
	 * @param composed
	 */
	private void updateComposedGlobalTiming(Map programs, Map modules, Map modes, ExotaskGraphSpecification composed, int slowdownFactor){
		//create the composed HTL exotask global timing annotation
		
		//create the program list
		HTLProgram[] progArray = new HTLProgram[programs.size()];
		Iterator it = programs.values().iterator();
		int i=0;
		while(it.hasNext()){
			progArray[i++] = (HTLProgram)it.next();
		}
		HTLProgramList progList = new HTLProgramList(progArray);
		
		//create the module list
		HTLModule[] moduleArray = new HTLModule[modules.size()];
		it = modules.values().iterator();
		i=0;
		while(it.hasNext()){
			moduleArray[i++] = (HTLModule)it.next();
		}
		HTLModuleList moduleList = new HTLModuleList(moduleArray);
		
		//create the mode list
		HTLMode[] modeArray = new HTLMode[modes.size()];
		it = modes.values().iterator();
		i=0;
		while(it.hasNext()){
			modeArray[i++] = (HTLMode)it.next();
		}
		HTLModeList modeList = new HTLModeList(modeArray);
		
		HTLExotaskGraphAnnotation graphAnnot = new HTLExotaskGraphAnnotation(progList, moduleList, modeList, slowdownFactor);
		composed.setTimingData(graphAnnot);
	}
	
	/**
	 * Get the programs in the two graphs
	 * @param g1
	 * @param g2
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getPrograms(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2) throws ExotaskValidationException{
		Map programs = new HashMap();
	
		//get programs from the first graph
		HTLExotaskGraphAnnotation annot = (HTLExotaskGraphAnnotation)g1.getTimingData();
		ArrayList progList = annot.getHTLProgramList().getPrograms();
		Iterator it = progList.iterator();
		//update the list of programs
		while(it.hasNext()){
			HTLProgram prog = (HTLProgram)it.next();
			if(!programs.containsKey(prog.getName())){
				programs.put(prog.getName(), prog.clone());
			}
		}
		
		annot = (HTLExotaskGraphAnnotation)g2.getTimingData();
		progList = annot.getHTLProgramList().getPrograms();
		it = progList.iterator();
		//update the list of programs
		while(it.hasNext()){
			HTLProgram prog = (HTLProgram)it.next();
			if(!programs.containsKey(prog.getName())){
				programs.put(prog.getName(), prog.clone());
			}
		}
		
		return programs;
	}
	
	/**
	 * Get the modules.
	 * @param g1
	 * @param g2
	 * @param programs
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getModules(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2, Map programs) 
			throws ExotaskValidationException{
		Map modules = new HashMap();
		
		//get modules from the first graph
		HTLExotaskGraphAnnotation annot = (HTLExotaskGraphAnnotation)g1.getTimingData();
		ArrayList moduleList = annot.getHTLModuleList().getModules();
		Iterator it = moduleList.iterator();
		//update the list of modules
		while(it.hasNext()){
			HTLModule M = (HTLModule)it.next();
			if(!modules.containsKey(M.getName())){
				modules.put(M.getName(), M.clone());
			}
		}
		
		annot = (HTLExotaskGraphAnnotation)g2.getTimingData();
		moduleList = annot.getHTLModuleList().getModules();
		it = moduleList.iterator();
		//update the list of modules
		while(it.hasNext()){
			HTLModule M = (HTLModule)it.next();
			if(!modules.containsKey(M.getName())){
				modules.put(M.getName(), M.clone());
			}
		}
		
		return modules;
	}
	
	/**
	 * Get the modes
	 * @param g1
	 * @param g2
	 * @param programs
	 * @param modules
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getModes(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2, Map programs, Map modules) 
	throws ExotaskValidationException{
		Map modes = new HashMap();
		
		//get modes from the first graph
		HTLExotaskGraphAnnotation annot = (HTLExotaskGraphAnnotation)g1.getTimingData();
		ArrayList modeList = annot.getHTLModeList().getModes();
		Iterator it = modeList.iterator();
		//update the list of modules
		while(it.hasNext()){
			HTLMode m = (HTLMode)it.next();
			if(!modes.containsKey(m.getName())){
				modes.put(m.getName(), m.clone());
			}
		}
		
		annot = (HTLExotaskGraphAnnotation)g2.getTimingData();
		modeList = annot.getHTLModeList().getModes();
		it = modeList.iterator();
		//update the list of modules
		while(it.hasNext()){
			HTLMode m = (HTLMode)it.next();
			if(!modes.containsKey(m.getName())){
				modes.put(m.getName(), m.clone());
			}
		}
		
		return modes;
	}
	
	/**
	 * Get connection annotations.
	 * @param g1
	 * @param g2
	 * @param modes
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getConnectionAnnotations(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2, Map modes) 
	throws ExotaskValidationException{
		Map connAnnotations = new HashMap();
		
		//get connection annotations from the first graph		
		Iterator it = g1.getConnections().iterator();
		//update the list of modules
		while(it.hasNext()){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			HTLConnectionAnnotation annot = (HTLConnectionAnnotation)c.getTimingData();
			if(!connAnnotations.containsKey(c.getName())){
				connAnnotations.put(c.getName(), annot.clone());
			}
		}
		
		//get connection annotations from the second graph		
		it = g2.getConnections().iterator();
		//update the list of modules
		while(it.hasNext()){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			HTLConnectionAnnotation annot = (HTLConnectionAnnotation)c.getTimingData();
			if(!connAnnotations.containsKey(c.getName())){
				connAnnotations.put(c.getName(), annot.clone());
			}
		}
		
		return connAnnotations;
	}
	
	/**
	 * Get communicator annotations.
	 * @param g1
	 * @param g2
	 * @param modes
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getCommunicatorAnnotations(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2, Map modes) 
	throws ExotaskValidationException{
		Map commAnnotations = new HashMap();
		
		//get communicator annotations from the first graph		
		Iterator it = g1.getTasks().iterator();
		//update the list of communicator annotations
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			if(t instanceof ExotaskCommunicatorSpecification){
				HTLCommunicatorAnnotation annot = (HTLCommunicatorAnnotation)t.getTimingData();
				if(!commAnnotations.containsKey(t.getName())){
					commAnnotations.put(t.getName(), annot.clone());
				}
			}
		}
		
		//get communicator annotations from the second graph		
		it = g2.getTasks().iterator();
		//update the list of communicator annotations
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			if(t instanceof ExotaskCommunicatorSpecification){
				HTLCommunicatorAnnotation annot = (HTLCommunicatorAnnotation)t.getTimingData();
				if(!commAnnotations.containsKey(t.getName())){
					commAnnotations.put(t.getName(), annot.clone());
				}
				else{
					HTLCommunicatorAnnotation annot1 = (HTLCommunicatorAnnotation)commAnnotations.get(t.getName());
					if(!annot.equals(annot1)){
						throw new ExotaskValidationException("Can not compose two graphs that have different annotation for the same communicator."
								+ "Communicator '"+t.getName()+"' has different timing annotations.");
					}
				}
			}
		}
		
		return commAnnotations;
	}
	
	/**
	 * Get task annotations.
	 * @param g1
	 * @param g2
	 * @param modes
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getTaskAnnotations(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2, Map modes) 
	throws ExotaskValidationException{
		Map taskAnnotations = new HashMap();
		
		//get task annotations from the first graph		
		Iterator it = g1.getTasks().iterator();
		//update the list of task annotations
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			if(t.getTimingData() instanceof HTLTaskAnnotation){
				HTLTaskAnnotation annot = (HTLTaskAnnotation)t.getTimingData();
				if(!taskAnnotations.containsKey(t.getName())){
					taskAnnotations.put(t.getName(), annot.clone());
				}
			}
		}
		
		//get task annotations from the second graph		
		it = g2.getTasks().iterator();
		//update the list of task annotations
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			if(t.getTimingData() instanceof HTLTaskAnnotation){
				HTLTaskAnnotation annot = (HTLTaskAnnotation)t.getTimingData();
				if(!taskAnnotations.containsKey(t.getName())){
					taskAnnotations.put(t.getName(), annot.clone());
				}
			}
		}
		
		return taskAnnotations;
	}
	
	/**
	 * Get predicate annotations.
	 * @param g1
	 * @param g2
	 * @param modes
	 * @return
	 * @throws ExotaskValidationException
	 */
	private Map getPredicateAnnotations(ExotaskGraphSpecification g1, ExotaskGraphSpecification g2, Map modes) 
	throws ExotaskValidationException{
		Map predicateAnnotations = new HashMap();
		
		//get task annotations from the first graph		
		Iterator it = g1.getTasks().iterator();
		//update the list of task annotations
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			if(t.getTimingData() instanceof HTLModeSwitch){
				HTLModeSwitch annot = (HTLModeSwitch)t.getTimingData();
				if(!predicateAnnotations.containsKey(t.getName())){
					predicateAnnotations.put(t.getName(), annot.clone());
				}
			}
		}
		
		//get predicate annotations from the second graph		
		it = g2.getTasks().iterator();
		//update the list of task annotations
		while(it.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			if(t.getTimingData() instanceof HTLModeSwitch){
				HTLModeSwitch annot = (HTLModeSwitch)t.getTimingData();
				if(!predicateAnnotations.containsKey(t.getName())){
					predicateAnnotations.put(t.getName(), annot.clone());
				}
			}
		}
		
		return predicateAnnotations;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskGlobalTimingData#isComposableWith(com.ibm.realtime.exotasks.timing.ExotaskGlobalTimingData)
	 */
	public boolean isComposableWith(ExotaskGlobalTimingData partner)
	{
		return partner instanceof HTLExotaskGraphAnnotation;
	}
}
