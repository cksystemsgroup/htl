/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import com.ibm.realtime.exotasks.timing.ExotaskTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingDataParser;

/**
 * This calss represents an HTL mode.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 **/
public class HTLMode extends ExotaskTimingData {

	/**
	 * Mode XML TAG.
	 */
	public static final String XML_NODE = "Mode";
	public static final String XML_ATTRIB_NAME = "name";
	public static final String XML_ATTRIB_PERIOD = "period";
	public static final String XML_ATTRIB_MODULE = "module";
	public static final String XML_ATTRIB_REFINE = "refine";
	
	//name of the mode
	private String name;
	//period of the mode
	private long period;
	//the name of the parent module
	private String module;
	//the name of the program that refines the mode
	private String refineProgram;
	
	/**
	 * Create a new mode.
	 * @param pName the name of the mode
	 * @param pPeriod the period of the mode
	 * @param pModule the name of the parent module
	 * @param pRefineProgram the name of the program that refines the mode
	 */
	public HTLMode(String pName, long pPeriod, String pModule, String pRefineProgram){
		name = pName;
		period = pPeriod;
		module = pModule;
		refineProgram = pRefineProgram;
	}
	
	/**
	 * Get the name of the mode.
	 * @return the name of the mode
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * Get the period of the mode.
	 * @return the period of the mode
	 */
	public long getPeriod(){
		return period;
	}
	
	/**
	 * Get the name of the program that refines the mode 
	 * @return
	 */
	public String getRefineProgram(){
		return refineProgram;
	}
	
	/**
	 * Sets the refining program
	 * @param pRefineProgram
	 */
	public void setRefineProgram(String pRefineProgram){
		refineProgram = pRefineProgram;
	}
	
	/**
	 * Get the name of the parent module.
	 * @return the name of the parent module.
	 */
	public String getModule(){
		return module;
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer("");
		code.append("new "+HTLMode.class.getName()+
				"(\"" + name + "\", " + period+"L, \"" + module + "\", \""+
				refineProgram+"\")");
		
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		xml.append("    <"+XML_NODE+" "+
				XML_ATTRIB_NAME+" = '"+name+"' "+
				XML_ATTRIB_PERIOD+" = '"+ExotaskTimingDataParser.formatTime(period)+"' "+
				XML_ATTRIB_MODULE+" = '"+module+"' "+
				XML_ATTRIB_REFINE+" = '"+refineProgram+"'"+
				"/>");
		
		return xml.toString();
	}
	
	public String toString(){
		return "{" + name + ", " + ExotaskTimingDataParser.formatTime(period) + ", " + module + ", " + refineProgram + "}";
	}

	public Object clone(){
		return new HTLMode(name, period, module, refineProgram);
	}
}
