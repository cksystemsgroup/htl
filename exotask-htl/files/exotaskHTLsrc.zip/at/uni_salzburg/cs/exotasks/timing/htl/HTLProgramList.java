/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.timing.htl;

import java.util.ArrayList;

/**
 * This class represents a list of HTL programs
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLProgramList {
	/**
	 * The name of the XML element
	 */
	public static final String XML_NODE = "ProgramList";
	
	/**The list of programs*/
	private ArrayList programs; 
	
	/**
	 * Create a new list of programs.
	 * @param pPrograms the programs that will be added to the list.
	 */
	public HTLProgramList(HTLProgram[] pPrograms){
		programs = new ArrayList(pPrograms.length);
		for(int i=0; i<pPrograms.length; i++)
			if(pPrograms[i]!=null)
				programs.add(pPrograms[i]);
	}
	
	/**
	 * Get the list of program names in the program list.
	 * @return
	 */
	public String[] getProgramNames(){
		String[] names = new String[programs.size()];
		
		for(int i=0; i < programs.size(); i++)
			names[i] = ((HTLProgram)programs.get(i)).getName();
		
		return names;
	}
	
	/**
	 * Get the programs in the list.
	 * @return the programs in the list.
	 */
	public ArrayList getPrograms(){
		return programs;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateSource()
	 */
	public String generateSource() {
		StringBuffer code = new StringBuffer();
		code.append("new "+HTLProgramList.class.getName()+"(");
		
		//create the list of programs
		code.append("new " + HTLProgram.class.getName() + "[]{");
		for(int i=0; i<programs.size(); i++){
			HTLProgram p = (HTLProgram)programs.get(i);
			code.append(p.generateSource());
			if(i<(programs.size()-1)){
				code.append(", ");
			}
		}
		code.append("}");
		code.append(")");
		return code.toString();
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.timing.ExotaskTimingData#generateXML()
	 */
	public String generateXML() {
		StringBuffer xml = new StringBuffer();
		xml.append("  <"+XML_NODE+">\n");
		
		//generate XML for programs
		for(int i=0; i<programs.size(); i++){
			HTLProgram p = (HTLProgram)programs.get(i);
			xml.append(p.generateXML());
			xml.append("\n");
		}
		
		xml.append("  </"+XML_NODE+">");
		return xml.toString();
	}
	
	/**
	 * String representation of the class.
	 */
	public String toString(){
		StringBuffer buff = new StringBuffer();
		for(int i=0; i<programs.size(); i++){
			HTLProgram p = (HTLProgram)programs.get(i);
			buff.append(p.toString());
			
			if(i<(programs.size()-1))
				buff.append(", ");
		}
		
		return buff.toString();
	}
	
	public Object clone(){
		HTLProgram[] programs = new HTLProgram[this.programs.size()];
		
		for(int i = 0; i<programs.length; i++){
			programs[i] = (HTLProgram)((HTLProgram)this.programs.get(i)).clone();
		}
		
		return new HTLProgramList(programs);
	}
}
