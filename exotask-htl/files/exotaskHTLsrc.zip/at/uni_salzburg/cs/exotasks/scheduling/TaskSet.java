/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling;

import com.ibm.realtime.exotasks.ExotaskRunner;
import com.ibm.realtime.exotasks.scheduling.ExotaskSchedulerRunnable;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * This class represents a set of tasks
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class TaskSet {
	//the set of e code task that will be used to run functional tasks
	private ExotaskSchedulerRunnable[] tasks;
	//the exotask threads used to execute the tasks
	private Thread[] threads;
	//the list of IDLE tasks
	private Task idleTaskList;
	//count of used tasks
	private int usedTasks = 1;
	
	/**
	 * Create a new set of ECode tasks.
	 * @param threadFactory the factory that will be used to run the tasks
	 * @param noTasks the number of tasks in the set
	 */
	public TaskSet(){
		idleTaskList = null;
	}
	
	/*
	 * Set the tasks.
	 */
	public void setTasks(ExotaskSchedulerRunnable[] tasks){
		this.tasks = tasks;
		usedTasks = tasks.length;
		//on position it is the schedule
		//set the task set
		for(int i=1; i < this.tasks.length; i++){
			Task t = ((Task)this.tasks[i]); 
			t.setTaskSet(this);
			freeTask(t);
		}
	}
	
	//Put the task in IDLE state
	public void freeTask(Task t){
		t.setNextIdleTask(idleTaskList);
		idleTaskList = t;
		usedTasks--;
	}
	
	/**
	 * Set the threads.
	 * @param threads
	 */
	public void setThreads(Thread[] threads){
		this.threads = threads;
	}
	
	/**
	 * Get the control task.
	 * @return
	 */
	public ExotaskRunner getControlTask(){
		return (ExotaskRunner)tasks[0];
	}
	
	/**
	 * Start the set of E code tasks
	 *
	 */
	public synchronized void start(){		
		for(int i = threads.length-1; i>=0; i--){
			threads[i].start();
		}
	}
	
	/**
	 * Stop the set of E code tasks
	 *
	 */
	public synchronized void stop(){
		for(int i = tasks.length-1; i>0; i--){
			if(tasks[i] instanceof Task){
				((Task)tasks[i]).stop();
			}
		}
	}
	
	/**
	 * Find an emty thread to execute the specified controller.
	 * @param controller
	 */
	public synchronized void scheduleTask(Runnable task, int taskIndex) throws ExotaskValidationException{
		Task t=null;
		//find an IDLE thread
		t = idleTaskList;
				
		//use the found thread to run the runnable
		if(t!=null){
			usedTasks++;
			idleTaskList = t.getNextIdleTask();
			t.setTaskIndex(taskIndex);
			t.setTask(task);
			synchronized (t) {
				t.notify();
			}
		}
		else{
			throw new ExotaskValidationException("There is no available thread to run the requested task.");
		}
	}
	
	/**
	 * Get the number of used tasks
	 * @return
	 */
	public int getUsedTasksCount(){
		return usedTasks;
	}
	
	/**
	 * Get the size of task set
	 * @return
	 */
	public int getSize(){
		return threads.length;
	} 
}
