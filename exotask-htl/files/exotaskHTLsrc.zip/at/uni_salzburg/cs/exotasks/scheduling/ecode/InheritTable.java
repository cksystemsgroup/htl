/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;

/**
 * This class represents the inherit table.
 * 
 * @author dani
 *
 */
class InheritTable extends HTLProgramWalker {
	/**
	 * For each program there will be an entry in this Map
	 * containing a list of child programs for the program.
	 */
	public Map programChildren = new HashMap();
	
	/**
	 * For each program except the root program there will be 
	 * an entry in this Map containing a referance to the 
	 * parent program.
	 */
	public Map programParents = new HashMap();
	
	/**
	 * For each module there will be an entry in this Map
	 * containing a list of child modules for the program.
	 */
	public Map moduleChildren = new HashMap();
	
	/**
	 * For each module except the root modules there will be 
	 * an entry in this Map containing a referance to the 
	 * parent module.
	 */
	public Map moduleParents = new HashMap();
	
	/**
	 * For each mode there will be an entry in this Map
	 * containing a list of child modes for the program.
	 */
	public Map modeChildren = new HashMap();
	
	/**
	 * For each mode except the root modes there will be 
	 * an entry in this Map containing a referance to the 
	 * parent mode.
	 */
	public Map modeParents = new HashMap();
	
	/**
	 * The symbol table
	 */
	private SymbolTable symbolTable; 
	
	public InheritTable(SymbolTable pSymbolTable) throws ExotaskValidationException{
		super(pSymbolTable);
		symbolTable = pSymbolTable;
		walk();
	}

	/**
	 * Update the edges
	 * @param P
	 * @param M
	 * @param m
	 */
	private void updateEdges(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{
		if(m.getRefineProgram()==null || m.getRefineProgram().equals(""))
			return;
		
		HTLProgram P2 = symbolTable.getProgram(m.getRefineProgram());
		
		//update edges for programs
		addToMapOfLists(programChildren, P.getName(), P2);
		addToMap(programParents, P2.getName(), P);
		
		//update edges for modules
		Map modules = symbolTable.getModulesInProgram(P2.getName());
		
		Iterator itModules = modules.values().iterator();
		while(itModules.hasNext()){
			HTLModule M2 = (HTLModule)itModules.next();
			
			addToMapOfLists(moduleChildren, M.getName(), M2);
			addToMap(moduleParents, M2.getName(), M);
			
			//update edges for modes
			Map modes = symbolTable.getModesInModule(M2.getName());
			
			Iterator itModes = modes.values().iterator();
			while(itModes.hasNext()){
				HTLMode m2 = (HTLMode)itModes.next();
				
				if(m2.getPeriod() != m.getPeriod()){
					throw new ExotaskValidationException("Child mode '"+m2.getName()+"' and parent mode '"+
							m.getName()+"' have different periods");
				}
				
				addToMapOfLists(modeChildren, m.getName(), m2);
				addToMap(modeParents, m2.getName(), m);
			}
		}
	}
	
	protected void inAMode(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{
		updateEdges(P, M, m);
	}
	
	public boolean isParentForModule(String parent, String child){
		String crrChild = child;
		while(true){
			if(parent.equals(crrChild))
				return true;
			
			HTLModule M = (HTLModule)moduleParents.get(crrChild);
			if(M == null)
				return false;
			
			crrChild = M.getName();		
		}
	}
}
