/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import at.uni_salzburg.cs.exotasks.scheduling.MultiThreadingSchedule;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Call;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.CleanChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.CopyChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.CopyRegister;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.DeleteChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Future;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.GetParent;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Instruction;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.JumpAbsolute;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.JumpIf;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.JumpSub;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.PopRegister;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.PushRegister;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.RFuture;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Release;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.ReplaceChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Return;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.SFuture;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.SetParent;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.SetParentOfChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.WFuture;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLCommunicatorAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLConnectionAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLExotaskGraphAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeSwitch;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLTaskAnnotation;

import com.ibm.realtime.exotasks.ExotaskRunner;
import com.ibm.realtime.exotasks.ExotaskSystemSupport;
import com.ibm.realtime.exotasks.ExotaskThreadFactory;
import com.ibm.realtime.exotasks.scheduling.ExotaskSchedulingData;
import com.ibm.realtime.exotasks.specification.ExotaskCommunicatorSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskPredicateSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * Creates an ecode schedule from an ExotaskGraphSpecification and an
 *   instantiation map.  Runs as a subroutine of EcodeMasterScheduler,
 *   which is the formal ExotaskScheduler registered with the system.
 *   
 * @author Daniel Iercan (diercan@aut.upt.ro)
 */
public class ECodeSchedule
{   
	  private static final int R0 = 0;
	  private static final int R1 = 1;
	  private static final int R2 = 2;
	  private static final int R3 = 3;
	
	  /**
	   * This Map will contain the list of instructions that need to be fixedup.
	   */
	  private final Map fixeUpChain = new HashMap();
	  
	  /**
	   * The generated e code
	   */
	  private final ArrayList instructions = new ArrayList();

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduler#schedule(com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification, java.util.Map, com.ibm.realtime.exotasks.specification.ExotaskSchedulingData)
	 */
	public ExotaskRunner schedule(ExotaskGraphSpecification toSchedule, Map instantiationMap,
			ExotaskSchedulingData schedulingData, ExotaskThreadFactory factory) 
        throws ExotaskValidationException 
  {
		final SymbolTable symbolTable = new SymbolTable(toSchedule);
		final InheritTable inheritTable = new InheritTable(symbolTable);
		final HTLValidator validator = new HTLValidator(symbolTable, inheritTable);
		validator.check();
		final InstantiationTable instantiationTable = new InstantiationTable(toSchedule, instantiationMap);
		
		//generate SUB to root program
		JumpSub sub = new JumpSub(-1, "Start root program ("+symbolTable.rootProgram+")");
		addSUBToFixeUp(programStartAddress(symbolTable.rootProgram), sub, instructions.size());
		instructions.add(sub);
		instructions.add(new Return("Wait for triggers to become enabled."));
		
		//generate E code for programs
		generateProgramECode(symbolTable);
		
		//generate E code for modules
		generateModuleECode(symbolTable);
		
		long smallestPeriod = 0;
		
		//generate ecode for each mode
		for(Iterator it = symbolTable.modes.values().iterator(); it.hasNext(); ){
			HTLMode mode = (HTLMode)it.next(); 
			
			long modeUinitPeriod = generateModeECode(mode, symbolTable, instantiationTable);
			
			//update the samllest period of the HTL program
			if(smallestPeriod == 0){
				smallestPeriod = modeUinitPeriod;
			}
			else{
				smallestPeriod = gcd(smallestPeriod, modeUinitPeriod);
			}
		}
		
		if (!ExotaskSystemSupport.isExotaskVM()) {
			try{
				FileOutputStream fo = new FileOutputStream("ecode.txt");
				PrintStream ps = new PrintStream(fo);
				
				//write E Code instraction to a file
				int i=0;
				for(Iterator it = instructions.iterator(); it.hasNext();){
					ps.print((i++)+": ");
					Instruction instr = (Instruction)it.next();
					
					ps.println(instr.toString());
				}
				ps.flush();
				ps.close();
				fo.close();
			}
			catch(IOException e){}
			}
			
			ECodeRunner emachine = new ECodeRunner(instructions, instantiationTable.tasks, 
					instantiationTable.drivers, instantiationTable.predicates, 
					symbolTable.maxRunningTasks, smallestPeriod, ((HTLExotaskGraphAnnotation)toSchedule.getTimingData()).getSlowDownFactor());
			
			return MultiThreadingSchedule.cloneAndStartMultiThreadingSchedule(emachine, factory);
	}

	private void generateProgramECode(final SymbolTable pSymbolTable){
		//generate E code that will start each program
		for(Iterator it = pSymbolTable.programs.values().iterator(); it.hasNext(); ){
			HTLProgram P = (HTLProgram)it.next();
			
			//fixup SUB that start this program
			fixeUpSUB(programStartAddress(P.getName()), instructions.size());
			
			//generate SUB for each module
			Map modules = (Map)pSymbolTable.modulesInProgram.get(P.getName());
			for(Iterator itModules = modules.values().iterator(); itModules.hasNext(); ){
				HTLModule M = (HTLModule)itModules.next();
				
				//generate SUB to start M.
				JumpSub sub = new JumpSub(-1, "Start module '"+M.getName()+"'");
				
				addSUBToFixeUp(moduleStartAddress(M.getName()), sub, instructions.size());
				
				instructions.add(sub);
			}
			
			//RETURN from program start subroutine
			instructions.add(new Return("Return from program '"+P.getName() + "' start."));
		}
	}
	
	/**
	 * Generate E code that starts modules.
	 * @param pSymbolTable
	 */
	private void generateModuleECode(final SymbolTable pSymbolTable){
		//add future instruction that will jump to the begining of each group
		for(Iterator it = pSymbolTable.modules.values().iterator(); it.hasNext(); ){
			
			HTLModule M = (HTLModule)it.next();
			
			//fixup SUB that start this module
			fixeUpSUB(moduleStartAddress(M.getName()), instructions.size());
			
			//emit SUB to start 'starting mode'
			JumpSub sub = new JumpSub(-1, "SUB to start mode '"+M.getStartMode()+"'.");
			
			addSUBToFixeUp(modeStartAddress(M.getStartMode()), sub, instructions.size());
			
			instructions.add(sub);
			
			//RETURN from module start subroutine
			instructions.add(new Return("Return from module '"+M.getName() + "' start."));
		}
	}
	
	/**
	 * Generate e code for a mode
	 * @param pMode
	 * @param pSymbolTable
	 * @return the unit period for the mode
	 */
	private long generateModeECode(HTLMode pMode, SymbolTable pSymbolTable, InstantiationTable pInstantiationTable)throws ExotaskValidationException{
		final Map connections = pSymbolTable.getConnectionsInMode(pMode.getName());
		final Map tasks = pSymbolTable.getTasksInMode(pMode.getName());
		final Map predicates = pSymbolTable.getPredicatesInMode(pMode.getName());
		final long period = pMode.getPeriod();
		final Set nonPreTasks = new HashSet();
		final Set preTasks = new HashSet();

		//generate mode start E Code
		fixeUpSUB(modeStartAddress(pMode.getName()), instructions.size());
		//read communicators into predicates input ports
		generatePredicateCallECode(connections, pInstantiationTable);
		//check switches
		generateStartModeModeSwitchTests(pMode.getName(), predicates, pInstantiationTable);
		fixeUpIf(targetModeAddress(pMode.getName()), instructions.size());
		fixeUpJUMP(targetModeAddress(pMode.getName()), instructions.size());
		//generate SUB to mode body E code
		JumpSub sub = new JumpSub(-1, "Call mode_body_address['"+pMode.getName()+"']");
		addSUBToFixeUp(modeBodyAddress(pMode.getName()), sub, instructions.size());
		instructions.add(sub);
		if(!pMode.getRefineProgram().equals("")){
			//generate INCREMENT LEVEL instructions
			instructions.add(new GetParent(R0, R3, "Save the parent of R0 in R3"));
			instructions.add(new PushRegister(R3, "Push register R3 on to PARENT_STACK"));
			instructions.add(new SetParent(R0, R2, "Set R2 as parent of R0"));
			instructions.add(new CleanChildren(R0, "Reset the children list of the trigger in R0"));
			//start refining program
			sub = new JumpSub(-1, "Start refining program. Call program_start_address['"+pMode.getRefineProgram()+"']");
			addSUBToFixeUp(programStartAddress(pMode.getRefineProgram()), sub, instructions.size());
			instructions.add(sub);
			//generate DECREMENT LEVEL instructions
			instructions.add(new PopRegister(R3, "POP a trigger from the PARENT_STACK into R3"));
			instructions.add(new SetParent(R0, R3, "Set R3 as parent of R0"));
			instructions.add(new CleanChildren(R0, "Reset the children list of the trigger in R0"));
		}
		//return from start subrutine
		instructions.add(new Return("Retrun from mode_start_address['"+pMode.getName()+"']"));
		
		sortTasks(tasks, connections, nonPreTasks, preTasks);
		
		long smallPeriod = computeUnitPeriod(period, connections);
		
		int units = (int)(period/smallPeriod);
		int j=0;
		long futurePeriod = smallPeriod;
		for(int i=0; i < units; i++){
			//generate E code for each unit
			
			if(i!=0 && i!=units-1 && !isAnyEventDue(connections, i, smallPeriod, period)){
				futurePeriod += smallPeriod;
				continue;
			}
			
			fixeUpFuture(modeUnitWriteAddress(pMode.getName(), j), instructions.size(), futurePeriod);
			
			//generate E Code for connections that write communicators
			generateCallECode(connections, i, smallPeriod, period, pInstantiationTable, true);
			
			//wait for other modules to call drivers
			instructions.add(new Return("Return from updateing communicators."));
			
			if(i==0){
				fixeUpFuture(modeUnitSwitchAddress(pMode.getName(), i), instructions.size());
				//read communicators into predicates input ports
				generatePredicateCallECode(connections, pInstantiationTable);				
			
				//generate mode switch test
				generateUnit0ModeSwitchTests(pMode.getName(), predicates, pInstantiationTable);
				
				//this is mode body address
				fixeUpSUB(modeBodyAddress(pMode.getName()), instructions.size());
				//future to the start of unit 0  after period
				Future f = new WFuture(pMode.getPeriod(), 0, -1, 
						"WFUTURE after period to the start of unit 0 for '"+pMode.getName()+"'");
				addFutureToFixeUp(modeUnitWriteAddress(pMode.getName(), 0), f, instructions.size());
				instructions.add(f);
				f = new SFuture(pMode.getPeriod(), 0, -1, 
						"SFUTURE after period to the start of unit 0 for '"+pMode.getName()+"'");
				addFutureToFixeUp(modeUnitSwitchAddress(pMode.getName(), 0), f, instructions.size());
				instructions.add(f);
				instructions.add(new GetParent(R0, R3, "Save the parent of R0 in R3"));
				instructions.add(new ReplaceChildren(R3, R0, R1, "Replace R0 with R1 in the children list of R3"));
				instructions.add(new SetParentOfChildren(R0, R1, "Set R1 as the parent of the children in the children list of R0"));
				instructions.add(new SetParent(R1, R3, "Set R3 as the parent of R1"));
				instructions.add(new CopyChildren(R1, R0, "Copy children list from R0 to R1"));
				instructions.add(new CopyRegister(R1, R2, "Save the trigger in R1 in R2"));
				f = new RFuture(0, 0, -1, 
						"RFUTURE to the start of unit 0 for '"+pMode.getName()+"'");
				addFutureToFixeUp(modeUnitReadAddress(pMode.getName(), 0), f, instructions.size());
				instructions.add(f);
				instructions.add(new Return("Return from mode body."));
			}
			
			fixeUpFuture(modeUnitReadAddress(pMode.getName(), j), instructions.size(), futurePeriod);
			
			//generate E Code for connections that read communicators
			generateCallECode(connections, i, smallPeriod, period, pInstantiationTable, false);
			
			if(i==0){
				//generate future to release precedence task
				for(Iterator it = preTasks.iterator(); it.hasNext();){
					ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
					
					Future f = new RFuture(0, 0, -1, "Future to release task: "+t.getName());
					
					getTaskDependencies(t, connections, f, pInstantiationTable);
					addFutureToFixeUp(taskReleaseAddress(pMode.getName(), t.getName()), f, instructions.size());
					instructions.add(f);
				}
			}
			
			//generate ecode that releases tasks that has no precedence
			releaseNonPrecedenceTasks(smallPeriod, i, nonPreTasks, connections, pInstantiationTable);
			
			//generate future to next unit
			int nextUnit = i+1;
			if(i+1 == units)
				nextUnit = 0;
			
			if(nextUnit != 0){
				//wfuture to next unit (except for the unit zero, the future for unit zero is already there)
				Future f = new WFuture(smallPeriod, 0, -1, "WFUTURE to the next unit.");
				
				addFutureToFixeUp(modeUnitWriteAddress(pMode.getName(), nextUnit), f,instructions.size());
				instructions.add(f);
				
				//rfuture to next unit (except for the unit zero, the future for unit zero is already there)
				f = new RFuture(smallPeriod, 0, -1, "RFUTURE to the next unit.");
				
				addFutureToFixeUp(modeUnitReadAddress(pMode.getName(), nextUnit), f,instructions.size());
				instructions.add(f);
			}
			
			Return r  = new Return("Return from: mode "+pMode.getName()+" unit "+i);
			instructions.add(r);
			
			j=i+1;
			futurePeriod = smallPeriod;
		}
		
		//generate E Code that releases the tasks
		for(Iterator it = preTasks.iterator(); it.hasNext();){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			//fixe up adresses
			fixeUpFuture(taskReleaseAddress(pMode.getName(), t.getName()), instructions.size());
						
			//generate E Code that will call all flexibale connections
			generateFlexConnECode(t, connections, pInstantiationTable);
			
			//generate release instruction
			Release rls = new Release(pInstantiationTable.getTaskPositions(t),"Release task " + t.getName());
			instructions.add(rls);
			
			//	return
			Return r  = new Return("Return from tasks "+t.getName()+" release.");
			instructions.add(r);
		}
		
		return smallPeriod;
	}
	
	/**
	 * This method will split the tasks in non precedences tasks and preceences tasks.
	 * @param tasks
	 * @param connections
	 * @param nonPrecedenceTasks
	 * @param precedenceTasks
	 */
	private void sortTasks(Map tasks, Map connections, Set nonPrecedenceTasks, Set precedenceTasks){
		if(tasks == null)
			return;
		for(Iterator it = tasks.values().iterator(); it.hasNext();){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			
			if(!((HTLTaskAnnotation)t.getTimingData()).IsAbstract()){
				//if this is not an abstract task
				boolean hasPre = false;
				for(Iterator itConn = connections.values().iterator(); itConn.hasNext();){
					ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)itConn.next();
					if(c.getOutput().getName().equals(t.getName())){
						if(tasks.containsKey(c.getInput().getName())){
							//t has at least one precedence task
							precedenceTasks.add(t);
							hasPre = true;
							break;
						}
					}
				}
				
				if(!hasPre){
					//task does not have predecessors
					nonPrecedenceTasks.add(t);
				}
			}
		}
	}
	
	private long computeUnitPeriod(long pModePeriod, Map pConnectionsInMode) throws ExotaskValidationException{
		long smallPeriod = pModePeriod;
		
		if(pConnectionsInMode == null)
			return smallPeriod;
		
		for(Iterator it = pConnectionsInMode.values().iterator(); it.hasNext(); ){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			
			HTLConnectionAnnotation constraint = (HTLConnectionAnnotation) c.getTimingData();
				
			if (constraint != null && constraint.getInstance() >= 0) {
			  // the connection uses a communicator
			  ExotaskTaskSpecification comm = constraint.getCommunicator(c);
			  long period = ((HTLCommunicatorAnnotation) comm.getTimingData()).getPeriod();
			    
			  long offset = 0;
			  offset = constraint.getInstance()*period;
			  if(pModePeriod < offset){
			      throw new ExotaskValidationException("Incompatible connector instance " + 
			          constraint.getInstance() + " with communicator period " + period + 
			          " and mode period " + pModePeriod + " in " + c.generateXML());
			  }	else{
			      smallPeriod = gcd(smallPeriod, offset);
			  }
			}			
		}
		
		return smallPeriod;
	}
	
	/**
	 * Test to see if there is any event due in the specified unit
	 *
	 */
	private boolean isAnyEventDue(Map pConnections, long pUnit, long pSmallPeriod, long pPeriod){
		if(pConnections == null)
			return false;
		//generate call connection driver instructions
		for(Iterator it = pConnections.values().iterator(); it.hasNext();){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			
			if(isAbstractConnection(c))
				continue;
			
			if(c.getTimingData() != null && 
					((HTLConnectionAnnotation) c.getTimingData()).getInstance() >= 0) {
				//get the communicator use and the communicator
				HTLConnectionAnnotation annote = (HTLConnectionAnnotation)c.getTimingData();
				
				if((c.getOutput() instanceof ExotaskPredicateSpecification))
					//the connection should not be called yet
					continue;
				
				ExotaskTaskSpecification comm = annote.getCommunicator(c);
				long period = ((HTLCommunicatorAnnotation) comm.getTimingData()).getPeriod();

				long offset = annote.getInstance()*period;

				if(offset%pPeriod == pUnit*pSmallPeriod){
					//the driver should be called
					return true;
				}
			}
		}
		return false;
	}
		
	/**
	 * Generate E Code for connections that have an ConnectorUse associented with them
	 *
	 */
	private void generateCallECode(Map pConnections, long pUnit, long pSmallPeriod, long pPeriod, InstantiationTable pInstantiation, boolean pWrite){
		if(pConnections == null)
			return;
		//generate call connection driver instructions
		for(Iterator it = pConnections.values().iterator(); it.hasNext();){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			
			if(isAbstractConnection(c))
				continue;
			
			if(c.getTimingData() != null && 
					((HTLConnectionAnnotation) c.getTimingData()).getInstance() >= 0) {
				//get the communicator use and the communicator
				HTLConnectionAnnotation annote = (HTLConnectionAnnotation)c.getTimingData();
				
				if(annote.writesCommunicator()!=pWrite || (c.getOutput() instanceof ExotaskPredicateSpecification))
					//the connection should not be called yet
					continue;
				
				ExotaskTaskSpecification comm = annote.getCommunicator(c);
				long period = ((HTLCommunicatorAnnotation) comm.getTimingData()).getPeriod();

				long offset = annote.getInstance()*period;

				if(offset%pPeriod == pUnit*pSmallPeriod){
					//the driver should be called

					Call callInstr = new Call(pInstantiation.getDriverPositions(c),
                                      "Call copy from "+c.getInput().getName()+" to " + c.getOutput().getName());
					instructions.add(callInstr);
				}
			}
		}
	}
	
	/**
	 * Test to see if a connection is an abstract one.
	 * @param connection
	 * @return
	 */
	private boolean isAbstractConnection(ExotaskConnectionSpecification connection){
		ExotaskTaskSpecification task = null;
		
		if(!(connection.getOutput() instanceof ExotaskCommunicatorSpecification || 
				connection.getOutput() instanceof ExotaskPredicateSpecification)){
			task = connection.getOutput();
		}
		if(!(connection.getInput() instanceof ExotaskCommunicatorSpecification)){
			task = connection.getInput();
		}
		
		if(task != null){
			HTLTaskAnnotation taskAnnot = (HTLTaskAnnotation)task.getTimingData();
			
			return taskAnnot.IsAbstract();
		}
		
		return false;
	}
	
	/**
	 * Generate E Code that read communicators into predicators input ports
	 *
	 */
	private void generatePredicateCallECode(Map pConnections, InstantiationTable pInstantiation)
	throws ExotaskValidationException{
		if(pConnections == null)
			return;
		
		//generate call connection driver instructions
		for(Iterator it = pConnections.values().iterator(); it.hasNext();){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			
			if(c.getTimingData() != null && 
					((HTLConnectionAnnotation) c.getTimingData()).getInstance() == 0) {
				
				if(!(c.getOutput() instanceof ExotaskPredicateSpecification))
					//the connection should not be called yet
					continue;

				Call callInstr = new Call(pInstantiation.getDriverPositions(c),
                                  "Call copy from "+c.getInput().getName()+" to " + c.getOutput().getName());
				instructions.add(callInstr);
			}
			else
			if(c.getTimingData() != null){
				if(!(c.getOutput() instanceof ExotaskPredicateSpecification))
					//the connection should not be called yet
					continue;

				Call callInstr = new Call(pInstantiation.getDriverPositions(c),
                                  "Call copy from "+c.getInput().getName()+" to " + c.getOutput().getName());
				instructions.add(callInstr);
			}
			else{
				throw new ExotaskValidationException("[Connection: '"+c.getName()
						+"']Predicates can be updated only at the begining of period.");
			}
		}
	}
	
	/**
	 * Generate mode switch test.
	 * @param pPredicates
	 * @param pInstantiation
	 */
	private void generateUnit0ModeSwitchTests(String pModeName,Map pPredicates, InstantiationTable pInstantiation){
		if(pPredicates==null)
			return;//no mode switch
		for(Iterator it = pPredicates.values().iterator(); it.hasNext();){
			ExotaskPredicateSpecification p = (ExotaskPredicateSpecification)it.next();
			HTLModeSwitch sw = (HTLModeSwitch)p.getTimingData();
		
			JumpIf ifInstruction = new JumpIf(pInstantiation.getPredicatePosition(p), instructions.size()+2, "Mode switch from '"+
					pModeName + "' to '" + sw.getTargetMode() + "'. (Unit 0 check)");
			instructions.add(ifInstruction);
			instructions.add(new JumpAbsolute(instructions.size()+4, "Mode switch condition is FALSE."));
			instructions.add(new DeleteChildren(R0, "Mode switch is TRUE. Cancel all triggers that belong to the refining program"));
			instructions.add(new CleanChildren(R0, "Clean the children list."));
			JumpAbsolute jump = new JumpAbsolute(-1, "Jump to target mode from unit 0 mode switch test");
			addJUMPToFixeUp(targetModeAddress(sw.getTargetMode()), jump, instructions.size());
			instructions.add(jump);
		}
	}
	
	/**
	 * Generate mode switch test for the start of the mode.
	 * @param pPredicates
	 * @param pInstantiation
	 */
	private void generateStartModeModeSwitchTests(String pModeName, Map pPredicates, InstantiationTable pInstantiation){
		if(pPredicates==null)
			return;//no mode switch
		for(Iterator it = pPredicates.values().iterator(); it.hasNext();){
			ExotaskPredicateSpecification p = (ExotaskPredicateSpecification)it.next();
			HTLModeSwitch sw = (HTLModeSwitch)p.getTimingData();
		
			JumpIf ifInstruction = new JumpIf(pInstantiation.getPredicatePosition(p), -1, "Mode switch from '"+
					pModeName + "' to '" + sw.getTargetMode() + "'. (Start of mode '"+pModeName+"')");
			addIfToFixeUp(targetModeAddress(sw.getTargetMode()), ifInstruction, instructions.size());
			instructions.add(ifInstruction);
		}
	}
	
	/**
	 * Compute the offset relative to the begining of the period 
	 * and also the dependency list
	 * @param pTask
	 * @param pConnections
	 * @param pFuture
	 */
	private long getTaskDependencies(ExotaskTaskSpecification pTask, Map pConnections, Future pFuture, InstantiationTable pInstantiations) throws ExotaskValidationException {
		long offset = 0;
		long depList = 0;
		
		for(Iterator it = pConnections.values().iterator(); it.hasNext();){
			//take each connection in the group
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			if(c.getOutput().equals(pTask)){
				//the output of the connection is the searched task
				if(c.getTimingData()!=null && ((HTLConnectionAnnotation) c.getTimingData()).getInstance() >= 0) {
					//fixed connection
					//get the communicator use and the communicator
					HTLConnectionAnnotation annote = (HTLConnectionAnnotation)c.getTimingData();
					ExotaskTaskSpecification comm = annote.getCommunicator(c);
					long period = ((HTLCommunicatorAnnotation) comm.getTimingData()).getPeriod();
					long o = period * annote.getInstance();

					if(o > offset)
						offset = o;
				}
				else{
					//flexibale connection
					if(c.getInput() instanceof ExotaskTaskSpecification){
						//the pTask depends on another task
						int taskIndex = pInstantiations.getTaskPositions(c.getInput());
						
						if(taskIndex >=63){
							throw new ExotaskValidationException("There is a limit of 63 tasks.");
						}

						depList |= (1l<<taskIndex);
					}
				}
			}
		}
		
		if(pFuture != null){
			pFuture.setTime(offset);
			pFuture.setDependency(depList);
		}
		
		return offset;
	}
	
	/**
	 * Release nonprecedence tasks in the specified unit.
	 * @param pPeriod
	 * @param pUnit
	 * @param pTasks
	 * @param pConnections
	 * @param pInstantiation
	 */
	private void releaseNonPrecedenceTasks(long pUnitPeriod, int pUnit, Set pTasks, 
			Map pConnections, InstantiationTable pInstantiations) throws ExotaskValidationException{
		
		for(Iterator it=pTasks.iterator(); it.hasNext();){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			long offset = getTaskDependencies(t, pConnections, null, pInstantiations);
			
			if(offset == pUnit*pUnitPeriod){
				//task has to be released
				Release r = new Release(pInstantiations.getTaskPositions(t), "Release task '"+t.getName()+"'");
				instructions.add(r);
			}
		}
	}
	
	/**
	 * Generate Call instructions for 
	 * @param pTask
	 * @param pConnections
	 */
	private void generateFlexConnECode(ExotaskTaskSpecification pTask, Map pConnections, InstantiationTable pInstantiation){
		
		for(Iterator it = pConnections.values().iterator(); it.hasNext();){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			
			if(c.getTimingData() != null && ((HTLConnectionAnnotation)c.getTimingData()).getInstance()<=0)
			{
				if(c.getOutput().equals(pTask)){
					//generate Call for this
					Call call = new Call(pInstantiation.getDriverPositions(c), 
							"CALL diriver to update input port "+ c.getInputPortToWrite()+ " of task "
							+pTask.getName());
					instructions.add(call);
				}
			}
		}
	}
	
	/////////////////////////////////////////////////////
	//                      MISC                       //
	/////////////////////////////////////////////////////
	
	/**
	 * Compute greater common divider
	 * @param a
	 * @param b
	 * @return the gcd of a and b
	 */
	private long gcd(long a, long b){
		if(b == 0)
			return a;
		long mod = a % b;
		if(mod > 0)
		{
			return gcd(b, mod);
		}
		else{
			return b;
		}
	}
	
	/**
	 * Add a future instruction to the fixe up chain
	 * @param pKey
	 * @param pF
	 * @param pAddress
	 */
	private void addFutureToFixeUp(String pKey, Future pF, int pAddress){
		if(fixeUpChain.containsKey(pKey)){
			Object obj = fixeUpChain.get(pKey);
			if(obj instanceof Integer)
				pF.setAddress(((Integer)obj).intValue());
			else{
				Future f = (Future)obj;
				
				int adr = f.getAddress();
				f.setAddress(-pAddress-2);
				pF.setAddress(adr);
			}
				
		}
		else{
			pF.setAddress(-1);
			fixeUpChain.put(pKey, pF);
		}
	}
	
	/**
	 * Add an If instruction to the fixe up chain
	 * @param pKey
	 * @param pF
	 * @param pAddress
	 */
	private void addIfToFixeUp(String pKey, JumpIf pIf, int pAddress){
		String key = "IF_"+pKey; 
		if(fixeUpChain.containsKey(key)){
			Object obj = fixeUpChain.get(key);
			if(obj instanceof Integer)
				pIf.setAddress(((Integer)obj).intValue());
			else{
				JumpIf ifThen = (JumpIf)obj;
				
				int adr = ifThen.getAddress();
				ifThen.setAddress(-pAddress-2);
				pIf.setAddress(adr);
			}
				
		}
		else{
			pIf.setAddress(-1);
			fixeUpChain.put(key, pIf);
		}
	}
	
	/**
	 * Add an SUB instruction to the fixe up chain
	 * @param pKey
	 * @param pF
	 * @param pAddress
	 */
	private void addSUBToFixeUp(String pKey, JumpSub pSUB, int pAddress){
		String key = "SUB_"+pKey; 
		if(fixeUpChain.containsKey(key)){
			Object obj = fixeUpChain.get(key);
			if(obj instanceof Integer)
				pSUB.setAddress(((Integer)obj).intValue());
			else{
				JumpSub sub = (JumpSub)obj;
				
				int adr = sub.getAddress();
				sub.setAddress(-pAddress-2);
				pSUB.setAddress(adr);
			}
				
		}
		else{
			pSUB.setAddress(-1);
			fixeUpChain.put(key, pSUB);
		}
	}
	
	/**
	 * Add an JUMP instruction to the fixe up chain
	 * @param pKey
	 * @param pF
	 * @param pAddress
	 */
	private void addJUMPToFixeUp(String pKey, JumpAbsolute pJUMP, int pAddress){
		String key = "JUMP_"+pKey; 
		if(fixeUpChain.containsKey(key)){
			Object obj = fixeUpChain.get(key);
			if(obj instanceof Integer)
				pJUMP.setAddress(((Integer)obj).intValue());
			else{
				JumpAbsolute jump = (JumpAbsolute)obj;
				
				int adr = jump.getAddress();
				jump.setAddress(-pAddress-2);
				pJUMP.setAddress(adr);
			}
				
		}
		else{
			pJUMP.setAddress(-1);
			fixeUpChain.put(key, pJUMP);
		}
	}
	
	/**
	 * Fixe up future instructions
	 * @param pKey
	 * @param pAddress
	 */
	private void fixeUpFuture(String pKey, int pAddress, long pTime){
		if(fixeUpChain.containsKey(pKey) && (fixeUpChain.get(pKey) instanceof Future)){
			Future fInst = (Future)fixeUpChain.get(pKey);
			fInst.setTime(pTime);
			fixeUpFuture(fInst, pAddress);
		}
		
		fixeUpChain.put(pKey, new Integer(pAddress));
	}
	
	/**
	 * Fixe up future instructions
	 * @param pKey
	 * @param pAddress
	 */
	private void fixeUpFuture(String pKey, int pAddress){
		if(fixeUpChain.containsKey(pKey) && (fixeUpChain.get(pKey) instanceof Future))
			fixeUpFuture((Future)fixeUpChain.get(pKey), pAddress);
		
		fixeUpChain.put(pKey, new Integer(pAddress));
	}
	
	/**
	 * Fixe up IF instructions
	 * @param pKey
	 * @param pAddress
	 */
	private void fixeUpIf(String pKey, int pAddress){
		String key = "IF_"+pKey;
		if(fixeUpChain.containsKey(key) && (fixeUpChain.get(key) instanceof JumpIf))
			fixeUpIf((JumpIf)fixeUpChain.get(key), pAddress);
		
		fixeUpChain.put(key, new Integer(pAddress));
	}
	
	/**
	 * Fixe up IF instructions
	 * @param pF
	 * @param pAddress
	 */
	private void fixeUpFuture(Future pF, int pAddress){
		int adr = pF.getAddress();
		pF.setAddress(pAddress);
		
		if(adr < -1){
			fixeUpFuture((Future)instructions.get(-adr-2), pAddress);
		}
	}
	
	/**
	 * Fixe up IF instructions
	 * @param pIf
	 * @param pAddress
	 */
	private void fixeUpIf(JumpIf pIf, int pAddress){
		int adr = pIf.getAddress();
		pIf.setAddress(pAddress);
		
		if(adr < -1){
			fixeUpIf((JumpIf)instructions.get(-adr-2), pAddress);
		}
	}
	
	/**
	 * Fixe up SUB instructions
	 * @param pKey
	 * @param pAddress
	 */
	private void fixeUpSUB(String pKey, int pAddress){
		String key = "SUB_"+pKey;
		if(fixeUpChain.containsKey(key) && (fixeUpChain.get(key) instanceof JumpSub))
			fixeUpSUB((JumpSub)fixeUpChain.get(key), pAddress);
		
		fixeUpChain.put(key, new Integer(pAddress));
	}
	
	/**
	 * Fixe up SUB instructions
	 * @param pF
	 * @param pAddress
	 */
	private void fixeUpSUB(JumpSub pSub, int pAddress){
		int adr = pSub.getAddress();
		pSub.setAddress(pAddress);
		
		if(adr < -1){
			fixeUpSUB((JumpSub)instructions.get(-adr-2), pAddress);
		}
	}
	
	/**
	 * Fixe up JUMP instructions
	 * @param pKey
	 * @param pAddress
	 */
	private void fixeUpJUMP(String pKey, int pAddress){
		String key = "JUMP_"+pKey;
		if(fixeUpChain.containsKey(key) && (fixeUpChain.get(key) instanceof JumpAbsolute))
			fixeUpJUMP((JumpAbsolute)fixeUpChain.get(key), pAddress);
		
		fixeUpChain.put(key, new Integer(pAddress));
	}
	
	/**
	 * Fixe up JUMP instructions
	 * @param pF
	 * @param pAddress
	 */
	private void fixeUpJUMP(JumpAbsolute pJump, int pAddress){
		int adr = pJump.getAddress();
		pJump.setAddress(pAddress);
		
		if(adr < -1){
			fixeUpJUMP((JumpAbsolute)instructions.get(-adr-2), pAddress);
		}
	}
	
	/**
	 * Compose the mode unit address key.
	 * @param pMode
	 * @param pUnit
	 * @return
	 */
	private String modeUnitWriteAddress(String pMode, int pUnit){
		StringBuffer buff = new StringBuffer();
		buff.append("adr_mode_unit_write[").append(pMode);
		buff.append(", ").append(pUnit).append("]");
		return buff.toString();
	}
	
	/**
	 * Compose the mode unit address key.
	 * @param pMode
	 * @param pUnit
	 * @return
	 */
	private String modeUnitSwitchAddress(String pMode, int pUnit){
		StringBuffer buff = new StringBuffer();
		buff.append("adr_mode_unit_switch[").append(pMode);
		buff.append(", ").append(pUnit).append("]");
		return buff.toString();
	}
	
	/**
	 * Compose the mode unit address key.
	 * @param pMode
	 * @param pUnit
	 * @return
	 */
	private String modeUnitReadAddress(String pMode, int pUnit){
		StringBuffer buff = new StringBuffer();
		buff.append("adr_mode_unit_read[").append(pMode);
		buff.append(", ").append(pUnit).append("]");
		return buff.toString();
	}
		
	private String taskReleaseAddress(String pMode, String pTask){
		return "addr_release["+pMode+", "+pTask+"]";
	}
	
	private String programStartAddress(String pProgram){
		return "program_start_address["+pProgram+"]";
	}
	
	private String moduleStartAddress(String pModule){
		return "module_start_address["+pModule+"]";
	}
	
	private String modeStartAddress(String pMode){
		return "mode_start_address["+pMode+"]";
	}
	
	private String targetModeAddress(String pMode){
		return "target_mode_address["+pMode+"]";
	}
	
	private String modeBodyAddress(String pMode){
		return "mode_body_address["+pMode+"]";
	}
}
