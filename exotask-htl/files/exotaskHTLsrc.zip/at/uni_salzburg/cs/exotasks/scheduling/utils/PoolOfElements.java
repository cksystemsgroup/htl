/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.utils;

import java.lang.reflect.Constructor;

/**
 * @author Daniel Iercan (daniel.iercan@aut.upt.ro)
 * 
 * This class implements a pool of elements.
 *
 */
public class PoolOfElements extends DoubleLinkedList {
	/**list of used elements*/
	private DoubleLinkedList usedElements;
	
	/**
	 * Create a pool with the specified number of elements in it.
	 * @param index
	 * @param noOfElelments
	 * @param elementType
	 */
	public PoolOfElements(int index, int noOfElements, int linkSize, Class elementType) {
		super(index);
		
		usedElements = new DoubleLinkedList(index);
		
		try{
			Constructor cons = elementType.getDeclaredConstructor(new Class[]{Integer.class});
		    cons.setAccessible(true);
			while(getSize() < noOfElements){
				MultiLinkEelement elem = (MultiLinkEelement)cons.newInstance(new Object[]{new Integer(linkSize)});
				add(elem);
			}
		}
		catch(Exception e){
			throw new IllegalStateException(elementType.getName() + 
					" could not be instantiated or it is not a subclass of MultiLinkElement.");
		}
	}
	
	/**
	 * Get a free element from the pool.
	 * @return
	 * @throws IndexOutOfBoundsException
	 */
	public MultiLinkEelement getElement() throws IndexOutOfBoundsException{
		MultiLinkEelement elem = getTail();
		if(elem == null){
			throw new IndexOutOfBoundsException("Thre are no free elements in the pool");
		}
		remove(elem);
		usedElements.add(elem);
		return elem;
	}
	
	/**
	 * Free a element.
	 * @param element
	 */
	public void freeElement(MultiLinkEelement element){
		usedElements.remove(element);
		element.reset();
		add(element);
	}
	
	/**
	 * Reset the pool of elements
	 *
	 */
	public void reset(){
		for(MultiLinkEelement e = usedElements.getHead(); e!=null; ){
			MultiLinkEelement eTmp = e;
			e=usedElements.getNext(e);
			usedElements.remove(eTmp);
			add(eTmp);
		}
	}
	 
	/**
	 * Get the size of used elements
	 * @return
	 */
	public int getUsedElementsSize(){
		return usedElements.getSize();
	}
}
