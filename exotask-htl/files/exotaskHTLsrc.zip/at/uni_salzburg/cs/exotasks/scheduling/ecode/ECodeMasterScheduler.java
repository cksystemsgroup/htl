/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.Collections;
import java.util.Map;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLExotaskGraphAnnotation;

import com.ibm.realtime.exotasks.ExotaskRunner;
import com.ibm.realtime.exotasks.ExotaskThreadFactory;
import com.ibm.realtime.exotasks.scheduling.ExotaskScheduler;
import com.ibm.realtime.exotasks.scheduling.ExotaskSchedulingData;
import com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * Fulfulls the ExotaskScheduler contract.  This contract calls for one reusable object per VM.
 * The ECodeSchedule written by Daniel Iercan uses its own instance variables to hold
 *   state while computing the Ecode schedule.  So, it is not reusable.  It is still used to
 *   compute the schedule for each individual graph.
 */
public class ECodeMasterScheduler implements ExotaskScheduler
{
  /* (non-Javadoc)
   * @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduler#getHeapSizes(com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification, com.ibm.realtime.exotasks.scheduling.ExotaskSchedulingData)
   */
  public Map getHeapSizes(ExotaskGraphSpecification toSchedule, ExotaskSchedulingData schedulingData)
	{
  	// TODO a more meaningful implementation
		return Collections.EMPTY_MAP;
	}
  
  // @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduler#isSchedulable(com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification, com.ibm.realtime.exotasks.specification.ExotaskSchedulingData)
  public boolean isSchedulable(ExotaskGraphSpecification toSchedule,
      ExotaskSchedulingData schedulingData)
  {
    /* For the moment, we just test whether the right timing grammar was used. */
  	boolean result = toSchedule.getTimingData() instanceof HTLExotaskGraphAnnotation;
    return result;
  }

  // @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduler#schedule(com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification, java.util.Map, com.ibm.realtime.exotasks.specification.ExotaskSchedulingData, com.ibm.realtime.exotasks.ExotaskThreadFactory)
  public ExotaskRunner schedule(ExotaskGraphSpecification toSchedule,
      Map instantiationMap, ExotaskSchedulingData schedulingData,
      ExotaskThreadFactory threadFactory)
        throws ExotaskValidationException
  {	  
    ECodeSchedule oneShot = new ECodeSchedule();
    return oneShot.schedule(toSchedule, instantiationMap, schedulingData, threadFactory);
  }

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.scheduling.ExotaskScheduler#getName()
	 */
	public String getName()
	{
		return "HTLScheduler";
	}
}
