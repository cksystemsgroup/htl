/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskPredicateSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;

/**
 * This class implements the functionality needed to walk an
 * HTL program.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
abstract class HTLProgramWalker {

	private SymbolTable symbolTable;
	private InheritTable inheritTable; 
	
	public HTLProgramWalker(SymbolTable pSymbolTable){
		symbolTable = pSymbolTable;
	}
	
	public HTLProgramWalker(SymbolTable pSymbolTable, InheritTable pInheritTable){
		symbolTable = pSymbolTable;
		inheritTable = pInheritTable;
	}
	
	public void walk() throws ExotaskValidationException{
		walkPrograms();
	}
	
	public void walkDepFirst() throws ExotaskValidationException{
		walkDepFirst(symbolTable.getProgram(symbolTable.rootProgram));
	}
	
	/**
	 * Walk through the HTL program depth first.
	 */
	private void walkDepFirst(HTLProgram P) throws ExotaskValidationException{
		inAProgram(P);
		Map modules = symbolTable.getModulesInProgram(P.getName());
		walkModules(P, modules);
		
		ArrayList childrens = (ArrayList)inheritTable.programChildren.get(P.getName());
		
		if(childrens != null){
			Iterator itPrograms = childrens.iterator();
			while(itPrograms.hasNext()){
				HTLProgram child = (HTLProgram)itPrograms.next();
				walkDepFirst(child);
			}
		}
		outAProgram(P);
	}
	
	/**
	 * Walk through the HTL program.
	 */
	private void walkPrograms() throws ExotaskValidationException{
		Iterator itPrograms = symbolTable.programs.values().iterator();
		while(itPrograms.hasNext()){
			HTLProgram P = (HTLProgram)itPrograms.next();
			Map modules = symbolTable.getModulesInProgram(P.getName());
			
			inAProgram(P);
			
			walkModules(P, modules);
			
			outAProgram(P);
		}
	}

	/**
	 * Walk through the modules of a program
	 * @param P
	 * @param modules
	 */
	private void walkModules(HTLProgram P, Map modules) throws ExotaskValidationException{
		Iterator itModules = modules.values().iterator();
		while(itModules.hasNext()){
			HTLModule M = (HTLModule)itModules.next();
			Map modes = symbolTable.getModesInModule(M.getName());
			
			inAModule(P, M);
			
			walkModes(P, M, modes);
			
			outAModule(P, M);
		}
	}
	
	/**
	 * Walk through the modes of a module
	 * @param P
	 * @param M
	 * @param modes
	 */
	private void walkModes(HTLProgram P, HTLModule M, Map modes) throws ExotaskValidationException{
		Iterator itModes = modes.values().iterator();
		while(itModes.hasNext()){
			HTLMode m = (HTLMode)itModes.next();
			Map tasks = symbolTable.getTasksInMode(m.getName());
			Map predicates = symbolTable.getPredicatesInMode(m.getName());
			Map connections = symbolTable.getConnectionsInMode(m.getName());
			
			inAMode(P, M, m);
			walkTasks(P, M, m, tasks);
			walkPredicates(P, M, m, predicates);
			walkConnections(P, M, m, connections);
			outAMode(P, M, m);
		}
	}
	
	/**
	 * Walk through the tasks of a mode
	 * @param P
	 * @param M
	 * @param m
	 */
	private void walkTasks(HTLProgram P, HTLModule M, HTLMode m, Map tasks ) throws ExotaskValidationException{
		
		if(tasks == null)
			return;
		
		Iterator itTasks = tasks.values().iterator();
		while(itTasks.hasNext()){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)itTasks.next();
			
			inATask(P, M, m, t);
			outATask(P, M, m, t);
		}
	}
	
	/**
	 * Walk through the predicates of a mode
	 * @param P
	 * @param M
	 * @param m
	 */
	private void walkPredicates(HTLProgram P, HTLModule M, HTLMode m, Map predicates) throws ExotaskValidationException{
		if(predicates == null)
			return;
		
		Iterator itPredicates = predicates.values().iterator();
		while(itPredicates.hasNext()){
			ExotaskPredicateSpecification p = (ExotaskPredicateSpecification)itPredicates.next();
			
			inAPredicate(P, M, m, p);
			outAPredicate(P, M, m, p);
		}
	}
	
	/**
	 * Walk through the connections of a mode
	 * @param P
	 * @param M
	 * @param m
	 */
	private void walkConnections(HTLProgram P, HTLModule M, HTLMode m, Map connections) throws ExotaskValidationException{
		if(connections == null)
			return;
		Iterator itConnections = connections.values().iterator();
		while(itConnections.hasNext()){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)itConnections.next();
			
			inAConnection(P, M, m, c);
			outAConnection(P, M, m, c);
		}
	}
	
	/**
	 * This method will be called when an HTL program is reached.
	 * @param P
	 */
	protected void inAProgram(HTLProgram P) throws ExotaskValidationException{}
	
	/**
	 * This method will be called when living an HTL program.
	 * @param P
	 */
	protected void outAProgram(HTLProgram P) throws ExotaskValidationException{}
	
	/**
	 * This method will be called when an HTL module will be reached
	 * @param P
	 * @param M
	 */
	protected void inAModule(HTLProgram P, HTLModule M) throws ExotaskValidationException{}
	
	/**
	 * This method will be called when an HTL module is left
	 * @param P
	 * @param M
	 */
	protected void outAModule(HTLProgram P, HTLModule M) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a mode is reached
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void inAMode(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a mode will be left.
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void outAMode(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a task is reached
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void inATask(HTLProgram P, HTLModule M, HTLMode m, ExotaskTaskSpecification t) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a task will be left.
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void outATask(HTLProgram P, HTLModule M, HTLMode m, ExotaskTaskSpecification t) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a connection is reached
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void inAConnection(HTLProgram P, HTLModule M, HTLMode m, ExotaskConnectionSpecification c) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a connection will be left.
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void outAConnection(HTLProgram P, HTLModule M, HTLMode m, ExotaskConnectionSpecification c) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a predicate is reached
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void inAPredicate(HTLProgram P, HTLModule M, HTLMode m, ExotaskPredicateSpecification p) throws ExotaskValidationException{}
	
	/***
	 * This method will be called when a predicate will be left.
	 * @param P
	 * @param M
	 * @param m
	 */
	protected void outAPredicate(HTLProgram P, HTLModule M, HTLMode m, ExotaskPredicateSpecification p) throws ExotaskValidationException{}
	
	//	utiliti methods
	/**
	 * Add a child for the specified name. 
	 */
	protected void addToMapOfLists(Map pMap, String pName, Object pObject){
		ArrayList children;
		if(pMap.containsKey(pName))
			children = (ArrayList)pMap.get(pName);
		else{
			children = new ArrayList();
			pMap.put(pName, children);
		}
		
		if(!children.contains(pObject))
			children.add(pObject);
	}
	
	/***
	 * Add a parent for the specified name.
	 * @param pMap
	 * @param pName
	 * @param pParent
	 */
	protected void addToMap(Map pMap, String pName, Object pParent){
		pMap.put(pName, pParent);
	}
}
