/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling;

import com.ibm.realtime.exotasks.ExotaskController;
import com.ibm.realtime.exotasks.scheduling.ExotaskSchedulerRunnable;

/**
 * This class represents a task that will be
 * started from the ECodeRunner.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class Task extends ExotaskSchedulerRunnable {

	/***
	 * The index of the ExotaskTask being mapped to this runnable.
	 */
	private int taskIndex=-1;
	
	/**
	 * The functionality code that has to be executed.
	 */
	private Runnable task;
	
	/**
	 * Flag indicating that the task is running.
	 */
	private boolean running; 
	
	/**
	 * Thios memeber will help build a list of IDLE tasks
	 */
	private Task nextIdleTask;
	
	/**
	 * The set of task to which this task belongs.
	 */
	private TaskSet taskSet;
	
	/**
	 * The callback method that will be called when a task has completed.
	 */
	private ITaskCompletionCallback iTaskCompletionCallback;
	
	public Task(ITaskCompletionCallback pCompletionCallback){
		iTaskCompletionCallback = pCompletionCallback;
		running = true;
		nextIdleTask = null;
	}
	
	/***
	 * Get the next IDLE tasks.
	 * @return
	 */
	public Task getNextIdleTask(){
		return nextIdleTask;
	}
	
	/***
	 * Set the next IDLE tasks.
	 * @return
	 */
	public void setNextIdleTask(Task nextIdleTask){
		this.nextIdleTask = nextIdleTask;
	}
	
	/**
	 * Get the set of tasks.
	 * @return
	 */
	public TaskSet getTaskSet(){
		return taskSet;
	}
	
	/**
	 * Set the set of tasks
	 * @param taskSet
	 */
	public void setTaskSet(TaskSet taskSet){
		this.taskSet = taskSet;
	}
	
	/**
	 * Get the index of the task being executed by this Task.
	 * @return
	 */
	public int getTaskIndex(){
		return taskIndex;
	}
	
	/**
	 * Set the index of the task being executed by this Task.
	 */
	public void setTaskIndex(int pIdx){
		taskIndex = pIdx;
	}
	
	/**
	 * Get the exotask controller representing the running task.
	 * @return
	 */
	public Runnable getTask(){
		return task;
	}
	
	/**
	 * Set the exotask controller representing the running task.
	 */
	public void setTask(Runnable pTask){
		task = pTask;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		try{
			while(running){
				synchronized (this){
					this.wait();
				}
				
				if(task!=null){
					//execute the runnable
					if(task instanceof ExotaskController){
						//this is a normal task
						ExotaskController controller = (ExotaskController)task;
						
						controller.collect();
						controller.run();
				
						iTaskCompletionCallback.taskCompleted(taskIndex);
						
						//clear task
						controller = null;
						taskIndex = -1;
						taskSet.freeTask(this);
					}
					else{
						//this is the emachine tasks
						task.run();
					}
				}
			}
		}
		catch(InterruptedException e){
			running = false;
		}
	}
	
	/**
	 * Stop the E code task.
	 *
	 */
	public void stop(){
		if(running){
			running = false;
			synchronized (this){
				this.notify();
			}
		}
	}

}