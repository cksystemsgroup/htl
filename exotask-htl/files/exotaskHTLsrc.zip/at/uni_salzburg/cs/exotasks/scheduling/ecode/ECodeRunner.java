/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.ArrayList;

import at.uni_salzburg.cs.exotasks.scheduling.ITaskCompletionCallback;
import at.uni_salzburg.cs.exotasks.scheduling.MultiThreadingSchedule;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Call;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.CleanChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.CopyChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.CopyRegister;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.DeleteChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Future;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.GetParent;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Instruction;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.JumpAbsolute;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.JumpIf;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.JumpSub;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.PopRegister;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.PushRegister;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.RFuture;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Release;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.ReplaceChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.Return;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.SFuture;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.SetParent;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.SetParentOfChildren;
import at.uni_salzburg.cs.exotasks.scheduling.ecode.instructions.WFuture;
import at.uni_salzburg.cs.exotasks.scheduling.utils.DoubleLinkedList;
import at.uni_salzburg.cs.exotasks.scheduling.utils.DoubleLinkedStack;
import at.uni_salzburg.cs.exotasks.scheduling.utils.MultiLinkEelement;
import at.uni_salzburg.cs.exotasks.scheduling.utils.PoolOfElements;

import com.ibm.realtime.exotasks.ESystem;
import com.ibm.realtime.exotasks.ExotaskController;
import com.ibm.realtime.exotasks.ExotaskPredicateController;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * The Runner for the ECode scheduler.  Uses the ExotaskSingleThreadRunner
 *   convenience class for now (eventually, this scheduler should be
 *   multi-threaded and preemptive).
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 */
public class ECodeRunner extends MultiThreadingSchedule {

  private final int slowDownFactor;
  
  private static final int FREE_INDEX = 0;
  private static final int QUEUE_INDEX = 1;
  private static final int CHILDREN_INDEX = 2;
  private static final int PARENT_STACK_INDEX = 3;
  private static final int LINK_SIZE = 4; 
	
  /**Contains the list of runnables that implement the tasks*/
  private final ArrayList tasks;

  /**Contains the list of runnables that implement connections*/
  private final ArrayList drivers;
  
  /**Contains the list of runnables that implement predicates*/
  private final ArrayList predicates;

  /** The generated e code */
  private final ArrayList instructions;

  /** The current instruction pointer (may be -1 after return from a block).  Will be zero
   *   at super-period boundaries (I think: JSA). */
  private int IP;
  
  /**List of free triggers*/
  private PoolOfElements freeTriggers;
  
  /**Write queue.*/
  private DoubleLinkedList wqueue;
  
  /**Switch queue.*/
  private DoubleLinkedList squeue;
  
  /**Read queue.*/
  private DoubleLinkedList rqueue;
  
  /**Stack of parents*/
  private DoubleLinkedStack parentStack;
  
  /**A stack of addresses used to support SUB instruction*/
  private StackOfAddresses stackOfAddresses;
  
  /**List of trigger register*/
  private TriggerElement[] R;
  
  /**Temporary register*/
  private TriggerElement Rx;
  
  /**Temporary register*/
  private TriggerElement Ry;
  
  /**Temporary register*/
  private TriggerElement Rz;
  
  /** The system clock time.  Reinitialized on each fresh run and also when examining trigger queue */
  private long clocktime;
  
  /**The maximum number of tasks.*/
  private int maxTasks;
  
  /**The smallest period between to time events.*/
  private long smallestPeriod;
  
  /**This memeber will contain null if no active trigger was foud,
   * otherwise it will contain the found active trigger.*/
  private TriggerElement activeTrigger;
  
  /**Active trigger queue*/
  private DoubleLinkedList activeQueue;
      
  public ECodeRunner(ArrayList pInstructions, ArrayList pTasks, ArrayList pDrivers, ArrayList pPredicates, int maxTasks, long smallestPeriod, int slowDownFactor)
  {
	int maxTriggers = 0;
	this.slowDownFactor = slowDownFactor;
	//count future instructions
	for(int i=0; i<pInstructions.size(); i++){
		if(pInstructions.get(i) instanceof Future){
			maxTriggers++;
		}
	}
	
	//instantiate the four registers: R0, R1, R2, R3
	R = new TriggerElement[4];
	freeTriggers = new PoolOfElements(FREE_INDEX, maxTriggers+1, LINK_SIZE, TriggerElement.class);
    instructions = pInstructions;
    tasks = pTasks;
    drivers = pDrivers;
    predicates = pPredicates;
    wqueue = new DoubleLinkedList(QUEUE_INDEX);
    squeue = new DoubleLinkedList(QUEUE_INDEX);
    rqueue = new DoubleLinkedList(QUEUE_INDEX);
    parentStack = new DoubleLinkedStack(PARENT_STACK_INDEX);
    stackOfAddresses = new StackOfAddresses();
    this.smallestPeriod = smallestPeriod*slowDownFactor;
    this.maxTasks = maxTasks; 
  }
  
  /**
   * Get the maximum number of tasks
   */
  protected int getMaxTasks(){
	  return maxTasks;
  }
	
  /**
   * Get the completion event handler.
   */
  protected ITaskCompletionCallback getComplitionCallback(){
	  return new TaskCompletionCallback(rqueue);
  }
  
  protected void startSchedule(){
	  /* Get initial clocktime for any fresh run (initially or after a period of being stopped) */
	clocktime = nanoTime();
	IP = 0;
	
	wqueue.reset();
	rqueue.reset();
	squeue.reset();
	parentStack.reset();
	freeTriggers.reset();
	stackOfAddresses.clear();
	resetRegister();
	R[0] = (TriggerElement)freeTriggers.getElement();
	R[0].reset();
  }
  
  /**
   * Reset registers
   *
   */
  private void resetRegister(){
	  R[0] = null;
	  R[1] = null;
	  R[2] = null;
	  R[3] = null;
  }
  
  // @see com.ibm.realtime.exotasks.scheduling.ExotaskSingleThreadRunner#runExotasks()
  public void schedule(){
   	    
	    try{
		    
	      if(IP > -1){
	    	  interpretECode();
	      }else{ /* Last instruction was a return.  Get something from trigger queue */
	        checkTriggers();
	      }
	      //debugln("End while.");
    }
    catch(ExotaskValidationException e){
    	terminateWith(e);
    }
    catch(Throwable e){
    	terminateWith(e);
    }
  }

  /**
   * This method implements an E Code interpreter
   *
   */
  public void interpretECode() throws ExotaskValidationException{
	  //debugln(IP);
	  
	  Instruction instr = (Instruction)instructions.get(IP++);
      
      //execute current instruction
      switch(instr.getCode()){
      case Call.CODE:
          //call
          //debugln("CALL");
          Call call = (Call)instr;
          Runnable driver = (Runnable)drivers.get(call.getDriver());
          driver.run();
          break;
      case Release.CODE:
          //release
          //debugln("RELEASE");
          Release release = (Release)instr;
          ExotaskController task = (ExotaskController)tasks.get(release.getTask());
          
          //schedule the task
          try{
        	  releaseTask(task, release.getTask());
          }
          catch(Exception e){
        	  ESystem.err.println("Deadline violation");
        	  getComplitionCallback().taskCompleted(release.getTask());
          }
          break;
      case WFuture.CODE:
          //wfuture instruction
          WFuture wf = (WFuture)instr;
          //debugln("WFUTURE");
          TriggerElement wtrigger = getFreeTrigger();
          wtrigger.setValues(wf.getTime(), wf.getDependency(), wf.getAddress());
          R[1] = wtrigger;
          wqueue.add(wtrigger);
          break;
      case SFuture.CODE:
          //sfuture instruction
          SFuture sf = (SFuture)instr;
          //debugln("SFUTURE");
          TriggerElement strigger = getFreeTrigger();
          strigger.setValues(sf.getTime(), sf.getDependency(), sf.getAddress());
          R[1] = strigger;
          squeue.add(strigger);
          break;
      case RFuture.CODE:
          //rfuture instruction
          RFuture rf = (RFuture)instr;
          //debugln("RFUTURE");
          TriggerElement rtrigger = getFreeTrigger();
          rtrigger.setValues(rf.getTime(), rf.getDependency(), rf.getAddress());
          R[1] = rtrigger;
          rqueue.add(rtrigger);
          break;
      case JumpIf.CODE:
		  JumpIf i = (JumpIf)instr;
		  //debugln("IF");
		  ExotaskPredicateController p = (ExotaskPredicateController)predicates.get(i.getCondition());
		  p.collect();
		  p.run();
		  if(p.isTrue()){
			  //jump to the true address
			  IP = i.getAddress();
		  }
		  break;
      case JumpAbsolute.CODE:
    	  //debugln("JUMP");
    	  IP = ((JumpAbsolute)instr).getAddress();
    	  break;
      case JumpSub.CODE:
        	//debugln("SUB");
        	JumpSub sub = (JumpSub)instr;
        	stackOfAddresses.pushAddress(IP);
        	IP = sub.getAddress();
        	break;
      case CopyRegister.CODE:
    	  //debugln("COPY REGISTER");
    	  CopyRegister cpReg = (CopyRegister)instr;
    	  R[cpReg.Ry] = R[cpReg.Rx];
    	  break;
      case PushRegister.CODE:
        	//debugln("PUSH REGISTER");
        	PushRegister pushR = (PushRegister)instr;
        	Rx = R[pushR.Rx];
        	if(Rx!=null)
        		parentStack.push(Rx);
        	else
        		debugln("PUSH NULL REGISTER");
        	break;
      case PopRegister.CODE:
	      	//debugln("POP REGISTER");
	      	PopRegister popR = (PopRegister)instr;
	      	if(!parentStack.isEmpty()){
	      		R[popR.Rx] = (TriggerElement)parentStack.pop();
	      	}
	      	else{
	      		R[popR.Rx] = null;
	      	}
	      	break;
      case GetParent.CODE:
    	  //debugln("GET PARENT");
    	  GetParent getParent = (GetParent)instr;
    	  Rx = R[getParent.Rx];
    	  if(Rx!=null)
    		  R[getParent.Ry] = Rx.parent;
    	  else
    		  R[getParent.Ry] = null;
    	  break;
      case SetParent.CODE:
    	  //debugln("SET PARENT");
    	  SetParent setParent=(SetParent)instr;
    	  Rx = R[setParent.Rx];
    	  if(Rx!=null)
    		  Rx.parent = R[setParent.Ry];
    	  break;
      case CopyChildren.CODE:
    	  //debugln("COPY CHILDREN");
    	  CopyChildren copyChildren = (CopyChildren)instr;
    	  Rx = R[copyChildren.Rx];
    	  Ry = R[copyChildren.Ry];
    	  if(Rx!=null){
    		  if(Ry!=null)
    			  Rx.children.copy(Ry.children);
    		  else
    			  Rx.children.reset();
    	  }
    	  break;
      case SetParentOfChildren.CODE:
    	  //debugln("Set parent of children");
    	  SetParentOfChildren spoChildren = (SetParentOfChildren)instr;
    	  Rx = R[spoChildren.Rx];
    	  Rz = R[spoChildren.Ry];
    	  if(Rx!=null){
    		  Ry = (TriggerElement)Rx.children.getHead();
    		  while(Ry!=null){
    			  Ry.parent = Rz;
    			  Ry = (TriggerElement)Rx.children.getNext(Ry);
    		  }
    	  }
    	  break;
      case DeleteChildren.CODE:
    	  //debugln("DELETE CHILDREN");
    	  DeleteChildren delCh = (DeleteChildren)instr;
    	  Rx = R[delCh.Rx];
    	  if(Rx != null)
    		  deleteChildren(Rx.children);    	  
    	  break;
      case ReplaceChildren.CODE:
    	 // debugln("REPLACE CHILDREN");
    	  ReplaceChildren rpChildren = (ReplaceChildren)instr;
    	  Rx = R[rpChildren.Rx];
    	  Ry = R[rpChildren.Ry];
    	  Rz = R[rpChildren.Rz];
    	  if(Rx!=null){
    		  if(Ry!=null && !Rx.children.isEmpty()){
    			  Rx.children.remove(Ry);    				  
    		  }
    		  if(Rz!=null){
    			  Rx.children.add(Rz);
    		  }
    	  }
    	  break;
      case CleanChildren.CODE:
    	  //debugln("CLEAN CHILDREN");
    	  CleanChildren cleanCh = (CleanChildren)instr;
    	  Rx = R[cleanCh.Rx];
    	  if(Rx!=null)
    		  Rx.children.reset();
    	  break;
      case Return.CODE:
          //return
          //debugln("RETURN");
          if(stackOfAddresses.isEmpty()){
        	  IP = -1;
        	  freeTriggers.freeElement(R[0]);
        	  resetRegister();
          }
          else
        	  IP = stackOfAddresses.popAddress();
          break;
      default:
      	debugln("Unknown instruction.");
      	break;
      }
      //debugln("End execute instruction.");
  }
  
  /**
   * Get a free trigger
   * @return
   */
  private TriggerElement getFreeTrigger(){
	  TriggerElement trigger = (TriggerElement) freeTriggers.getElement();
	  debug("Triggers: ");
	  debug(freeTriggers.getUsedElementsSize());
	  debug(" / ");
	  debugln(freeTriggers.getSize()+freeTriggers.getUsedElementsSize());
	  return trigger;
  }
  
  /**
   * Delete recursevly all the triggers
   * @param children
   */
  private void deleteChildren(DoubleLinkedList children){
	  TriggerElement t1,t2;
	  if(children!=null){
		  t1 = (TriggerElement)children.getHead();
		  while(t1!=null){
			  t2 = (TriggerElement)children.getNext(t1);
			  deleteChildren(t1.children);
			  squeue.remove(t1);
			  children.remove(t1);
			  freeTriggers.freeElement(t1);
			  t1 = t2;
		  }
	  }
	  
  }
    
  private void checkTriggers(){
      //debugln("Check triggers...");
      
      //update triggers
      long newtime = nanoTime();
      activeTrigger = null;
      activeQueue = null;
      long timeToWait = updateTriggerTime(wqueue, (newtime - clocktime)/slowDownFactor, Long.MAX_VALUE);
      timeToWait = updateTriggerTime(squeue, (newtime - clocktime)/slowDownFactor, timeToWait);
      timeToWait = updateTriggerTime(rqueue, (newtime - clocktime)/slowDownFactor, timeToWait);
      
  	  long msTime = (timeToWait>0)? timeToWait*slowDownFactor/1000000L : smallestPeriod/1000000L;
  	  int nsTime = (int)((timeToWait>0)? timeToWait*slowDownFactor%1000000L : smallestPeriod%1000000L);
      clocktime = newtime;
        
      if(activeTrigger != null){
    	//there is an active trigger
        debugln("Active trigger was found");
        IP = activeTrigger.address;
        activeQueue.remove(activeTrigger);
        R[0] = activeTrigger;
        activeTrigger = null;
      } else {
    	debugln("No active trigger was found");    
    	try{
        	synchronized(squeue){
        		if(timeToWait == 0){
        			// there is either no trigger in the trigger queue,
        			//or all the triggers depend only on task complition events.
        			squeue.wait();
        		}
        		else{
        			//wait until the smallest period on which a trigger depends 
        			// has elapsed
        			squeue.wait(msTime, nsTime);
        		}
        	}
    	}
    	catch(Exception e){
    		debugln("Ouch!");
    	}
     }
     debugln("End checking triggers.");
  }
  
  private void terminateWith(Throwable e) {
		if (e instanceof Error) {
			throw (Error) e;
		} else if (e instanceof RuntimeException) {
			throw (RuntimeException) e;
		} else {
			throw new IllegalStateException(e);
		}
	}

  /**
   * Update triggers time. This method will return the smalest non zero amount of
   * time that has to elapse util a new trigger might become active. If zero is 
   * return this means either that for all the triggers the time has elapsed, or
   * there is no trigger in the trigger queue. The function will also set the 
   * activeTrigger memeber to the first active trigger that was found.
   * @param pQueue the trigger queue
   * @param pTime the amount of time (nanos) that's elapsed since the last update
   * @return the number of nanoseconds until any trigger will fire
   */
  private long updateTriggerTime(DoubleLinkedList pQueue, long pTime, long timeToWait){
    long ans = timeToWait;
    //reset the active trigger
    for(TriggerElement trigger = (TriggerElement) pQueue.getHead();
        trigger != null;
        trigger = (TriggerElement) pQueue.getNext(trigger)) {
      //take each trigger in the trigger queue
    	
      //updte time of the trigger
      trigger.time -= pTime;
      if(trigger.time < 0){
    	//time can not be less the ZERO
        trigger.time = 0;
      }
      if (trigger.time < ans && trigger.time > 0) {
    	//consider only values greater then zero.
        ans = trigger.time;
      }
      
      //check to see if trigger is active
      if(trigger.time == 0 && trigger.dependencyList == 0 && activeTrigger==null) {
	    activeTrigger = trigger;
	    activeQueue = pQueue;
	  }
    }
    
    if(ans == Long.MAX_VALUE){
    	//no trigger was found for which the time has not expired yet
    	ans = 0;
    }
    
    return ans;
  }
    
  /////////////////////////////////////////
  //                MISC                 //
  /////////////////////////////////////////
  static class TriggerElement extends MultiLinkEelement {
   	public long time;
    public long dependencyList;
    public int address;
    public DoubleLinkedList children;
    public TriggerElement parent;

    public TriggerElement(Integer noOfLinks) {
		super(noOfLinks);
		children = new DoubleLinkedList(CHILDREN_INDEX);
	}
    
    public void setValues(long pTime, long pDepList, int pAddress){
      time = pTime;
      dependencyList = pDepList;
      address = pAddress;
      parent = null;
      children.reset();
    }
    
    public void reset(){
    	super.reset();
    	parent = null;
    	children.reset();
    	time = 0;
    	dependencyList = 0;
    	address = -1;
    }
    
    public String toString(){
    	return "Address="+address+", Time="+time+", Dependency="+dependencyList;
    }
  }
  
  private static class StackOfAddresses{
	  /**The maximum number of elements in the stack*/
	  public static final int MAX_SIZE = 100;
	  
	  /**An array of inteners containing the stack data*/
	  private final int[] addresses;
	  
	  /**Pointer that marks the TOP of the stack*/
	  private int stackPointer;
	  
	  /**
	   * Create a new empty stack that can hold up to MAX_SIZE elements
	   *
	   */
	  public StackOfAddresses(){
		  addresses = new int[MAX_SIZE];
		  stackPointer = -1;
	  }
	  
	  /***
	   * 
	   * @return true if the stack is empty.
	   */
	  public boolean isEmpty(){
		  return stackPointer == -1;
	  }
	  
	  /**
	   * Push a new data on the stack
	   * @param pAddress
	   * @throws ExotaskValidationException
	   */
	  public void pushAddress(int pAddress) throws ExotaskValidationException{
		  if(stackPointer == MAX_SIZE-1)
			  throw new ExotaskValidationException("StackOfAddresses overflow.");
		  addresses[++stackPointer] = pAddress;
	  }
	  
	  /**
	   * Pop an element from the stack
	   * @return
	   * @throws ExotaskValidationException
	   */
	  public int popAddress() throws ExotaskValidationException{
		  if(stackPointer == -1)
			  throw new ExotaskValidationException("StackOfAddresses is empty.");
		  return addresses[stackPointer--];
	  }
	  
	  public void clear(){
		  stackPointer = -1;
	  }
  }
}

