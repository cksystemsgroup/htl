/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLCommunicatorAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLConnectionAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLExotaskGraphAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeAssignment;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeSwitch;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLTaskAnnotation;

import com.ibm.realtime.exotasks.specification.ExotaskCommunicatorSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskPredicateSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 * 
 * This class represents the symbol table for an Exotask Grapth
 * annotated with HTL grammer
 **/
class SymbolTable {
	//a map of programs to search faster for programs by name
	public final Map programs = new HashMap();
	
	//a map of modules to search faster for modules by name
	public final Map modules = new HashMap();
	
	//a map of modes to search faster for modes by name
	public final Map modes = new HashMap();
	
	//map a module to a program
	public final Map modulesInProgram = new HashMap();
	
	//	map a communicator to a program
	public final Map communicatorsInProgram = new HashMap();
	
	//map a mode to a module
	public final Map modesInModule = new HashMap(); 
	
	//this Map contains an entry for each mode
	//the entry represents the map of tasks that are part of the mode
	public final Map tasksInMode = new HashMap();
	
	//this Map contains an entry for each connection
	//the entry represents the map of connections that are part of the mode
	public final Map connectionsInMode = new HashMap();
		
	//this Map contains an entry for each mode
	//the entry represents the map of predicates that are part of the mode
	public final Map predicatesInMode = new HashMap();
	
	//the name of the root program
	public String rootProgram;
	
	//the maximum number of tasks running in paralele
	public int maxRunningTasks;
	
	public SymbolTable(ExotaskGraphSpecification toSchedule) throws ExotaskValidationException{
		
		Set rootPrograms = new HashSet(); //we consider that all thye programs are root
								//as we find that a program refines anode we remove that
								//program from this set
		
		//create the map of programs
		HTLProgram P;
		Iterator itPrograms =((HTLExotaskGraphAnnotation)toSchedule.getTimingData()).getHTLProgramList().getPrograms().iterator(); 
		while(itPrograms.hasNext()){
			P = (HTLProgram)itPrograms.next();
						
			if(this.programs.containsKey(P.getName())){
				throw new ExotaskValidationException("Duplicate programs - " + P.getName());
			}
			else{
				this.programs.put(P.getName(), P);
			}
			
			rootPrograms.add(P.getName());
		}
		
		//create moduleInProgram map
		HTLModule M;
		Iterator itModules =((HTLExotaskGraphAnnotation)toSchedule.getTimingData()).getHTLModuleList().getModules().iterator(); 
		while(itModules.hasNext()){
			M = (HTLModule)itModules.next();
			
			validateModule(M);
			
			//get/create the list of modules
			Map modules;
			if(modulesInProgram.containsKey(M.getProgram())){
				modules = (HashMap)modulesInProgram.get(M.getProgram());
			}
			else{
				//create a new set
				modules = new HashMap();
				modulesInProgram.put(M.getProgram(), modules);
			}
			
			if(this.modules.containsKey(M.getName())){
				throw new ExotaskValidationException("Duplicate modules - " + M.getName());
			}
			else{
				this.modules.put(M.getName(), M);
			}
			
			modules.put(M.getName(), M);
		}
		
		//create modesInModule map
		HTLMode m;
		Iterator itModes =((HTLExotaskGraphAnnotation)toSchedule.getTimingData()).getHTLModeList().getModes().iterator(); 
		while(itModes.hasNext()){
			m = (HTLMode)itModes.next();
			
			if(rootPrograms.contains(m.getRefineProgram())){
				//remove the refining program from the
				//set of root programs
				rootPrograms.remove(m.getRefineProgram());
			}
			
			//get/create the list of modes
			Map modes;
			if(modesInModule.containsKey(m.getModule())){
				modes = (HashMap)modesInModule.get(m.getModule());
			}
			else{
				//create a new set
				modes = new HashMap();
				modesInModule.put(m.getModule(), modes);
			}
			modes.put(m.getName(), m);
			
			if(this.modes.containsKey(m.getName())){
				throw new ExotaskValidationException("Duplicate mode - " + m.getName());
			}
			else{
				this.modes.put(m.getName(), m);
			}
			
			validateMode(m);
		}
		
		//there has to be one and only one root program
		if(rootPrograms.size() != 1){
			throw new ExotaskValidationException("There has to be one and only one root program.");
		}
		rootProgram = (String)rootPrograms.toArray()[0];
		
		//create the amp of modules
		itModules =((HTLExotaskGraphAnnotation)toSchedule.getTimingData()).getHTLModuleList().getModules().iterator(); 
		while(itModules.hasNext()){
			M = (HTLModule)itModules.next();
			
			//check if the start mode exists
			Map modes = (Map)modesInModule.get(M.getName());
			
			if(modes == null || !modes.containsKey(M.getStartMode())){
				throw new ExotaskValidationException("The module '" + M.getName() + "' does not contains the mode '"+
						M.getStartMode() + "' which is declared as the start mode.");
			}
		}
		
		Iterator itTasks = toSchedule.getTasks().iterator();
		while(itTasks.hasNext()){
			Object o = itTasks.next();
			if (o instanceof ExotaskPredicateSpecification) {
				//update the list of predicates
				ExotaskPredicateSpecification p = (ExotaskPredicateSpecification) o;
				
				HTLModeSwitch  sw = (HTLModeSwitch)p.getTimingData();
				
				if(sw == null){
					throw new ExotaskValidationException("No mode switch was specified for predicate '"+p.getName()+"'");
				}
				
				validatePredicate(p);
				
				//get/create the list of predicates
				for(int i=0; i<sw.getModes().size(); i++){
					Map predicates;
					String modeName = ((HTLModeAssignment)sw.getModes().get(i)).getMode();
					if(predicatesInMode.containsKey(modeName)){
						predicates = (HashMap)predicatesInMode.get(modeName);
					}
					else{
						//create a new set
						predicates = new HashMap();
						predicatesInMode.put(modeName, predicates);
					}
					predicates.put(p.getName(), p);
				}
			}
			else if (o instanceof ExotaskCommunicatorSpecification) {
				//jump over exotask communicator specification
				validateCommunicator((ExotaskCommunicatorSpecification)o);
				
				HTLCommunicatorAnnotation c = (HTLCommunicatorAnnotation)((ExotaskCommunicatorSpecification)o).getTimingData();
				
				//get/create the list of communicators
				Map communicators;
				if(communicatorsInProgram.containsKey(c.getProgram())){
					communicators = (HashMap)communicatorsInProgram.get(c.getProgram());
				}
				else{
					//create a new set
					communicators = new HashMap();
					communicatorsInProgram.put(c.getProgram(), communicators);
				}
				
				communicators.put(((ExotaskCommunicatorSpecification)o).getName(), o);
			}
			else{
				ExotaskTaskSpecification t = (ExotaskTaskSpecification)o;
				HTLTaskAnnotation taskAnnot = (HTLTaskAnnotation)t.getTimingData();
				if(taskAnnot == null){
					//invalid task
					throw new ExotaskValidationException("No mode was specified for task '"+t.getName()+"'");
				}
				
				for(int i=0; i<taskAnnot.getModes().size(); i++){
					
					HTLModeAssignment invoc = (HTLModeAssignment)taskAnnot.getModes().get(i);
					
					//check if mode was declared
					if(!modes.containsKey(invoc.getMode()))
						throw new ExotaskValidationException("Task '"+t.getName()+"' is invoked in mode '"+
								invoc.getMode()+"' but the mode was not defined.");
					
					if(i > 0){
						//check if the task is invoked in modes from different modules
						HTLModeAssignment prevInvoc = (HTLModeAssignment)taskAnnot.getModes().get(i-1);
						HTLMode m1 = (HTLMode)modes.get(invoc.getMode());
						HTLMode m2 = (HTLMode)modes.get(prevInvoc.getMode());
						
						if(!m1.getModule().equals(m2.getModule()))
							throw new ExotaskValidationException("Task '"+t.getName()+
									"' is invoked in modes from different modules");
					}
					
					//	get/create the list of tasks
					Map tasks;
					if(tasksInMode.containsKey(invoc.getMode())){
						tasks = (Map)tasksInMode.get(invoc.getMode());
					}
					else{
						//create a new set
						tasks = new HashMap();
						tasksInMode.put(invoc.getMode(), tasks);
					}
					if(tasks.containsKey(t.getName()))
						throw new ExotaskValidationException("Task '"+t.getName()+
								"' is invoked twice in the same mode '" + invoc.getMode() + "'");
					else
						tasks.put(t.getName(), t);
				}
			}
		}
		
		Iterator itConn = toSchedule.getConnections().iterator();
		while(itConn.hasNext()){
			Object o = itConn.next();
			ExotaskConnectionSpecification conn = (ExotaskConnectionSpecification)o;
			HTLConnectionAnnotation connAnnot = (HTLConnectionAnnotation)conn.getTimingData();
			
			if(connAnnot == null){
				//invalid connection
				throw new ExotaskValidationException("No mode was specified for connection '"+conn.getName()+"'");
			}
			
			validateConnection(conn);
			
			for(int i=0; i<connAnnot.getModes().size(); i++){
				String modeName = ((HTLModeAssignment)connAnnot.getModes().get(i)).getMode();
				
				//get/create the list of connections
				Map connections;
				if(connectionsInMode.containsKey(modeName)){
					connections = (Map)connectionsInMode.get(modeName);
				}
				else{
					//create a new set
					connections = new HashMap();
					connectionsInMode.put(modeName, connections);
				}
				connections.put(conn.getName(), conn);
			}
		}
		
		maxRunningTasks = getMaxTaskNumberInProgram();
	}
	
	/***
	 * Get the maximum number of tasks running in paralel.
	 * @return
	 */
	public int getMaxRunningTasks(){
		return maxRunningTasks;
	}
	
	/***
	 * Get the maximum number of tasks running in paralele in the HTL program.
	 * @return
	 */
	private int getMaxTaskNumberInProgram(){
		Map rootModules = (Map)modulesInProgram.get(rootProgram);
		int noTasks = 0;
		
		Iterator moduleIT = rootModules.values().iterator();
		while(moduleIT.hasNext()){
			HTLModule module = (HTLModule)moduleIT.next();
			noTasks += getMaxTaskNumberInModule(module);
		}
		
		return noTasks;
	}
	
	/***
	 * Find the maximum number of tasks running in paralel in the specified module.
	 * @param module
	 * @return
	 */
	private int getMaxTaskNumberInModule(HTLModule module){
		int noTasks = 0;
		
		Map rootModes = (Map)modesInModule.get(module.getName());
		
		Iterator modesIT = rootModes.values().iterator();
		while(modesIT.hasNext()){
			HTLMode m = (HTLMode)modesIT.next();
			Map tasks = (Map)tasksInMode.get(m.getName());
			if(tasks!=null && noTasks < tasks.size()){
				noTasks = tasks.size();
			}
		}
		
		return noTasks;
	}

	private void validateMode(HTLMode m)throws ExotaskValidationException{
		if(m.getName().equals("")){
			throw new ExotaskValidationException("No name was specified for mode.");
		}
		
		if(m.getPeriod() <= 0){
			throw new ExotaskValidationException("Invalid period for mode '" + m.getName()+"'");
		}
		
		if(!modules.containsKey(m.getModule())){
			throw new ExotaskValidationException("Parent module was not declared for mode '" + m.getName()+"'");
		}
		
		if(!m.getRefineProgram().equals("") && 
				!programs.containsKey(m.getRefineProgram())){
			throw new ExotaskValidationException("Refining program was not declared for mode '" + m.getName()+"'");
		}
	}
	/**
	 * Validate an HTL module
	 * @param pModule
	 * @throws ExotaskValidationException
	 */
	private void validateModule(HTLModule pModule) throws ExotaskValidationException{
		if(pModule.getName().equals("")){
			throw new ExotaskValidationException("No name was specified for module.");
		}
		
		if(!programs.containsKey(pModule.getProgram())){
			throw new ExotaskValidationException("Parent program of module '"+pModule.getName()+"' does not exists.");
		}
	}
	
	/**
	 * Validate communicator.
	 * @param c
	 * @throws ExotaskValidationException
	 */
	private void validateCommunicator(ExotaskCommunicatorSpecification c) throws ExotaskValidationException{
		if(c.getTimingData() == null)
			throw new ExotaskValidationException("No timing data for communicator '"+c.getName()+"'");
		
		HTLCommunicatorAnnotation annotation = (HTLCommunicatorAnnotation)c.getTimingData();
		if(annotation.getPeriod() <= 0)
			throw new ExotaskValidationException("Period has to be specified for communicator '"+c.getName()+"'");
		
		if(!programs.containsKey(annotation.getProgram())){
			throw new ExotaskValidationException("Parent program of the communicator '"+c.getName()+"' is not declared");
		}
	}
	
	/**
	 * Validate a predicate.
	 * @param p - predicate to be validated.
	 * @throws ExotaskValidationException if the predicate is not valid then an ExotaskValidationException will be thrown. 
	 */
	private void validatePredicate(ExotaskPredicateSpecification p) throws ExotaskValidationException {
		
		for(int i=0; i<((HTLModeSwitch)p.getTimingData()).getModes().size(); i++){
			String srcMode = ((HTLModeAssignment)((HTLModeSwitch)p.getTimingData()).getModes().get(i)).getMode();
			String destMode = ((HTLModeSwitch)p.getTimingData()).getTargetMode();
			String srcModule = ((HTLMode)modes.get(srcMode)).getModule();
			String destModule = ((HTLMode)modes.get(destMode)).getModule();
			
			if(srcMode.equals(destMode)){
				throw new ExotaskValidationException("The source and the target mode are the same for the mode switch '" + p.getName() + "'");
			}
			
			if(!srcModule.equals(destModule)){
				throw new ExotaskValidationException("Predicate '"+p.getName()+"' specifies a switch between modes in different modules.");
			}
		}
	}
	
	/**
	 * Validate a connection.
	 * @param c - connection to be validated.
	 * @throws ExotaskValidationException if the connection is not valid.
	 */
	private void validateConnection(ExotaskConnectionSpecification c) throws ExotaskValidationException {
		HTLConnectionAnnotation connAnnot = (HTLConnectionAnnotation)c.getTimingData();
		
		if(connAnnot.getInstance()>=0 && 
				!((c.getInput() instanceof ExotaskCommunicatorSpecification) || 
				(c.getOutput() instanceof ExotaskCommunicatorSpecification))){
			throw new ExotaskValidationException("Connection '"+c.getName()+
					"' an instance >= 0 although it does not connect any communicator.");
		}
		
		for(int i=0; i<connAnnot.getModes().size(); i++){
			String mode = ((HTLModeAssignment)connAnnot.getModes().get(i)).getMode();
			
			if(mode==null || mode.equals("")){
				throw new ExotaskValidationException("A mode has to be specified for connection '"+c.getName() +"'");
			}
			
			if(!(c.getInput() instanceof ExotaskCommunicatorSpecification)){
				//the input is a task
				String str = c.getInput().getName();
				
				if(!((HashMap)tasksInMode.get(mode)).containsKey(str)){
					throw new ExotaskValidationException("Connection '"+c.getName()+"' is invalid. Task '"+str+"' is not invoked in mode '"+mode+"'.");
				}
			}
			else{
				HTLConnectionAnnotation cAnnot = (HTLConnectionAnnotation)c.getTimingData();
				
				if(connAnnot.getInstance() <0){
					throw new ExotaskValidationException("Invalid instance for connection '"+c.getName()+"'");
				}
				
				if(cAnnot.writesCommunicator()){
					throw new ExotaskValidationException("Connection '"+c.getName()+
							"' reads a communicator although the annotation says it writes the communicator.");
				}
			}
		
			if(!(c.getOutput() instanceof ExotaskCommunicatorSpecification)){
				String str = c.getOutput().getName();
				if(c.getOutput() instanceof ExotaskPredicateSpecification ){
					HTLModeSwitch ms = (HTLModeSwitch)c.getOutput().getTimingData();
					if(!ms.isAssignedTo(mode)){
						throw new ExotaskValidationException("Connection '"+c.getName()+
								"' is invalid. Task '"+str+"' is not invoked in mode '"+mode+"'.");
					}
				}
				else{
					//the output is a task
					if(!((HashMap)tasksInMode.get(mode)).containsKey(str)){
						throw new ExotaskValidationException("Connection '"+c.getName()+"' is invalid. Task '"+str+"' is not invoked in mode '"+mode+"'.");
					}
				}
			}
			else{
				HTLConnectionAnnotation cAnnot = (HTLConnectionAnnotation)c.getTimingData();
				
				if(connAnnot.getInstance() <0){
					throw new ExotaskValidationException("Invalid instance for connection '"+c.getName()+"'");
				}
				
				if(!cAnnot.writesCommunicator()){
					throw new ExotaskValidationException("Connection '"+c.getName()+
							"' writes a communicator although the annotation says it reads the communicator.");
				}
			}
		}
	}
		
	//misc
	
	/**
	 * Get the program from the programs Map based on its name.
	 * @param pProgramName the program name
	 * @return the found HTLProgra,
	 */
	public HTLProgram getProgram(String pProgramName){
		return (HTLProgram)programs.get(pProgramName);
	}
	
	/**
	 * Get the mode from the modes Map based on its name.
	 * @param pModuleName the mode name
	 * @return the found HTLMode
	 */
	public HTLMode getMode(String pModeName){
		return (HTLMode)modes.get(pModeName);
	}
	
	/**
	 * Get the module from the modules Map based on its name.
	 * @param pModuleName the module name
	 * @return the found module
	 */
	public HTLModule getModule(String pModuleName){
		return (HTLModule)modules.get(pModuleName);
	}
	
	/**
	 * Get the list of modules that are in the specified program.
	 * @param pProgramName the program name.
	 * @return the found map of modules.
	 */
	public Map getModulesInProgram(String pProgramName){
		return (Map)modulesInProgram.get(pProgramName);
	}
	
	/**
	 * Get the list of modes that are in the specified module.
	 * @param pModuleName the module name.
	 * @return the found map of modes.
	 */
	public Map getModesInModule(String pModuleName){
		return (Map)modesInModule.get(pModuleName);
	}
	
	/**
	 * Get the list of task that are invoked in the specified mode.
	 * @param pModeName the mode name.
	 * @return the list of tasks invoked in the mode with the specified name.
	 */
	public Map getTasksInMode(String pModeName){
		return (Map)tasksInMode.get(pModeName);
	}
	
	/**
	 * Get the list of connections that are in the specified mode.
	 * @param pModeName the mode name.
	 * @return the list of connections in the mode with the specified name.
	 */
	public Map getConnectionsInMode(String pModeName){
		return (Map)connectionsInMode.get(pModeName);
	}
	
	/**
	 * Get the list of predicates in the specified mode. 
	 * @param pModeName the mode name.
	 * @return the list of predicates.
	 */
	public Map getPredicatesInMode(String pModeName){
		return (Map)predicatesInMode.get(pModeName);
	}
}
