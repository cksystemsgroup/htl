/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.utils;

/**
 * @author Daniel Iercan (daniel.iercan@aut.upt.ro)
 *
 */
public class DoubleLinkedList {
	/**Head of the list*/
	private MultiLinkEelement head;
	/**Tail of the list*/
	private MultiLinkEelement tail;
	/**Index used for linking*/
	private int index;
	/**Number of elements in the list*/
	private int size;
	
	/**
	 * Create a new empty double linked list
	 * @param index - index that will be used to link elements
	 */
	public DoubleLinkedList(int index){
		this.index = index;
		head = tail = null;
		size = 0;
	}
	
	/**
	 * Add a new element to the end of the list.
	 * @param element
	 */
	public void add(MultiLinkEelement element){
		element.setNext(null, index);
		element.setPrev(tail, index);
		if(tail!=null)
			tail.setNext(element, index);
		tail = element;
		if(head == null)
			head = element;
		
		size++;
	}
	
	/**
	 * Remove specify element from the list
	 * @param element
	 */
	public void remove(MultiLinkEelement element){
		if(element==head || element==tail){
			if(element == head){
				//if element equals head
				head = element.getNext(index);
				if(head!=null)
					head.setPrev(null, index);
			}
			
			if(element == tail){
				//if element equals tail
				tail = element.getPrev(index);
				if(tail!=null)
					tail.setNext(null, index);
			}
		}
		else{
			//redo the connections
			MultiLinkEelement next = element.getNext(index);
			MultiLinkEelement prev = element.getPrev(index);
			
			if(next==null || prev == null)
				return;//element is not in the list
			
			next.setPrev(prev, index);
			prev.setNext(next, index);
		}
		
		element.setNext(null, index);
		element.setPrev(null, index);
		
		size--;
	}
	
	/**
	 * Get the number of elements in the list.
	 * @return
	 */
	public int getSize(){
		return size;
	}
	
	/**
	 * Test to see if the list is empty.
	 * @return
	 */
	public boolean isEmpty(){
		return size==0;
	}
	
	/**
	 * Get the head of the list.
	 * @return
	 */
	public MultiLinkEelement getHead(){
		return head;
	}
	
	/**
	 * Get the tail of the list.
	 * @return
	 */
	public MultiLinkEelement getTail(){
		return tail;
	}
	
	/**
	 * Get the next element of the specified element.
	 * @param element
	 * @return
	 */
	public MultiLinkEelement getNext(MultiLinkEelement element){
		return element.getNext(index);
	}
	
	/**
	 * Get the prev element of the specified element.
	 * @param element
	 * @return
	 */
	public MultiLinkEelement getPrev(MultiLinkEelement element){
		return element.getPrev(index);
	}
	
	/**
	 * Reset the list, but does not brake the links between the elements.
	 *
	 */
	public void reset(){
		head = tail = null;
		size = 0;
	}
	
	/**
	 * Copy the source list. Both the source and
	 * this will point to the same list.
	 * @param source
	 */
	public void copy(DoubleLinkedList source){
		head = source.head;
		tail = source.tail;
		size = source.size;
		index = source.index;
	}
}
