/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLConnectionAnnotation;

import com.ibm.realtime.exotasks.ExotaskController;
import com.ibm.realtime.exotasks.specification.ExotaskCommunicatorSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskGraphSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskPredicateSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
class InstantiationTable {
	
	/**
     * This class serves to pair two Runnables into a single driver
     */
    private static final class DriverPair implements Runnable
    {
      private Runnable first;
      private Runnable second;
      private String name;
      private ExotaskController toCollectFirst;
      private ExotaskController toCollectSecond;
      DriverPair(Runnable first, Runnable second)
      {
        this.first = first;
        this.second = second;
        name = first.toString()+"___"+second.toString();
        toCollectFirst = (ExotaskController) ((first instanceof ExotaskController) ? first : null);
        toCollectSecond = (ExotaskController) ((second instanceof ExotaskController) ? second : null );
      }
      public void run()
      {
      		//toCollect.collect();
    	  	if(toCollectFirst != null)
    	  		toCollectFirst.collect();
	    	first.run();
	    	if(toCollectSecond != null)
    	  		toCollectSecond.collect();
	    	second.run();
      }
      
      public String toString(){
    	  return name;
      }
    }
    
	/**
	 * Contains the list of runnables that implement the tasks
	 */
	public final ArrayList tasks = new ArrayList();
	  
	/**
	 * From this Map one can get the index of an ExotaskTaskSpecification implementation
	 * in the tasks ArrayList
	 */
	private final Map taskPositions = new HashMap(); 
	  
	/**
	 * Contains the list of runnables that implement connections
	 */
	public final ArrayList drivers = new ArrayList();
	  
	/**
	 * From this Map one can get the index of an ExotaskConnectionSpecification implementation
	 * in the drivers ArrayList
	 */
	private final Map driverPositions = new HashMap();
	  
	/**
	 * Contains the list of predicates
	 */
	public final ArrayList predicates = new ArrayList();
	  
	/**
	 * From this Map one can get the index of an ExotaskPredicateSpecification implementation
	 * in the drivers ArrayList 
	 */
	private final Map predicatePositions = new HashMap();
	
	/**
	 * Create the implementation table.
	 * @param pGraph
	 * @param instantiationMap
	 */
	public InstantiationTable(ExotaskGraphSpecification pGraph, Map instantiationMap){
		initTaskTables(pGraph, instantiationMap);
		initDriverTable(pGraph, instantiationMap);
	}
	
	/**
	 * Populate the task array and the predicate array.
	 * @param pGraph
	 * @param instantiationMap
	 */
	private void initTaskTables(ExotaskGraphSpecification pGraph, Map instantiationMap){
		for(Iterator it = pGraph.getTasks().iterator();it.hasNext();){
			ExotaskTaskSpecification t = (ExotaskTaskSpecification)it.next();
			
			if(t instanceof ExotaskPredicateSpecification){
				//add a predicate
				predicatePositions.put(t, new Integer(predicates.size()));
				predicates.add(instantiationMap.get(t));
			}
			else if (!(t instanceof ExotaskCommunicatorSpecification)) {
				/* Only non-communicator tasks are examined here */
  				taskPositions.put(t, new Integer(tasks.size()));
  				//add the runnable that implements this taks to the tasks collection
  				tasks.add(instantiationMap.get(t));
  			}
		}
	}
	
	
	private void initDriverTable(ExotaskGraphSpecification pGraph, Map instantiationMap){
		//populate drivers ArrayList
		for(Iterator it = pGraph.getConnections().iterator();it.hasNext();){
			ExotaskConnectionSpecification c = (ExotaskConnectionSpecification)it.next();
			HTLConnectionAnnotation annote = (HTLConnectionAnnotation) c.getTimingData();
			driverPositions.put(c, new Integer(drivers.size()));
			if (annote == null || annote.getInstance() < 0) {
				//connection does not use a communicator
				drivers.add(instantiationMap.get(c));
			} else {
				//connection uses a communicator
				Runnable communicatorRunnable = (Runnable) instantiationMap.get(annote.getCommunicator(c));
				Runnable connectionRunnable = (Runnable) instantiationMap.get(c);
				if (annote.writesCommunicator()) {
					//communicator is written 
					drivers.add(new DriverPair(connectionRunnable, communicatorRunnable));
				} else{
					//communicator is read
					drivers.add(new DriverPair(communicatorRunnable, connectionRunnable));
				}
			}
		}
	}
	
	/**
	 * Get task position.
	 */
	public int getTaskPositions(ExotaskTaskSpecification t){
		return ((Integer)taskPositions.get(t)).intValue();
	}
	  
	/**
	 * Get driver index.
	 */
	public int getDriverPositions(ExotaskConnectionSpecification c){
		return ((Integer)driverPositions.get(c)).intValue();
	}
	  
	/**
	 * From this Map one can get the index of an ExotaskPredicateSpecification implementation
	 * in the drivers ArrayList 
	 */
	public int getPredicatePosition(ExotaskPredicateSpecification p){
		return ((Integer)predicatePositions.get(p)).intValue();
	}
}
