/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling;

import com.ibm.realtime.exotasks.ExotaskRunner;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
/**
 * An ExotaskRunner to be exposed outside the ExotaskGraph for the case where the scheduler's
 *    ExotaskRunner is also one of its Runnables and is hence inside the ExotaskGraph.  For
 *    example, ExotaskSingleThreadRunner uses this class to provide the necessary isolation.
 *    When the graph is shut down, the connection between this runner and the real runner is severed.
 */
class DelegatingExotaskRunner implements ExotaskRunner
{
  /* The real ExotaskRunner provided by the scheduler */
  private ExotaskRunner realRunner;
  
  /**
   * Create a new DelegatingExotaskRunner
   * @param realRunner the ExotaskRunner provided by the scheduler
   */
  DelegatingExotaskRunner(ExotaskRunner realRunner)
  {
    this.realRunner = realRunner;
  }
  
  // @see com.ibm.realtime.exotasks.ExotaskRunner#shutdown()
  public void shutdown()
  {
    realRunner.shutdown();
    realRunner = null;
  }

  // @see com.ibm.realtime.exotasks.ExotaskRunner#start()
  public void start()
  {
    realRunner.start();
  }

  // @see com.ibm.realtime.exotasks.ExotaskRunner#stop()
  public void stop()
  {
    realRunner.stop();
  }

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.ExotaskRunner#diagnose()
	 */
	public void diagnose()
	{
		realRunner.diagnose();
	}
}
