/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.utils;

/**
 * @author Daniel Iercan (daniel.iercan@aut.upt.ro)
 *
 * This class represents an element that can appear in 
 * more then one Double Linked list
 */
public class MultiLinkEelement {
	
	/**List of next nodes*/
	private MultiLinkEelement[] nextList;
	/**List of previous nodes*/
	private MultiLinkEelement[] prevList;
	
	public MultiLinkEelement(Integer noOfLinks){
		nextList = new MultiLinkEelement[noOfLinks.intValue()];
		prevList = new MultiLinkEelement[noOfLinks.intValue()];
	}
	
	/**
	 * Reset link information
	 *
	 */
	public void reset(){
		for(int i=0; i<nextList.length; i++){
			nextList[i] = prevList[i] = null;
		}
	}
	
	/**
	 * Set the next element at the index position
	 * @param next
	 * @param index
	 */
	public void setNext(MultiLinkEelement next, int index){
		nextList[index] = next;
	}
	
	/**
	 * Get the next element at the index position
	 * @param next
	 * @param index
	 */
	public MultiLinkEelement getNext(int index){
		return nextList[index];
	}
	
	/**
	 * Set the prev element at the index position
	 * @param prev
	 * @param index
	 */
	public void setPrev(MultiLinkEelement prev, int index){
		prevList[index] = prev;
	}
	
	/**
	 * Get the previous element at the index position
	 * @param prev
	 * @param index
	 */
	public MultiLinkEelement getPrev(int index){
		return prevList[index];
	}
}
