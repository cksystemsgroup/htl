/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling;

import com.ibm.realtime.exotasks.ESystem;
import com.ibm.realtime.exotasks.ExotaskRunner;
import com.ibm.realtime.exotasks.ExotaskSystemSupport;
import com.ibm.realtime.exotasks.ExotaskThreadFactory;
import com.ibm.realtime.exotasks.scheduling.ExotaskSchedulerRunnable;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public abstract class MultiThreadingSchedule extends ExotaskSchedulerRunnable implements ExotaskRunner {

  /**
   * The set of tasks used to run E code tasks.
   */
  private TaskSet taskSet;
  
  /**
   * Flag indicating weather the ECodeRunner is running.
   */
  private AtomicFlag running;
  
  /**
   * Flag indicating that the E code runner is active.
   */
  private AtomicFlag active;
  
  /** Value for DEBUG meaning never debug, even if in test VM */
  protected static final int DEBUG_NEVER = 0;
  
  /** Value for DEBUG meaning debug in test VM but not in real exotask VM */
  protected static final int DEBUG_IF_SAFE = 1;
  
  /** Value for DEBUG meaning debug always, even in real exotask VM (this may
   * or may not be safe, so the flag should never be set this way in production)
   */
  protected static final int DEBUG_ALWAYS = 2;
  
  /** Static debug control: set to DEBUG_NEVER, DEBUG_ALWAYS, or DEBUG_IF_SAFE */
  protected static final int DEBUG_MODE = DEBUG_NEVER;
  
  /** Flag used to control actual debugging */
  protected final boolean DEBUG = (DEBUG_MODE == DEBUG_ALWAYS || 
  	(DEBUG_MODE == DEBUG_IF_SAFE && !ExotaskSystemSupport.isExotaskVM()));
  
  /** A simple counter that is incremented when debug is called.  Even if debugging is off, this counter
   *  will increment when the thread is running.
   */
  protected int debugCounter;
    
  /** Store the last debug message for display by diagnose() even when DEBUG==DEBUG_NEVER */
  protected String lastDebug;
  	
  public MultiThreadingSchedule(){
    running = new AtomicFlag(false);
    active = new AtomicFlag(false);
    taskSet = new TaskSet();
    
    debugln("Multi Threading Schedule was created.");
  }
  
  /***
   * Set the task set for the schedule.
   * @param tasks
   * @param threads
   */
  private void setTaskSet(ExotaskSchedulerRunnable[] tasks, Thread[] threads){
	  taskSet.setTasks(tasks);
	  taskSet.setThreads(threads);
  }
  
  /**
   * Clone and start the MultiThreading schedule.
   * @param schedule
   * @param factory
   * @return
   */
  public static ExotaskRunner cloneAndStartMultiThreadingSchedule(MultiThreadingSchedule schedule, ExotaskThreadFactory factory){
	  
	  int noTasks = schedule.getMaxTasks();
	  ITaskCompletionCallback completionCallback = schedule.getComplitionCallback();
	  
	  ExotaskSchedulerRunnable[] tasks = new ExotaskSchedulerRunnable[noTasks+1];
	  //create the workers
	  for(int i=1; i<noTasks+1; i++)
		tasks[i] = new Task(completionCallback);
		
	  //set the control task
	  tasks[0] = schedule;
	  
	  //create the threads
	  Thread[] threads = factory.createThreads(tasks);
	  
	  //in exotask VM the tasks are cloned
	  //all the tasks were cloned, set the control tasks task set
	  MultiThreadingSchedule newScheduleTask = (MultiThreadingSchedule)tasks[0];
	  newScheduleTask.setTaskSet(tasks, threads);
	  
	  schedule.debugln("Multi Threading Schedule was initialized.");
	  
	  return new DelegatingExotaskRunner(newScheduleTask);
  }
  
  /**
   * Issue debugging message according flag setting
   * @param msg the message
   */
  final protected void debugln(String msg)
  {
  	debugCounter++;
  	lastDebug = msg;
  	if (DEBUG) {
  		ESystem.err.println(msg);
  	}
  }
  
  /**
   * Issue debugging message according flag setting
   * @param msg the message
   */
  final protected void debugln(int value)
  {
  	debugCounter++;
  	if (DEBUG) {
  		ESystem.err.println(value);
  	}
  }
  
  /**
   * Issue debugging message according flag setting
   * @param msg the message
   */
  final protected void debug(String msg)
  {
  	debugCounter++;
  	lastDebug = msg;
  	if (DEBUG) {
  		ESystem.err.print(msg);
  	}
  }
  
  /**
   * Issue debugging message according flag setting
   * @param msg the message
   */
  final protected void debug(int value)
  {
  	debugCounter++;
  	if (DEBUG) {
  		ESystem.err.print(value);
  	}
  }
  
  
  /**
	 * Shutdown the runner
	 */
	public synchronized void shutdown() {
		if(active.isOn()){
			
			active.resetFlag();
			running.resetFlag();
							
			synchronized (this) {
				//notify the runner
				this.notify();
			}
			
			taskSet.stop();
		}
		debugln("Multi Threading Schedule was shutdown.");
	}

	/**
	 * Start the runner
	 */
	public synchronized void start() {
		
		if(!running.isOn()){
			running.setFlag();
				
			synchronized (this) {
				//notify the runner that the running flag has changed
				this.notify();
			}
		}
		
		if(!active.isOn()){
			active.setFlag();
			debugln("Multi Threading Scheduler activate schedule...");
			taskSet.start();
		}
		debugln("Multi Threading Schedule was started.");
	}

	/**
	 * Stop the runner
	 */
	public synchronized void stop() {
		running.resetFlag();
		debugln("Multi Threading Schedule was stoped.");
	}
	
	public void run(){
		debugln("Multi Threading Schedule start of run method.");
		startSchedule();
		while(active.isOn()){
			if(!running.isOn()){
				//the runner is active but not running yet.
				synchronized (this) {
					try{
						this.wait();
						if(!running.isOn()){
							continue;
						}
					}
					catch(InterruptedException e){
						debugln("Error wile waiting for running flag.");
					}
				}
			}
			
			do {
				schedule();
			} while (running.isOn());
		}
		debugln("Multi Threading Schedule end of run method.");
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.scheduling.ExotaskSingleThreadRunner#diagnose()
	 */
	public void diagnose()
	{
		System.err.println("DebugCounter=" + debugCounter + ", lastDebug=" + lastDebug);
	}
	
	/**
	 * Return true if the multithreading schedule is running.
	 * @return
	 */
	protected boolean isRunning(){
		return running.isOn();
	}
	
	/**
	 * Return true if multithreading schedule is active.
	 * @return
	 */
	protected boolean isActive(){
		return active.isOn();
	}
	
	protected void releaseTask(Runnable runnable, int taskIndex)throws ExotaskValidationException{
		taskSet.scheduleTask(runnable, taskIndex);
		debug("Tasks: ");
		debug(taskSet.getUsedTasksCount());
		debug(" / ");
		debugln(taskSet.getSize());
	}
	
	/**
	 * Execute the schedule.
	 *
	 */
	protected abstract void schedule();
	
	protected abstract int getMaxTasks();
	
	protected abstract ITaskCompletionCallback getComplitionCallback();
	
	/**
	 * Start the schedule.
	 *
	 */
	protected abstract void startSchedule();
	
	private class AtomicFlag{
		private boolean flag;
		
		/**
		 * Create a new atomic flag in the specified status
		 * @param status
		 */
		public AtomicFlag(boolean status) {
			flag = status;
		}
		
		/**
		 * Set the flag.
		 *
		 */
		public synchronized void setFlag(){
			flag = true;
		}
		
		/**
		 * Reset the flag
		 *
		 */
		public synchronized void resetFlag(){
			flag = false;
		}
		
		/**
		 * Get flag status
		 * @return
		 */
		public synchronized boolean isOn(){
			return flag;
		}
	}
}
