/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.scheduling.ecode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLCommunicatorAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLConnectionAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLTaskAnnotation;

import com.ibm.realtime.exotasks.specification.ExotaskCommunicatorSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskConnectionSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskPredicateSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskTaskSpecification;
import com.ibm.realtime.exotasks.specification.ExotaskValidationException;

/**
 * This class cheks that the given program is a valid HTL program.
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
class HTLValidator extends HTLProgramWalker {
			
	/**
	 * This Map contains a list of task read by other tasks.
	 */
	private Map taskReadTasks = new HashMap();
		
	/**
	 * This Map contains a list of communicators read/written in/by a mode.
	 */
	private Map modeCommunicators = new HashMap();
	
	private SymbolTable symbolTable;
	private InheritTable inheritTable;
	
	public HTLValidator(SymbolTable pSymbolTable, InheritTable pInheritTable) throws ExotaskValidationException{
		super(pSymbolTable);
		symbolTable = pSymbolTable;
		inheritTable = pInheritTable;
		
		//load the Maps
		walk();
	}
	
	/**
	 * Check if the program is a valid HTL program. 
	 * @throws ExotaskValidationException
	 */
	public void check() throws ExotaskValidationException{
		new ClosedLoopChecker(symbolTable);
		new CausalityChecker(symbolTable);
		new TaskCommWriteChecker(symbolTable);
		new CommunicatorsInheritChecker(symbolTable, inheritTable);
		new CommProgramWriteChecker(symbolTable);
		new TaskInheritChecker(symbolTable, inheritTable);
	}

	/**
	 * In this method we will populate the maps.
	 */
	protected void inAConnection(HTLProgram P, HTLModule M, HTLMode m, ExotaskConnectionSpecification c) throws ExotaskValidationException{
		if(c.getInput().getTimingData() instanceof HTLTaskAnnotation){
			//the source of the communication is an HTL Task
			
			if(c.getOutput().getTimingData() instanceof HTLTaskAnnotation){
				//the destination of the communication is an HTL task
				addToMapOfLists(taskReadTasks, c.getOutput().getName(), c.getInput());
			}
			else if(c.getOutput().getTimingData() instanceof HTLCommunicatorAnnotation){
				//destination is a communicator
				addToMapOfLists(modeCommunicators, m.getName(), c.getOutput());
			}
		}
		else{
			if(c.getInput().getTimingData() instanceof HTLCommunicatorAnnotation){
				//the source of the communication is an HTL communicator				
				addToMapOfLists(modeCommunicators, m.getName(), c.getInput());
			}
		}
	}
	
	/**
	 * This class implements the closed loop checking
	 * @author Daniel Iercan (diercan@aut.upt.ro)
	 *
	 */
	private class ClosedLoopChecker extends HTLProgramWalker{
		
		public ClosedLoopChecker(SymbolTable pSymbolTable) throws ExotaskValidationException{
			super(symbolTable);
			walk();
		}
	
		/***
		 * This method will be called when a task is reached
		 * @param P
		 * @param M
		 * @param m
		 */
		protected void inATask(HTLProgram P, HTLModule M, HTLMode m, ExotaskTaskSpecification t)  throws ExotaskValidationException{
			searchForClosedLoops(P, M, m, t, t);
		}
		
		/**
		 * Recursevly search for closed loops
		 * @param firstTask
		 * @param t
		 * @throws ExotaskValidationException
		 */
		private void searchForClosedLoops(HTLProgram P, HTLModule M, HTLMode m, ExotaskTaskSpecification firstTask, ExotaskTaskSpecification t) throws ExotaskValidationException{
			ArrayList l = (ArrayList)taskReadTasks.get(t.getName());
			
			if(l!=null){
				Iterator it = l.iterator();
				while(it.hasNext()){
					ExotaskTaskSpecification tRead = (ExotaskTaskSpecification)it.next();
					if(tRead.equals(firstTask)){
						//a closed loop was found
						throw new ExotaskValidationException(printPosition(P, M, m) + ": Task '"+firstTask.getName()+"' is in a loop of dependencies.");
					}
				}
			}
		}
	}
	
	/**
	 * Check that no two task that are invoked in the same mode write the
	 * same instance of a communicator.
	 * @author Daniel Iercan (diercan@aut.upt.ro)
	 *
	*
	 */
	private class TaskCommWriteChecker extends HTLProgramWalker{
		
		public TaskCommWriteChecker(SymbolTable symbolTable) throws ExotaskValidationException{
			super(symbolTable);
			
			walk();
		}

		/**
		 * Check if there are communicator instances written more then once in a mode.
		 */
		public void inAMode(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{
			Map connections = symbolTable.getConnectionsInMode(m.getName());
			if(connections == null)
				return;
			Iterator connIterator = connections.values().iterator();
			
			final Set writtenInstances = new HashSet();
			
			while(connIterator.hasNext()){
				ExotaskConnectionSpecification conn = 
					(ExotaskConnectionSpecification)connIterator.next();
				HTLConnectionAnnotation connAnnot = (HTLConnectionAnnotation)conn.getTimingData();
				if(conn.getOutput() instanceof ExotaskCommunicatorSpecification){
					//connection writes a communicator, thus the source is a task
					if(!writtenInstances.add(conn.getOutput().getName()+", "+connAnnot.getInstance())){
						throw new ExotaskValidationException(printPosition(P, M, m) + "Instance "+connAnnot.getInstance()+
								" of communicator '"+conn.getOutput().getName()+"' is written twice in the same mode.");
					}
				}
			}
		}
	}
	
	/**
	 * Check that thereis no zero time to execute a task
	 */
	private class CausalityChecker extends HTLProgramWalker{
				
		public CausalityChecker(SymbolTable pSymbolTable) throws ExotaskValidationException{
			super(pSymbolTable);
			
			walk();
		}
		
		/***
		 * This method will be called when a task is reached
		 * @param P
		 * @param M
		 * @param m
		 */
		protected void inATask(HTLProgram P, HTLModule M, HTLMode m, ExotaskTaskSpecification t)  throws ExotaskValidationException{
			TaskBounds tb = computeTaskBounds(m, t);
			if(tb.releaseTime >= tb.terminationTime){
				throw new ExotaskValidationException(printPosition(P, M, m)+"Zero time to execute task '"+t.getName()+"'.");
			}
			
			ArrayList depTasks = (ArrayList)taskReadTasks.get(t.getName());
			checkDepBounds(depTasks, tb, t, m, printPosition(P, M, m));
		}
		
		/**
		 * Check to see if there is enough time to execute the given task.
		 * @param depTasks
		 * @param tb
		 * @param t
		 * @param m
		 * @param locus
		 * @throws ExotaskValidationException
		 */
		private void checkDepBounds(ArrayList depTasks, TaskBounds tb, ExotaskTaskSpecification t, HTLMode m, String locus) throws ExotaskValidationException{
			if(depTasks == null)
				return;
			
			Iterator itDep = depTasks.iterator();
			
			while(itDep.hasNext()){
				ExotaskTaskSpecification tDep = (ExotaskTaskSpecification)itDep.next();
				TaskBounds tDepBounds = computeTaskBounds(m, tDep);
				
				if(tDepBounds.releaseTime >= tb.terminationTime)
					throw new ExotaskValidationException(locus+"Zero time to execute task '"+t.getName()+
							"'. Because this task depends on '"+tDep.getName()+"'");
				
				ArrayList depTasks2 = (ArrayList)taskReadTasks.get(tDep.getName());
				checkDepBounds(depTasks2, tb, t, m, locus);
			}
		}
	}
	
	private class CommunicatorsInheritChecker extends HTLProgramWalker{
		
		private final Map commDecl = new HashMap();
		
		public CommunicatorsInheritChecker(SymbolTable pSymbolTable, InheritTable pInheritTable)
		throws ExotaskValidationException{
			super(pSymbolTable, pInheritTable);
			
			walkDepFirst();
		}
		
		/**
		 * This method will be called when an HTL program is reached.
		 * @param P
		 */
		protected void inAProgram(HTLProgram P) throws ExotaskValidationException{
			Map comms = (Map)symbolTable.communicatorsInProgram.get(P.getName());
			
			commDecl.put(P.getName(), comms);			
		}
		
		/**
		 * This method will be called when living an HTL program.
		 * @param P
		 */
		protected void outAProgram(HTLProgram P) throws ExotaskValidationException{
			commDecl.remove(P.getName());
		}
		
		/***
		 * This method will be called when a mode is reached
		 * @param P
		 * @param M
		 * @param m
		 */
		protected void inAMode(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{
			ArrayList comms = (ArrayList)modeCommunicators.get(m.getName());
			if(comms == null)
				return;
			Iterator itComms = comms.iterator();
			
			while(itComms.hasNext()){
				ExotaskCommunicatorSpecification comm = (ExotaskCommunicatorSpecification)itComms.next();		
				
				if(!isCommDecleared(comm.getName())){
					throw new ExotaskValidationException(printPosition(P, M, m) + "Communicator '"+comm.getName()+"' is "
							+ "used without being declared in one of the super programs.");
				}
			}
		}
		
		/**
		 * 
		 * @param commName
		 * @return if the communicator is decleared.
		 */
		private boolean isCommDecleared(String commName){
			Iterator it = commDecl.values().iterator();
			
			while(it.hasNext()){
				Map decls = (Map)it.next();
				if(decls != null && decls.containsKey(commName))
					return true;
			}
			
			return false;
		}
	}
	
	/**
	 * Check that a communicator is not written from sibling modules.
	 * @author Daniel Iercan (diercan@aut.upt.ro)
	 *
	*
	 */
	private class CommProgramWriteChecker extends HTLProgramWalker{
		SibWriteCommSet writeSet;
		
		public CommProgramWriteChecker(SymbolTable pSymbolTable)throws ExotaskValidationException{
			super(pSymbolTable);
			
			walk();
		}
		
		/**
		 * This method will be called when an HTL module will be reached
		 * @param P
		 * @param M
		 */
		protected void inAModule(HTLProgram P, HTLModule M) throws ExotaskValidationException{
			//clear the module written comm set
			writeSet = new SibWriteCommSet(symbolTable, inheritTable, P.getName(), M.getName());
		}
		
		/**
		 * In this method we will populate the maps.
		 */
		protected void inAConnection(HTLProgram P, HTLModule M, HTLMode m, ExotaskConnectionSpecification c) throws ExotaskValidationException{
			if(c.getInput().getTimingData() instanceof HTLTaskAnnotation){
				//the source of the communication is an HTL Task
				//HTLTaskAnnotation taskAnnot = (HTLTaskAnnotation)c.getInput().getTimingData();
				
				if(c.getOutput().getTimingData() instanceof HTLCommunicatorAnnotation){
					//destination is a communicator
					//moduleWrittenComms.add(c.getOutput().getName());
					String comm = c.getOutput().getName();
					
					if(writeSet.writeComms.contains(comm)){
						throw new ExotaskValidationException(printPosition(P, M, m) + " Communicator '"+comm+"' is written in more the one module that are run in paralel.");
					}
				}
			}
		}
				
		/**
		 * This class Will compute the write set of the sibling modes of a mode
		 * @author Daniel Iercan (diercan@aut.upt.ro)
		 *
  		 *
		 */
		private class SibWriteCommSet extends HTLProgramWalker{
			private String program;
			private String module;
			private boolean record;
			
			public final Set writeComms = new HashSet();
			
			public SibWriteCommSet(SymbolTable pSymbolTable, InheritTable pInheritTable, String pProgram, String pModule) throws ExotaskValidationException{
				super(pSymbolTable, pInheritTable);
			
				record= false;
				program = pProgram;
				module = pModule;
				
				walkDepFirst();
			}
			
			/**
			 * This method will be called when living an HTL program.
			 * @param P
			 */
			protected void inAProgram(HTLProgram P) throws ExotaskValidationException{
				if(P.getName().equals(program))
					record = true;
			}
						
			/**
			 * In this method we will populate the maps.
			 */
			protected void inAConnection(HTLProgram P, HTLModule M, HTLMode m, ExotaskConnectionSpecification c) throws ExotaskValidationException{
				if(record && !inheritTable.isParentForModule(module, M.getName())){
					if(c.getInput().getTimingData() instanceof HTLTaskAnnotation){
						//the source of the communication is an HTL Task
						//HTLTaskAnnotation taskAnnot = (HTLTaskAnnotation)c.getInput().getTimingData();
						
						if(c.getOutput().getTimingData() instanceof HTLCommunicatorAnnotation){
							//destination is a communicator
							writeComms.add(c.getOutput().getName());
						}
					}
				}
			}
			
			/**
			 * This method will be called when living an HTL program.
			 * @param P
			 */
			protected void outAProgram(HTLProgram P) throws ExotaskValidationException{
				if(P.getName().equals(program))
					record = false;
			}
						
		}
	}
	
	private class TaskInheritChecker extends HTLProgramWalker{
		
		private final Set refinedTasks = new HashSet();
		
		public TaskInheritChecker(SymbolTable pSymbolTable, InheritTable pInheritTable) throws ExotaskValidationException{
			super(pSymbolTable, pInheritTable);
			
			walkDepFirst();
		}

		/**
		 * In this method we will populate the maps.
		 */
		protected void inAConnection(HTLProgram P, HTLModule M, HTLMode m, ExotaskConnectionSpecification c) throws ExotaskValidationException{
			if(c.getOutput() instanceof ExotaskPredicateSpecification){
				if(c.getInput().getTimingData() instanceof HTLTaskAnnotation){
					HTLTaskAnnotation taskAnnot = (HTLTaskAnnotation)c.getInput().getTimingData();
					if(taskAnnot.IsAbstract())
						throw new ExotaskValidationException(printPosition(P, M, m)+"Predicate '"+c.getOutput().getName()+
								"' can not read an abstract task ('"+c.getInput().getName()+"')");
				}
			}
		}
		
		/***
		 * This method will be called when a mode is reached
		 * @param P
		 * @param M
		 * @param m
		 */
		protected void inAMode(HTLProgram P, HTLModule M, HTLMode m) throws ExotaskValidationException{
			
			if(!m.getRefineProgram().equals("")){
				Map parentModules = symbolTable.getModulesInProgram(m.getRefineProgram());
				Iterator itModules = parentModules.values().iterator();
				
				//constract the list of tasks trefined in the child program
				refinedTasks.clear();
				while(itModules.hasNext()){
					HTLModule childM = (HTLModule)itModules.next();
					final Set refinedTasksInModule = new HashSet();
					Map modes = symbolTable.getModesInModule(childM.getName());
					
					//get each mode in the module
					Iterator itModes = modes.values().iterator();
					while(itModes.hasNext()){
						HTLMode mode = (HTLMode)itModes.next();
						Map tasks = symbolTable.getTasksInMode(mode.getName());
						
						if(tasks != null){
							Iterator itTasks = tasks.values().iterator();
							while(itTasks.hasNext()){
								ExotaskTaskSpecification t = (ExotaskTaskSpecification)itTasks.next();
								HTLTaskAnnotation taskAnnot =(HTLTaskAnnotation)t.getTimingData();
								if(!taskAnnot.getParentTask().equals("")){
									refinedTasksInModule.add(taskAnnot.getParentTask());
								}
							}
						}
					}
					
					Iterator itRefTasks = refinedTasksInModule.iterator();
					//add the tasks to the set of refined task and test to see if they are 
					//not 
					while(itRefTasks.hasNext()){
						String task = (String)itRefTasks.next();
						if(!refinedTasks.add(task)){
							throw new ExotaskValidationException(printPosition(P, M, m)+
									"Task '"+task+"' is refined in two different modules.");
						}
					}
				}
			}
		}
		
		/***
		 * This method will be called when a task is reached
		 * @param P
		 * @param M
		 * @param m
		 */
		protected void inATask(HTLProgram P, HTLModule M, HTLMode m, ExotaskTaskSpecification t)  throws ExotaskValidationException{
			TaskBounds tb = computeTaskBounds(m, t);
			HTLTaskAnnotation taskAnnot = (HTLTaskAnnotation)t.getTimingData();
			
			if(taskAnnot.IsAbstract()){
				
				if(m.getRefineProgram().equals(""))
				{
					throw new ExotaskValidationException(printPosition(P, M, m) + "Abstract task '"+t.getName()+"' in a leef mode '"+m.getName()+"'");
				}
				
				//this is an abstract task it has to be refined in the refining program
				if(!refinedTasks.contains(t.getName()))
					throw new ExotaskValidationException(printPosition(P, M, m)+" Abstract task '"+t.getName()+"' is not refined in the refining program.");
			}
			
			HTLMode parentMode = (HTLMode)inheritTable.modeParents.get(m.getName());
			if(parentMode!=null){
				if(taskAnnot.getParentTask().equals("")){
					throw new ExotaskValidationException(printPosition(P, M, m) + "The mode '"+m.getName()+"'"+
							" is not a root mode, thus tasks invoked in it should have a parent. Task '"+t.getName() + 
							"' should have a parent.");
				}
				
				//test bounds
				ExotaskTaskSpecification parentTask = (ExotaskTaskSpecification)symbolTable.getTasksInMode(parentMode.getName()).get(taskAnnot.getParentTask());
				TaskBounds ptBounds = computeTaskBounds(parentMode, parentTask);
				if(ptBounds.releaseTime < tb.releaseTime){
					throw new ExotaskValidationException("Task '"+t.getName()+"' can not be released later then its parent '"+parentTask.getName()+"'");
				}
				if(ptBounds.terminationTime > tb.terminationTime){
					throw new ExotaskValidationException("Task '"+t.getName()+"' can not terminate earlier then its parent '"+parentTask.getName()+"'");
				}
				
				//test dependency list
				ArrayList depTasks = (ArrayList)taskReadTasks.get(t.getName());
				ArrayList parentDepTasks = (ArrayList)taskReadTasks.get(parentTask.getName());
				
				if(depTasks!=null){
					Iterator depIT = depTasks.iterator();
					while(depIT.hasNext()){
						ExotaskTaskSpecification tDep = (ExotaskTaskSpecification)depIT.next();
						HTLTaskAnnotation tDepAnnot = (HTLTaskAnnotation)tDep.getTimingData();
					
						ExotaskTaskSpecification tDepParent = (ExotaskTaskSpecification)symbolTable.getTasksInMode(parentMode.getName()).get(tDepAnnot.getParentTask());
						if(tDepParent == null || parentDepTasks==null || !parentDepTasks.contains(tDepParent)){
							throw new ExotaskValidationException(printPosition(P, M, m)+" Dependency list is not inherit. Task "+
									" '"+t.getName()+"' depends on '"+tDep.getName()+"' but it parent '"+parentTask.getName()+"' "+
									"does not depend on '"+tDepAnnot.getParentTask()+"'");
						}
					}
				}
			}
			else{
				if(!taskAnnot.getParentTask().equals("")){
					throw new ExotaskValidationException(printPosition(P, M, m) + "The mode '"+m.getName()+"'"+
							" is a root mode, thus tasks invoked in it can not have parents. Task '"+t.getName() + 
							"' can not have a parent.");
				}
			}
		}
	}
	
	/**
	 * Compute the bounds of a task.
	 * @param m
	 * @param t
	 * @return
	 * @throws ExotaskValidationException
	 */
	private TaskBounds computeTaskBounds(HTLMode m, ExotaskTaskSpecification t) throws ExotaskValidationException {
		TaskBounds tb = new TaskBounds();
		
		//set the bound to the limits
		tb.releaseTime = 0;
		tb.terminationTime = m.getPeriod();

		Map connMap = symbolTable.getConnectionsInMode(m.getName());
		
		if(connMap == null)
			return tb;
			
		Iterator itConns = connMap.values().iterator();
		
		while(itConns.hasNext()){
			ExotaskConnectionSpecification conn = (ExotaskConnectionSpecification)itConns.next();
			HTLConnectionAnnotation connAnnot = (HTLConnectionAnnotation)conn.getTimingData();
			if(conn.getInput().equals(t)){
				//t is the input of the connection
				if(conn.getOutput() instanceof ExotaskCommunicatorSpecification){
					//the connection writes a communicator
					HTLCommunicatorAnnotation commAnnot = (HTLCommunicatorAnnotation)conn.getOutput().getTimingData();
					long deadline = commAnnot.getPeriod()*connAnnot.getInstance();
					if(deadline > m.getPeriod()){
						throw new ExotaskValidationException("Instance "+connAnnot.getInstance()+" of communicator '"+
								conn.getOutput().getName()+"' is to big to be written in mode '"+m.getName()+"'.");
					}
					
					if(deadline < tb.terminationTime){
						tb.terminationTime = deadline;
					}
				}
			}else{
				if(conn.getOutput().equals(t)){
					//t is the output of the connection
					if(conn.getInput() instanceof ExotaskCommunicatorSpecification){
						//the connection reads a communicator
						HTLCommunicatorAnnotation commAnnot = (HTLCommunicatorAnnotation)conn.getInput().getTimingData();
						long deadline = commAnnot.getPeriod()*connAnnot.getInstance();
						if(deadline > m.getPeriod()){
							throw new ExotaskValidationException("Instance "+connAnnot.getInstance()+" of communicator '"+
									conn.getOutput().getName()+"' is to big to be read in mode '"+m.getName()+"'.");
						}
						
						if(deadline > tb.releaseTime){
							tb.releaseTime = deadline;
						}
					}
				}
			}
		}
		
		return tb;
	}
	
	/**
	 * This class contains information about the bounds of a task.
	 * @author Daniel Iercan (diercan@aut.upt.ro)
	 *
	*
	 */
	private class TaskBounds{
		public long releaseTime=0;
		public long terminationTime=0;
	}
	
	private String printPosition(HTLProgram P, HTLModule M, HTLMode m){
		return "["+P.getName()+", "+M.getName()+", "+ m.getName() + "]";
	}
}
