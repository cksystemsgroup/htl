/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DialogCellEditor;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.dialogs.ListSelectionDialog;
import org.eclipse.ui.dialogs.SelectionDialog;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLExotaskGraphAnnotation;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModeAssignmentsCellEditor extends DialogCellEditor {

	 /** Back pointer to the global timing object from which mode names may be retrieved */
	  private HTLGlobalTiming globalTiming;
	  
	  /**
	   * Create a new ActiveModesCellEditor
	   * @param parent the parent composite
	   * @param globalTiming the GlobalTiming from which to find out the available modes
	   */
	  public HTLModeAssignmentsCellEditor(Composite parent, HTLGlobalTiming globalTiming)
	  {
	    super(parent);
	    this.globalTiming = globalTiming;
	  }

	  // @see org.eclipse.jface.viewers.DialogCellEditor#openDialogBox(org.eclipse.swt.widgets.Control)
	  protected Object openDialogBox(Control cellEditorWindow)
	  {
	    String[] names = ((HTLExotaskGraphAnnotation)globalTiming.getAnnotation()).getHTLModeList().getModeNames();
	    SelectionDialog dialog = new ListSelectionDialog(cellEditorWindow.getShell(),
	        names, new ArrayContentProvider(), new LabelProvider(), "Available modes");
	    dialog.setTitle("Assign modes");
	    if (dialog.open() == IDialogConstants.CANCEL_ID)
	      return null;
	    Object[] active= dialog.getResult();
	    if (active == null || active.length == 0)
	      return null;
	    String[] ans = new String[active.length];
	    System.arraycopy(active,0, ans,0, active.length);
	    return new AssignedModes(ans);
	  }

	  // @see org.eclipse.jface.viewers.DialogCellEditor#createButton(org.eclipse.swt.widgets.Composite)
	  protected Button createButton(Composite parent)
	  {
	    Button button = super.createButton(parent);
	    button.setText("Edit...");
	    return button;
	  }
}

/**
 * A simple class to encapsulate a list of assigned modes and format it when called for
 */
class AssignedModes
{
  /** The modes currently wrapped by this class (directly accessible) */
  String[] modes;
  
  /**
   * Create a new ActiveModes object
   * @param modes the modes to wrap
   */
  AssignedModes(String[] modes)
  {
    this.modes = (modes != null) ? modes : new String[0];
  }
  
  /**
   * Create a new ActiveModes object with an empty modes list
   */
  AssignedModes()
  {
    this(new String[0]);
  }

  // @see java.lang.Object#toString()
  public String toString()
  {
    StringBuilder ans = new StringBuilder();
    String delim = "";
    for (int i = 0; i < modes.length; i++) {
      ans.append(delim).append(modes[i]);
      if(i < modes.length-1)
    	  delim = ", ";
    }
    return ans.toString();
  }
}