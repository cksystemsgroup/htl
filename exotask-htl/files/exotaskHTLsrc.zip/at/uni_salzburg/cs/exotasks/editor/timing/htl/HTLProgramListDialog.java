/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgramList;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLProgramListDialog extends Dialog{
	
	/** Place to store the ProgramList that is the content model for the dialog */
	  private HTLProgramList programList;
	  
	  /** The TableViewer in use in this dialog */
	  private TableViewer viewer;
	     
	  /**
	   * Create a new ModeListDialog
	   * @param shell the governing shell
	   * @param modeList the current mode list
	   */
	  public HTLProgramListDialog(Shell shell, HTLProgramList programList)
	  {
	    super(shell);
	    this.programList = programList;
	  }

	  // @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
	  protected Control createDialogArea(Composite parent)
	  {
	    Composite composite = (Composite)super.createDialogArea(parent);
	    Table programTable = new Table(composite, SWT.BORDER | SWT.SINGLE | SWT.FULL_SELECTION);
	    TableColumn programName = new TableColumn(programTable, SWT.LEFT);
	    programName.setText("Program Name");
	    programName.setWidth(80);
	    programName.pack();
	    viewer = new TableViewer(programTable);
	    viewer.setContentProvider(new HTLProgramListContentProvider());
	    viewer.setLabelProvider(new ThreeStringLabelProvider());
	    viewer.setInput(programList);
	    programTable.setHeaderVisible(true);
	    programTable.setLinesVisible(true);
	    programTable.getVerticalBar().setVisible(true);
	    /* Make table directly editable */
	    viewer.setColumnProperties(new String[] {"0"});
	    viewer.setCellModifier(new HTLTableModifier());
	    viewer.setCellEditors(new CellEditor[] {
	        new TextCellEditor(programTable)});
	    
	    composite.setSize(220, 300);
	    return composite;
	  }

	  // @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
	  protected void configureShell(Shell newShell)
	  {
	    super.configureShell(newShell);
	    newShell.setText("Edit progran names");
	  }

	  // @see org.eclipse.jface.dialogs.Dialog#okPressed()
	  protected void okPressed()
	  {
	    int count = 0;
	    Table programTable = viewer.getTable();
	    for (int i = 0; i < programTable.getItemCount(); i++) {
	      if (programTable.getItem(i).getText(0).length() > 0) {
	        count++;
	      }
	    }
	    HTLProgram[] programs = new HTLProgram[count];
	    for (int i = 0; i < programTable.getItemCount(); i++) {
	      TableItem item = programTable.getItem(i);
	      String name = item.getText(0);

	      if (name.length() > 0) {
	        programs[i] = new HTLProgram(name);
	      }
	    }
	    programList = new HTLProgramList(programs);
	    super.okPressed();
	  }

	  /**
	   * Return the current ModeList value
	   * @return the current ModeList value
	   */
	  public HTLProgramList getProgramList()
	  {
	    return programList;
	  }

}
