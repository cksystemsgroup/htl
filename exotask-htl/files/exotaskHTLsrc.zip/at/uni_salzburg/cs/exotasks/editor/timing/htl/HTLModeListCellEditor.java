/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.DialogCellEditor;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

/**
 * The cell editor for the list of modes in the GlobalTiming
 * of the HTL grammar
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 **/
public class HTLModeListCellEditor extends DialogCellEditor {

	 /** The value to be edited */
	  private HTLModeListWrapper modeList;
	  
	  /**
	   * Pass-through constructor
	   * @param parent the owning composite
	   */
	  public HTLModeListCellEditor(Composite parent)
	  {
	    super(parent);
	  }

	  // @see org.eclipse.jface.viewers.DialogCellEditor#doSetValue(java.lang.Object)
	  protected void doSetValue(Object value)
	  {
	    this.modeList = ((HTLModeListWrapper) value);
	    super.doSetValue(modeList);
	  }

	  // @see org.eclipse.jface.viewers.DialogCellEditor#openDialogBox(org.eclipse.swt.widgets.Control)
	  protected Object openDialogBox(Control cellEditorWindow)
	  {
	    HTLModeListDialog dialog = new HTLModeListDialog(cellEditorWindow.getShell(), modeList);
	    if (dialog.open() == IDialogConstants.CANCEL_ID)
	      return null;
	    HTLModeListWrapper modeList = dialog.getModeList();
	    return modeList;
	   }

	  // @see org.eclipse.jface.viewers.DialogCellEditor#createButton(org.eclipse.swt.widgets.Composite)
	  protected Button createButton(Composite parent)
	  {
	    Button button = super.createButton(parent);
	    button.setText("Edit...");
	    return button;
	  }

}
