/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModuleList;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModuleListDialog extends Dialog {

	/** Place to store the ModuleList that is the content model for the dialog */
	  private HTLModuleList moduleList;
	  
	  /** The TableViewer in use in this dialog */
	  private TableViewer viewer;
	  
	  private HTLGlobalTiming globalTiming;
	     
	  /**
	   * Create a new ModeListDialog
	   * @param shell the governing shell
	   * @param modeList the current mode list
	   */
	  public HTLModuleListDialog(Shell shell, HTLModuleList moduleList, HTLGlobalTiming globalTiming)
	  {
	    super(shell);
	    this.moduleList = moduleList;
	    this.globalTiming = globalTiming;
	  }

	  // @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
	  protected Control createDialogArea(Composite parent)
	  {
	    Composite composite = (Composite)super.createDialogArea(parent);
	    Table moduleTable = new Table(composite, SWT.BORDER | SWT.SINGLE | SWT.FULL_SELECTION);
	    TableColumn moduleName = new TableColumn(moduleTable, SWT.LEFT);
	    moduleName.setText("Module Name");
	    moduleName.setWidth(80);
	    TableColumn startMode = new TableColumn(moduleTable, SWT.LEFT);
	    startMode.setText("Start Mode");
	    TableColumn progName = new TableColumn(moduleTable, SWT.LEFT);
	    progName.setText("Parent Program");
	    progName.setWidth(80);
	    moduleName.pack();
	    startMode.pack();
	    progName.pack();
	    viewer = new TableViewer(moduleTable);
	    viewer.setContentProvider(new HTLModuleListContentProvider(globalTiming.getHTLProgramList().getProgramNames()));
	    viewer.setLabelProvider(new ThreeStringLabelProvider(globalTiming.getHTLProgramList().getProgramNames(), null, 2, -1));
	    viewer.setInput(moduleList);
	    moduleTable.setHeaderVisible(true);
	    moduleTable.setLinesVisible(true);
	    /* Make table directly editable */
	    viewer.setColumnProperties(new String[] {"0", "1", "2"});
	    viewer.setCellModifier(new HTLTableModifier(globalTiming.getHTLProgramList().getProgramNames(), null, 2, -1));
	    viewer.setCellEditors(new CellEditor[] {
	        new TextCellEditor(moduleTable),
	        new TextCellEditor(moduleTable),
	        new ComboBoxCellEditor(moduleTable, globalTiming.getHTLProgramList().getProgramNames())
	        });
	    
	    composite.setSize(220, 300);
	    return composite;
	  }

	  // @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
	  protected void configureShell(Shell newShell)
	  {
	    super.configureShell(newShell);
	    newShell.setText("Edit module names and start modes");
	  }

	  // @see org.eclipse.jface.dialogs.Dialog#okPressed()
	  protected void okPressed()
	  {
	    int count = 0;
	    Table moduleTable = viewer.getTable();
	    for (int i = 0; i < moduleTable.getItemCount(); i++) {
	      if (moduleTable.getItem(i).getText(0).length() > 0) {
	        count++;
	      }
	    }
	    HTLModule[] modes = new HTLModule[count];
	    for (int i = 0; i < moduleTable.getItemCount(); i++) {
	      TableItem item = moduleTable.getItem(i);
	      String name = item.getText(0);
	      String startMode = item.getText(1);
	      String program = item.getText(2);

	      if (name.length() > 0 && startMode.length() > 0 && program.length() > 0) {
	        modes[i] = new HTLModule(name, startMode, program);
	      }
	    }
	    moduleList = new HTLModuleList(modes);
	    super.okPressed();
	  }

	  /**
	   * Return the current ModeList value
	   * @return the current ModeList value
	   */
	  public HTLModuleList getModuleList()
	  {
	    return moduleList;
	  }

}
