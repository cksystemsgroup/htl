/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.draw2d.Label;
import java.util.List;

import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLExotaskGraphAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeList;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModule;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModuleList;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgram;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLProgramList;

import com.ibm.realtime.exotasks.editor.model.Communicator;
import com.ibm.realtime.exotasks.editor.model.Connection;
import com.ibm.realtime.exotasks.editor.model.GlobalTiming;
import com.ibm.realtime.exotasks.editor.model.LocalTiming;
import com.ibm.realtime.exotasks.editor.model.ModelElement;
import com.ibm.realtime.exotasks.editor.model.Predicate;
import com.ibm.realtime.exotasks.editor.model.Task;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * This class represents the global timing for HTL grammar
 * 
 * @author Daniel Iercan (diercan@aut.upt.ro)
 **/
public class HTLGlobalTiming extends GlobalTiming {

	/** Property ID for the Program List */
	  private static final String HTL_PROGRAM_LIST = "HTLGlobalTimingHTLProgramList";
	
	/** Property ID for the Module List */
	  private static final String HTL_MODULE_LIST = "HTLGlobalTimingHTLModuleList";
	
	/** Property ID for the Mode List */
	  private static final String HTL_MODE_LIST = "HTLGlobalTimingHTLModeList";
	  
	  /** Property Slow Down Factor */
	  private static final String SLOWDOWN_FACTOR = "SlowdownFactor";
		    	  
	  /** The property descriptors */
	  private final IPropertyDescriptor[] descriptors;
	  
	  private HTLModuleList moduleList;
	  private HTLModeList modeList;
	  private HTLProgramList programList;
	  private int slowdownFactor;
	  
	  /**
	   * Create a new SimpleMultiModeGlobalTiming by loading a graph
	   * @param modeList the ModeList timing annotation of the just-loaded graph
	   */
	  public HTLGlobalTiming(HTLExotaskGraphAnnotation pHTLStructure)
	  {
	    this.moduleList = (pHTLStructure!=null) ? pHTLStructure.getHTLModuleList() : 
	    	new HTLModuleList(new HTLModule[]{});
	    this.modeList = (pHTLStructure!=null) ? pHTLStructure.getHTLModeList() : 
	    	new HTLModeList(new HTLMode[]{});
	    this.programList = (pHTLStructure!=null) ? pHTLStructure.getHTLProgramList() : 
	    	new HTLProgramList(new HTLProgram[]{});
	    this.slowdownFactor = (pHTLStructure!=null) ? pHTLStructure.getSlowDownFactor() : 1;
	    
	    descriptors = new IPropertyDescriptor[] {
	    		new HTLProgramListPropertyDescriptor(HTL_PROGRAM_LIST, "Program List"),
	    	    new HTLModuleListPropertyDescriptor(HTL_MODULE_LIST, "Module List", this),
	    	    new HTLModeListPropertyDescriptor(HTL_MODE_LIST, "Mode List"),
	    	    new TextPropertyDescriptor(SLOWDOWN_FACTOR, "Slow Down Factor")
	    	  };
	    
	    computeToolTipAndColor();
	  }
	  
	  /**
	   * Create a new SimpleMultiModeGlobalTiming by dropping from the palette
	   */
	  public HTLGlobalTiming()
	  {
	    this(new HTLExotaskGraphAnnotation(new HTLProgramList(new HTLProgram[]{}), 
	    		new HTLModuleList(new HTLModule[]{}), new HTLModeList(new HTLMode[]{}), 1));
	  }

	  /**
	   * Get the list of modes in the program
	   * @return
	   */
	  public HTLModeList getHTLModeList(){
		  return modeList;
	  }
	  
	  /**
	   * Get the list of modes in the program
	   * @return
	   */
	  public HTLProgramList getHTLProgramList(){
		  return programList;
	  }
	  
	  public int getSlowDownFactor(){
		  return slowdownFactor;
	  }
	
	public LocalTiming getElementAnnotator(ModelElement element) {
		if(element instanceof Communicator)
			return new HTLCommunicatorLocalTiming(this);
		else if(element instanceof Predicate){
			return new HTLModeSwitchLocalTiming(this);
		}
		else if(element instanceof Connection){
			return new HTLConnectionAnnotationLocalTiming(this);
		}
		else if(element instanceof Task){
			return new HTLTaskAnnotationLocalTiming(this);
		}
		return null;
	}

	public ExotaskTimingData getAnnotation() {
		return new HTLExotaskGraphAnnotation(programList, moduleList, modeList, slowdownFactor);
	}

	public void setAnnotation(ExotaskTimingData annotation) {
		moduleList = ((HTLExotaskGraphAnnotation)annotation).getHTLModuleList();
		modeList = ((HTLExotaskGraphAnnotation)annotation).getHTLModeList();
		programList = ((HTLExotaskGraphAnnotation)annotation).getHTLProgramList();
		slowdownFactor = ((HTLExotaskGraphAnnotation)annotation).getSlowDownFactor();
		computeToolTipAndColor();		
	}

	public Object getEditableValue() {
		return this;
	}

		//@see org.eclipse.ui.views.properties.IPropertySource#getPropertyDescriptors()
	  public IPropertyDescriptor[] getPropertyDescriptors()
	  {
	    return descriptors;
	  }

	public Object getPropertyValue(Object id) {
		if (HTL_MODE_LIST.equals(id)) {
			return new HTLModeListWrapper(modeList, moduleList.getModuleNames(), programList.getProgramNames());
		}
		else if (HTL_MODULE_LIST.equals(id)) {
			return moduleList;
		}
		else if (HTL_PROGRAM_LIST.equals(id)) {
			return programList;
		}
		else if (SLOWDOWN_FACTOR.equals(id)) {
			return ""+slowdownFactor;
		}
		return null;
	}

	public boolean isPropertySet(Object id) {
		if (HTL_MODE_LIST.equals(id)) {
			return modeList.getModes().size() > 0;
		}
		else if (HTL_MODULE_LIST.equals(id)) {
			return moduleList.getModules().size() > 0;
		}
		else if (HTL_PROGRAM_LIST.equals(id)) {
			return programList.getPrograms().size() > 0;
		}
		else if (SLOWDOWN_FACTOR.equals(id)) {
			return true;
		}
		return false;
	}

	public void resetPropertyValue(Object id) {
		if (HTL_MODE_LIST.equals(id)) {
			modeList = new HTLModeList(new HTLMode[0]);
			computeToolTipAndColor();
		}
		else if (HTL_MODULE_LIST.equals(id)) {
			moduleList = new HTLModuleList(new HTLModule[0]);
			computeToolTipAndColor();	
		}
		else if (HTL_PROGRAM_LIST.equals(id)) {
			programList = new HTLProgramList(new HTLProgram[0]);
			computeToolTipAndColor();	
		}
		else if (SLOWDOWN_FACTOR.equals(id)) {
			slowdownFactor = 1;
			computeToolTipAndColor();	
		}
	}

	public void setPropertyValue(Object id, Object value) {
		if (HTL_MODE_LIST.equals(id)) {
			modeList = ((HTLModeListWrapper)value).getModeList();
			computeToolTipAndColor();	
		}
		else if (HTL_MODULE_LIST.equals(id)) {
			moduleList = (HTLModuleList)value;
			computeToolTipAndColor();	
		}
		else if (HTL_PROGRAM_LIST.equals(id)) {
			programList = (HTLProgramList)value;
			computeToolTipAndColor();	
		}
		else if (SLOWDOWN_FACTOR.equals(id)) {
			try{
				slowdownFactor = Integer.parseInt((String)value);
			}
			catch(Exception e){
				slowdownFactor = 1;
			}
			computeToolTipAndColor();	
		}
	}

	//@see com.ibm.realtime.exotasks.editor.model.ModelElement#getToolTipLabels(java.util.List)
	  public void getToolTipLabels(List labels)
	  {
	    Label label = new Label();
	    if (programList.getPrograms().size() == 0) {
		      label.setIcon(WARNING_IMAGE);
		      label.setText("At least one program must be specified");
		} else if (moduleList.getModules().size() == 0) {
		      label.setIcon(WARNING_IMAGE);
		      label.setText("At least one module must be specified");
		} else if (modeList.getModes().size() == 0) {
	      label.setIcon(WARNING_IMAGE);
	      label.setText("At least one mode must be specified");
	    } else {
	      label.setIcon(OK_IMAGE);
	      label.setText("Modules:" + moduleList + "\n Modes:" + modeList+"\nSlow Down Factor: "+slowdownFactor);
	    }
	    labels.add(label);
	  }
}
