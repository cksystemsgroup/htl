/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLMode;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeList;

import com.ibm.realtime.exotasks.timing.ExotaskTimingDataParser;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModeListDialog extends Dialog {

	/** Place to store the ModeList that is the content model for the dialog */
	  private HTLModeListWrapper modeList;
	 	  	  
	  /** The TableViewer in use in this dialog */
	  private TableViewer viewer;
	     
	  /**
	   * Create a new ModeListDialog
	   * @param shell the governing shell
	   * @param modeList the current mode list
	   */
	  public HTLModeListDialog(Shell shell, HTLModeListWrapper modeList)
	  {
	    super(shell);
	    this.modeList = modeList;
	  }

	  // @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
	  protected Control createDialogArea(Composite parent)
	  {
	    Composite composite = (Composite)super.createDialogArea(parent);
	    Table modeTable = new Table(composite, SWT.BORDER | SWT.SINGLE | SWT.FULL_SELECTION);
	    TableColumn modeName = new TableColumn(modeTable, SWT.LEFT);
	    modeName.setText("Mode Name");
	    modeName.setWidth(80);
	    TableColumn modePeriod = new TableColumn(modeTable, SWT.LEFT);
	    modePeriod.setText("Mode Period");
	    TableColumn modeModule = new TableColumn(modeTable, SWT.LEFT);
	    modeModule.setText("Parent Module");
	    modeModule.setWidth(80);
	    TableColumn modeRefProg = new TableColumn(modeTable, SWT.LEFT);
	    modeRefProg.setText("Refining Program");
	    modeRefProg.setWidth(80);
	    modeName.pack();
	    modePeriod.pack();
	    modeModule.pack();
	    modeRefProg.pack();
	    viewer = new TableViewer(modeTable);
	    viewer.setContentProvider(new HTLModeListContentProvider());
	    viewer.setLabelProvider(new ThreeStringLabelProvider(modeList.getModuleNames(), modeList.getProgramNames(), 2, 3));
	    viewer.setInput(modeList);
	    modeTable.setHeaderVisible(true);
	    modeTable.setLinesVisible(true);
	    /* Make table directly editable */
	    viewer.setColumnProperties(new String[] {"0", "1", "2", "3"});
	    viewer.setCellModifier(new HTLTableModifier(modeList.getModuleNames(), modeList.getProgramNames(), 2, 3));
	    viewer.setCellEditors(new CellEditor[] {
	        new TextCellEditor(modeTable),
	        new TextCellEditor(modeTable),
	       // new TextCellEditor(modeTable)
	        new ComboBoxCellEditor(modeTable, modeList.getModuleNames()),
	        new ComboBoxCellEditor(modeTable, modeList.getProgramNames())
	        });
	    
	    composite.setSize(220, 300);
	    return composite;
	  }

	  // @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
	  protected void configureShell(Shell newShell)
	  {
	    super.configureShell(newShell);
	    newShell.setText("Edit mode names, periods and modules");
	  }

	  // @see org.eclipse.jface.dialogs.Dialog#okPressed()
	  protected void okPressed()
	  {
	    int count = 0;
	    Table modeTable = viewer.getTable();
	    for (int i = 0; i < modeTable.getItemCount(); i++) {
	      if (modeTable.getItem(i).getText(0).length() > 0) {
	        count++;
	      }
	    }
	    HTLMode[] modes = new HTLMode[count];
	    for (int i = 0; i < modeTable.getItemCount(); i++) {
	      TableItem item = modeTable.getItem(i);
	      String name = item.getText(0);
	      long period = ExotaskTimingDataParser.parseTime(item.getText(1));
	      String module =  item.getText(2);
	      
	      if (name.length() > 0 && period > 0 && module.length() > 0) {
	    	  String program = item.getText(3);
	        modes[i] = new HTLMode(name, period, module, program);
	      }
	    }
	    modeList = new HTLModeListWrapper(new HTLModeList(modes), modeList.getModuleNames(), modeList.getProgramNames());
	    super.okPressed();
	  }

	  /**
	   * Return the current ModeList value
	   * @return the current ModeList value
	   */
	  public HTLModeListWrapper getModeList()
	  {
	    return modeList;
	  }

	
}
