/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import java.io.IOException;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLExotaskGraphAnnotation;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLTimingDataParser;

import com.ibm.realtime.exotasks.editor.model.GlobalTiming;
import com.ibm.realtime.exotasks.editor.model.TimingGrammarProvider;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingDataParser;

public class HTLGrammarProvider implements TimingGrammarProvider
{
  // Note: The following assumes the plugin is installed a JAR instead of being unzipped.  We might
  // want to revisit this, especially if this plugin is made part of the feature.
  private static final String EXOTASK_HTL_JAR = "exotaskHTL.jar";
  private static final String EXOTASK_HTL_PLUGIN = 
    "at.uni_salzburg.cs.exotasks.editor.timing.htl";

  public String getDescription()
  {
    return "Use HTL timing grammar";
  }

  public GlobalTiming getGlobalTiming(ExotaskTimingData annotation)
  {
    if(annotation instanceof HTLExotaskGraphAnnotation)
    	return new HTLGlobalTiming((HTLExotaskGraphAnnotation)annotation);
    return null;
  }

  public String getLabel()
  {
    return "HTL timing";
  }

  public Class getTemplateClass()
  {
    return HTLGlobalTiming.class;
  }

  public ExotaskTimingDataParser getParser()
  {
    return new HTLTimingDataParser();
  }

  // @see com.ibm.realtime.exotasks.editor.model.TimingGrammarProvider#getLibrary()
  public String[] getLibraries()
  {
    try {
      String library = FileLocator.toFileURL(Platform.getBundle(EXOTASK_HTL_PLUGIN)
          .getEntry(EXOTASK_HTL_JAR)).getPath();
      return new String[] {library};
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }
}
