/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import java.util.List;

import org.eclipse.draw2d.Label;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeAssignment;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLTaskAnnotation;

import com.ibm.realtime.exotasks.editor.model.LocalTiming;
import com.ibm.realtime.exotasks.editor.model.ModelElement;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLTaskAnnotationLocalTiming implements LocalTiming {
	public static final String ASSIGNED_MODES = "HTL_EXOTASK_ANNOTATION_ASSIGNED_MODES";
	public static final String ABSTRACT = "HTL_EXOTASK_ANNOTATION_ABSTRACT";
	public static final String PARENT = "HTL_EXOTASK_ANNOTATION_PARENT";
	
	private HTLTaskAnnotation annotation; 
	
	private IPropertyDescriptor[] propertyDescriptors;
	
	public HTLTaskAnnotationLocalTiming(HTLGlobalTiming pGlobalTiming){
		annotation = new HTLTaskAnnotation(new HTLModeAssignment[]{}, false, "");
		propertyDescriptors = new IPropertyDescriptor[]{
				new BooleanPropertyDescriptor(ABSTRACT, "Is Abstract"),
				new HTLModeAssignmentPropertyDescriptor(ASSIGNED_MODES, "Assigned Modes", pGlobalTiming),
				new TextPropertyDescriptor(PARENT, "Parent Task"),
		};
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#getAnnotation()
	 */
	public ExotaskTimingData getAnnotation() {
		return annotation;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#getToolTipLabels(java.util.List)
	 */
	public void getToolTipLabels(List labels) {
		Label label = new Label();
	    if (annotation.getModes().size() == 0) {
	      label.setIcon(ModelElement.WARNING_IMAGE);
	      label.setText("There has to be at least one mode assigned to the task invocation");
	    } else {
	      label.setIcon(ModelElement.OK_IMAGE);
	      label.setText("Modes Assigned: "+annotation.toString());
	    }
	    labels.add(label);
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#setAnnotation(com.ibm.realtime.exotasks.timing.ExotaskTimingData)
	 */
	public void setAnnotation(ExotaskTimingData annotation) {
		if(annotation == null)
			this.annotation = new HTLTaskAnnotation(new HTLModeAssignment[]{}, false, "");
		else{
			this.annotation = (HTLTaskAnnotation)annotation;
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getEditableValue()
	 */
	public Object getEditableValue() {
		return this;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		// TODO Auto-generated method stub
		return propertyDescriptors;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getPropertyValue(java.lang.Object)
	 */
	public Object getPropertyValue(Object id) {
		if(id.equals(ASSIGNED_MODES)){
			return new AssignedModes(annotation.getModeNames());
		}
		else if(id.equals(ABSTRACT)){
			return new Boolean(annotation.IsAbstract());
		}
		else if(id.equals(PARENT)){
			return annotation.getParentTask();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#isPropertySet(java.lang.Object)
	 */
	public boolean isPropertySet(Object id) {
		if(id.equals(ASSIGNED_MODES)){
			return annotation.getModes().size() > 0;
		}
		else if(id.equals(ABSTRACT)){
			return true;
		}
		else if(id.equals(PARENT)){
			return !annotation.getParentTask().equals("");
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#resetPropertyValue(java.lang.Object)
	 */
	public void resetPropertyValue(Object id) {
		if(id.equals(ASSIGNED_MODES)){
			annotation.setModeNames(new String[]{});
		}
		else if(id.equals(ABSTRACT)){
			annotation.setAbstract(false);
		}
		else if(id.equals(PARENT)){
			annotation.setParentTask("");
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#setPropertyValue(java.lang.Object, java.lang.Object)
	 */
	public void setPropertyValue(Object id, Object value) {
		if(id.equals(ASSIGNED_MODES)){
			annotation.setModeNames(((AssignedModes)value).modes);
		}
		else if(id.equals(ABSTRACT)){
			annotation.setAbstract(((Boolean)value).booleanValue());
		}
		else if(id.equals(PARENT)){
			annotation.setParentTask((String)value);
		}
	}

}
