/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class ThreeStringLabelProvider extends LabelProvider implements
		ITableLabelProvider {

	private String[] names1;
	private String[] names2;
	private int firstIndex=-1;
	private int secondIndex=-1;
	
	public ThreeStringLabelProvider(){
		
	}
	
	public ThreeStringLabelProvider(String[] names1, String[] names2,
			int firstIndex, int secondIndex){
		this.names1 = names1;
		this.names2 = names2;
		this.firstIndex = firstIndex;
		this.secondIndex = secondIndex;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnImage(java.lang.Object, int)
	 */
	public Image getColumnImage(Object element, int columnIndex) {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnText(java.lang.Object, int)
	 */
	public String getColumnText(Object element, int columnIndex) {
		Object elemData = ((Object[]) element)[columnIndex];
		
		if(elemData instanceof Integer){
			//for modes editor
			Integer idx = ((Integer)elemData);
			if(columnIndex==firstIndex){
				if(idx.intValue() >= 0 && names1!=null && idx.intValue() < names1.length){
					return names1[idx.intValue()];
				}
				else
					return "";
			}
			else if(columnIndex==secondIndex){
				if(idx.intValue() >= 0 && names2!=null && idx.intValue() < names2.length){
					return names2[idx.intValue()];
				}
				else
					return "";
			}
			return "";
		}
		else
			return elemData.toString();
	}

}
