/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import java.util.List;

import org.eclipse.draw2d.Label;
import org.eclipse.ui.views.properties.IPropertyDescriptor;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeAssignment;
import at.uni_salzburg.cs.exotasks.timing.htl.HTLModeSwitch;

import com.ibm.realtime.exotasks.editor.model.LocalTiming;
import com.ibm.realtime.exotasks.editor.model.ModelElement;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLModeSwitchLocalTiming implements LocalTiming {

	public static final String MODE = "HTLModeSwitchMode";
	public static final String TARGET = "HTLModeSwitchTarget";
	
	private IPropertyDescriptor[] propertyDescryptors;
	
	private HTLModeSwitch annotation;
	
	public HTLModeSwitchLocalTiming(HTLGlobalTiming pGlobalTiming){
		annotation = new HTLModeSwitch(new HTLModeAssignment[]{}, "");
		propertyDescryptors = new IPropertyDescriptor[]{
				new HTLModeAssignmentPropertyDescriptor(MODE, "Assigned Modes", pGlobalTiming),
				new ComboBoxPropertyDescriptor(TARGET, "Target Mode", pGlobalTiming, ComboBoxPropertyDescriptor.EDIT_MODES),
		};
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#getAnnotation()
	 */
	public ExotaskTimingData getAnnotation() {
		return annotation;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#getToolTipLabels(java.util.List)
	 */
	public void getToolTipLabels(List labels) {
		Label label = new Label();
	    if (annotation.getModes().size() == 0) {
	      label.setIcon(ModelElement.WARNING_IMAGE);
	      label.setText("At least one source mode has to be specified");
	    } else if (annotation.getTargetMode().length() == 0) {
		      label.setIcon(ModelElement.WARNING_IMAGE);
		      label.setText("Target mode has to be specified");
		} else if (annotation.isAssignedTo(annotation.getTargetMode())) {
		      label.setIcon(ModelElement.WARNING_IMAGE);
		      label.setText("Source mode and target mode can not be the same");
		} else {
	      label.setIcon(ModelElement.OK_IMAGE);
	      label.setText(annotation.toString());
	    }
	    labels.add(label);
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#setAnnotation(com.ibm.realtime.exotasks.timing.ExotaskTimingData)
	 */
	public void setAnnotation(ExotaskTimingData annotation) {
		if(annotation == null){
			this.annotation = new HTLModeSwitch(new HTLModeAssignment[]{}, "");
		}
		else{
			this.annotation = (HTLModeSwitch)annotation;
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getEditableValue()
	 */
	public Object getEditableValue(){ 
		return this;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		return propertyDescryptors;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getPropertyValue(java.lang.Object)
	 */
	public Object getPropertyValue(Object id) {
		if(id.equals(MODE)){
			return new AssignedModes(annotation.getModeNames());
		}
		else if(id.equals(TARGET)){
			return annotation.getTargetMode();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#isPropertySet(java.lang.Object)
	 */
	public boolean isPropertySet(Object id) {
		if(id.equals(MODE)){
			return annotation.getModes().size() > 0;
		}
		else if(id.equals(TARGET)){
			return annotation.getTargetMode().length() > 0;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#resetPropertyValue(java.lang.Object)
	 */
	public void resetPropertyValue(Object id) {
		if(id.equals(MODE)){
			annotation.setModeNames(new String[]{});
		}
		else if(id.equals(TARGET)){
			annotation.setTargetMode("");
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#setPropertyValue(java.lang.Object, java.lang.Object)
	 */
	public void setPropertyValue(Object id, Object value) {
		if(id.equals(MODE)){
			annotation.setModeNames(((AssignedModes)value).modes);
		}
		else if(id.equals(TARGET)){
			annotation.setTargetMode((String)value);
		}
	}

}
