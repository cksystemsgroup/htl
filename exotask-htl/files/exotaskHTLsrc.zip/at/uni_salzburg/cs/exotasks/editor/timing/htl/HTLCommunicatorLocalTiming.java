/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import java.util.List;

import org.eclipse.draw2d.Label;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;

import at.uni_salzburg.cs.exotasks.timing.htl.HTLCommunicatorAnnotation;

import com.ibm.realtime.exotasks.editor.model.LocalTiming;
import com.ibm.realtime.exotasks.editor.model.ModelElement;
import com.ibm.realtime.exotasks.timing.ExotaskTimingData;
import com.ibm.realtime.exotasks.timing.ExotaskTimingDataParser;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
public class HTLCommunicatorLocalTiming implements LocalTiming {

	public static final String PROGRAM = "HTL_COMMUNICATOR_PROGRAM";
	
	/**The key of the period property*/
	public static final String PERIOD = "HTL_COMMUNICATOR_PERIOD"; 
	
	/**Communicator annotation object*/
	private HTLCommunicatorAnnotation annotation;
	
	/** The property descriptors */
    private IPropertyDescriptor[] descriptors;

	
	public HTLCommunicatorLocalTiming(HTLGlobalTiming pGlobalTiming){
		annotation = new HTLCommunicatorAnnotation(0, "");
		descriptors = new IPropertyDescriptor[]{
				new TextPropertyDescriptor(PERIOD, "Set communicator period."),
				new ComboBoxPropertyDescriptor(PROGRAM, "Parent Program", pGlobalTiming, ComboBoxPropertyDescriptor.EDIT_PROGRAMS)
		};
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#getAnnotation()
	 */
	public ExotaskTimingData getAnnotation() {
		return annotation;
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#getToolTipLabels(java.util.List)
	 */
	public void getToolTipLabels(List labels) {
		Label label = new Label();
	    if (annotation.getPeriod() <= 0) {
	      label.setIcon(ModelElement.WARNING_IMAGE);
	      label.setText("Period of a communicator must be greater then zero");
	    } else if (annotation.getProgram().length() == 0) {
		      label.setIcon(ModelElement.WARNING_IMAGE);
		      label.setText("No program was specified for communicator");
		} else {
	      label.setIcon(ModelElement.OK_IMAGE);
	      label.setText(annotation.toString());
	    }
	    labels.add(label);
	}

	/* (non-Javadoc)
	 * @see com.ibm.realtime.exotasks.editor.model.LocalTiming#setAnnotation(com.ibm.realtime.exotasks.timing.ExotaskTimingData)
	 */
	public void setAnnotation(ExotaskTimingData annotation) {
		if(annotation!=null){
			this.annotation = (HTLCommunicatorAnnotation)annotation;
		}
		else{
			this.annotation = new HTLCommunicatorAnnotation(0, "");
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getEditableValue()
	 */
	public Object getEditableValue() {
		return this;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		return descriptors;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#getPropertyValue(java.lang.Object)
	 */
	public Object getPropertyValue(Object id) {
		if(PERIOD.equals(id)){
			return ExotaskTimingDataParser.formatTime(annotation.getPeriod());
		}
		else if(PROGRAM.equals(id)){
			return annotation.getProgram();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#isPropertySet(java.lang.Object)
	 */
	public boolean isPropertySet(Object id) {
		if(PERIOD.equals(id)){
			return annotation.getPeriod()>0;
		}
		else if(PROGRAM.equals(id)){
			return annotation.getProgram().length() > 0;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#resetPropertyValue(java.lang.Object)
	 */
	public void resetPropertyValue(Object id) {
		if(id.equals(PERIOD))
			annotation.setPeriod(0);
		else if(PROGRAM.equals(id))
			annotation.setProgram("");
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.views.properties.IPropertySource#setPropertyValue(java.lang.Object, java.lang.Object)
	 */
	public void setPropertyValue(Object id, Object value) {
		if(PERIOD.equals(id)){
			try{
				annotation.setPeriod(ExotaskTimingDataParser.parseTime((String)value));
			}
			catch(Exception e){
				annotation.setPeriod(0);
			}
		}
		else if(PROGRAM.equals(id))
			annotation.setProgram((String)value);
	}

}
