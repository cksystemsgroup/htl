/* 
 * The MIT License
 * 
 * Copyright (c) 2007 University of Salzburg, www.uni-salzburg.at
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package at.uni_salzburg.cs.exotasks.editor.timing.htl;

import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.swt.widgets.TableItem;

/**
 * @author Daniel Iercan (diercan@aut.upt.ro)
 *
 **/
class HTLTableModifier implements ICellModifier {

	private String[] names1;
	private String[] names2;
	private int firstIndex;
	private int secondIndex;
	
	public HTLTableModifier(String[] names1, String[] names2, int firstIndex, int secondIndex){
		this.names1 = names1;
		this.names2 = names2;
		this.firstIndex = firstIndex;
		this.secondIndex = secondIndex; 
	}
	
	public HTLTableModifier(){
		
	}
	
	 // @see org.eclipse.jface.viewers.ICellModifier#canModify(java.lang.Object, java.lang.String)
	  public boolean canModify(Object element, String property)
	  {
	    return property != null;
	  }

	  // @see org.eclipse.jface.viewers.ICellModifier#getValue(java.lang.Object, java.lang.String)
	  public Object getValue(Object element, String property)
	  {
	    if (property == null || element == null) {
	      return "";
	    }
	    int index = property.charAt(0) - '0';
	    return ((Object[]) element)[index];
	  }

	  // @see org.eclipse.jface.viewers.ICellModifier#modify(java.lang.Object, java.lang.String, java.lang.Object)
	  public void modify(Object element, String property, Object value)
	  {
	    if (property != null || element != null) {
	      int index = property.charAt(0) - '0';
	      TableItem item = (TableItem) element;
	      Object[] data = (Object[]) item.getData();
	      data[index] = value;
	      item.setData(data);
	      
	      if(data[index] != null){
	    	  if(value instanceof Integer){
	 
	    		  Integer idx = (Integer)value;
	    		  
	    		  if(index == firstIndex){
		    		  if(idx.intValue() >= 0 && names1!=null && idx.intValue() < names1.length){
		    			  item.setText(index, names1[idx.intValue()]);
		    		  }
		    		  else{
		    			  item.setText(index, "");
		    		  }
	    		  } else if(index == secondIndex){
		    		  if(idx.intValue() >= 0 && names2!=null && idx.intValue() < names2.length){
		    			  item.setText(index, names2[idx.intValue()]);
		    		  }
		    		  else{
		    			  item.setText(index, "");
		    		  }
	    		  }
	    		  else
	    			  item.setText(index, "");
	    	  }
	    	  else{
	    		  item.setText(index, data[index].toString());
	    	  }
	      }
	      else
	    	  item.setText(index, "");
	    }
	  }

}
