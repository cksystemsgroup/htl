/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

/*

  Author: Christoph Kirsch, 	cm@eecs.berkeley.edu
          Slobodan Matic, 		matic@eecs.berkeley.edu
          Daniel Iercan, 		diercan@cs.uni-salzburg.at

*/

#include "f_code.h"

#define MAX_HISTORY 10
#define PRAG_1 0.006
#define PRAG_2 0.006
#define PRAG_PI_LR 5

double Dh1_history[MAX_HISTORY];
double Dh2_history[MAX_HISTORY];
double Dh1c_history[MAX_HISTORY];
double Dh2c_history[MAX_HISTORY];

int v11;
int v12;
int v21;
int v22;

int port = 0;
char ip[16];
double hRez1 = 10;
double hRez2 = 20;
int idSocket;
int conectat;
double uPI1;
double uPI2;
double H1c_tm1;
double H1c_t;
double U1_tm1;
double U1_tm2;
double DH1c;
double U1_tm2;
double U1_tm1;
double H1_tm1;
double H1_t;
double DH1;
double H2c_tm1;
double H2c_t;
double U2_tm1;
double U2_tm2;
double DH2c;
double U2_tm2;
double U2_tm1;
double H2_tm1;
double H2_t;
double DH2;
double H1F_tm1;
double H2F_tm1;
double DH1c_tm1;
double DH1c_tm2;
double DH2c_tm1;
double DH2c_tm2;
double a0 = 1.0;
double a1 = -0.6128;
double b0 = 0.1936;
double b1 = 0.1936;

double kr = 25;//simulator 25;//285.714;
double Tr_R = 15.0;//simulator 15.0
double krPI_R = 50.0;//simulator 40.0
double Tr_L = 15.0;
double krPI_L = 30.0;

void f_code_init(int hostID){
	//3TS
	v11 = 0;
	v12 = 0;
	v21 = 0;
	v22 = 0;
	uPI1 = 0;
	uPI2 = 0;
	uPI1 = 0;
	uPI2 = 0;
	H1c_tm1 = 0;
	H1c_t = 0;
	U1_tm1 = 0;
	U1_tm2 = 0;
	DH1c = 0;
	U1_tm2 = 0;
	U1_tm1 = 0;
	H1_tm1 = 0;
	H1_t = 0;
	DH1 = 0;
	H2c_tm1 = 0;
	H2c_t = 0;
	U2_tm1 = 0;
	U2_tm2 = 0;
	DH2c = 0;
	U2_tm2 = 0;
	U2_tm1 = 0;
	H2_tm1 = 0;
	H2_t = 0;
	DH2 = 0;
	H1F_tm1 = 0;
	H2F_tm1 = 0;
	DH1c_tm1 = 0;
	DH1c_tm2 = 0;
	DH2c_tm1 = 0;
	DH2c_tm2 = 0;
	char linie[256];
	int rez = 0;
	int i = 0;
	for (i = 0;i<MAX_HISTORY;i++)
	{
		Dh1_history[i] = 0;
		Dh2_history[i] = 0;
		Dh1c_history[i] = 0;
		Dh2c_history[i] = 0;

	}
	FILE *fisierConfigurare;
	fisierConfigurare = fopen("configurare","r");
	fgets(linie,sizeof(linie),fisierConfigurare);
	linie[strlen(linie)-1] = '\0';
	if (strcmp(linie,"CONFIGURARE_3TS") == 0)
	{
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"Adresa IP = %s",ip);
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"Port = %d",&port);
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"h1 = %lf",&hRez1);
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"h2 = %lf",&hRez2);
	}
	if (fisierConfigurare != NULL)
		fclose(fisierConfigurare);

	if(hostID==0){
		//realizarea conexiunii
		struct sockaddr_in sa;
			
		idSocket = socket(AF_INET, SOCK_STREAM, 0);
		if (idSocket != -1)
		{
			bzero((char *) &sa, sizeof(sa));
			sa.sin_family = AF_INET;
			sa.sin_addr.s_addr = inet_addr(ip);
			sa.sin_port = htons(port);
			conectat = connect(idSocket,(struct sockaddr *) &sa,sizeof(sa));
			if (conectat == -1)
			{
				printf("Client not connected.\n");
				//return 0;
			}
			else
			{
				printf("Client connected.\n");
			}
		}
	}
	else
	{
	    conectat = -1;
	    printf("2Client not connected.\n");
	}
	
//3TS
}

void c_connect_sensor_to_return_key(c_bool *sensor) {
  *sensor = os_key_event();
}

void c_connect_sensor_to_random_generator(c_int *sensor) {
  unsigned i, text_message_length;

#ifdef OSEK
  *sensor = (*sensor + 1) % 10;
#else
  *sensor = 1 + (int)(MAXDISPLAY*(double)rand()/(RAND_MAX+1.0));
#endif

  sprintf(text_message, "\t\tSensor reading:  ");

  text_message_length = strlen(text_message);

  for(i = text_message_length; i < *sensor + text_message_length; i++)
    text_message[i] = '*';

  text_message[i] = 0;

  os_print_message(text_message);
}

void c_connect_actuator_to_display(c_string *string) {
  sprintf(text_message, "\t\tActuator update: %s", *string);

  os_print_message(text_message);
}

void c_empty_string(c_string *string) {
  **string = 0;
}

void copy_c_string(c_string *string_source, c_string *string_dest) {
  char *s = (char *) *string_source, *d = (char *) string_dest;

  while (*s)
    *d++ = *s++;

  *d = 0;
}

void c_one(c_int *integer) {
  *integer=1;
}

void copy_c_int(c_int *integer_source, c_int *integer_dest) {
  *integer_dest=*integer_source;
}

void copy_c_double(c_double *d_source, c_double *d_dest){
	*d_dest = *d_source;
}

unsigned c_true() {
  return 1;
}

void c_string_to_string(c_string *string_source, c_string *string_dest) {
  copy_c_string(string_source, string_dest);
}

unsigned c_key_pressed(c_bool *pressed) {
  return *pressed;
}


void c_int_to_int(c_int *integer_source, c_int *integer_dest) {
  copy_c_int(integer_source, integer_dest);
}

void giotto_timer_enable_code(e_machine_type e_machine_func, int relative_time) {
}

int giotto_timer_save_code(void) {
  return get_logical_time();
}

/**
 * dependency is current dependency
 * initial_dep is the initial dependency
 **/
unsigned giotto_timer_trigger_code(int initial_time, int relative_time, unsigned long long dependency, unsigned long long initial_dep) {
	unsigned logic_time = get_logical_time();
	unsigned compute_time = (initial_time + relative_time) % get_logical_time_overflow();
	
	if (initial_dep == 0)
		return (logic_time == compute_time) || relative_time==0;
	
	if (dependency == 0)
		return (logic_time >= compute_time)  || relative_time==0;
		
	return 0;
  //return (get_logical_time() >= (initial_time + relative_time) % get_logical_time_overflow());
}

void c_zero(c_int *integer){
	*integer=0;
}

//diploma_3TS
#define LUNGIME_MESAJ_DA_INALTIMILE 1
#define TIP_MESAJ 0
#define TIP_MESAJ_DA_INALTIMILE 71
#define LUNGIME_MESAJ_PRIMESTE_VALORI 7
#define TIP_MESAJ_SETEAZA_VALOARE 70
#define POMPA 1
#define LUNGIME_MESAJ_SETEAZA_VALOARE 4

double Convertest2OctetiLaDouble(char *data, int start)
{
	int numar = Converteste2OctetiLaIntreg(data, start);
	return numar*0.01;
}

int Converteste2OctetiLaIntreg(char *data, int start)
{
	unsigned int numar = 0;
	numar = data[start];
	numar = numar << 8;
	unsigned int nr = 0;
	nr = data[start+1];
	nr = nr & 0x00ff;
	numar = numar | nr;
	return numar;
}

void ConvertesteIntregLa2Octeti(char *data, int valoare, int pozitie)
{
	char mesaj[2];
	unsigned int val = valoare;
	val = val >> 8;
	val = val & 0x00FF;
	mesaj[0] = val;
	val = valoare;
	val = val & 0x00FF;
	mesaj[1] = val;
	memcpy(&data[pozitie], mesaj, sizeof(mesaj));
}

int DoubleLaInt(double inaltimeRezervor)
{
	int valoare = 0;
	valoare = inaltimeRezervor*100;
	return valoare;
}

char mesaj1[16];

void f_read(c_double *h1, c_double *h2)
{
	if (conectat != -1)
	{
		bzero((char *) &mesaj1, sizeof(mesaj1));
		mesaj1[TIP_MESAJ] = TIP_MESAJ_DA_INALTIMILE;
		write(idSocket,mesaj1,LUNGIME_MESAJ_DA_INALTIMILE);
		bzero((char *) &mesaj1, sizeof(mesaj1));
		read(idSocket, mesaj1, LUNGIME_MESAJ_PRIMESTE_VALORI);
		if (mesaj1[TIP_MESAJ] == TIP_MESAJ_DA_INALTIMILE)
		{
			*h1  = Convertest2OctetiLaDouble(mesaj1, 1);
			*h2 = Convertest2OctetiLaDouble(mesaj1, 3);
		}
	}
	else
		printf("Client not connected.\n");
}

void f_writeU(c_double *u, int pompNo){
    if (conectat != -1)
	{
		bzero((char *) &mesaj1, sizeof(mesaj1));
		mesaj1[TIP_MESAJ] = TIP_MESAJ_SETEAZA_VALOARE;
		mesaj1[POMPA] = pompNo;
		int u_int = DoubleLaInt(*u);
		if (u_int < 0)
		    u_int = 0;
		ConvertesteIntregLa2Octeti(mesaj1, u_int, 2);
		write(idSocket, mesaj1, LUNGIME_MESAJ_SETEAZA_VALOARE);
	}
	else
		printf("Client not connected.\n");
}

#define TIP_MESAJ_SETEAZA_VALORILE 40
#define LUNGIME_MESAJ_SETEAZA_VALORILE 13

void f_write(c_double *u1, c_double *u2, c_double *h1f, c_double *h2f, c_double *h1c, c_double *h2c)
{
	if (conectat != -1)
	{
		bzero((char *) &mesaj1, sizeof(mesaj1));
		mesaj1[TIP_MESAJ] = TIP_MESAJ_SETEAZA_VALORILE;
		int u_int = DoubleLaInt(*u1);
		if (u_int < 0)
		    u_int = 0;
		ConvertesteIntregLa2Octeti(mesaj1, u_int, 1);
		ConvertesteIntregLa2Octeti(mesaj1, DoubleLaInt(*h1f), 3);
		ConvertesteIntregLa2Octeti(mesaj1, DoubleLaInt(*h1c), 5);
		u_int = DoubleLaInt(*u2);
		if (u_int < 0)
		    u_int = 0;
		ConvertesteIntregLa2Octeti(mesaj1, u_int, 7);
		ConvertesteIntregLa2Octeti(mesaj1, DoubleLaInt(*h2f), 9);
		ConvertesteIntregLa2Octeti(mesaj1, DoubleLaInt(*h2c), 11);
		write(idSocket, mesaj1, LUNGIME_MESAJ_SETEAZA_VALORILE);
	}
	else
		printf("Client not connected.\n");
//	f_writeU(u1, 1);
//	f_writeU(u2, 2);
}

//#define C 0.0000107
#define C 0.000012
#define A 0.0154

double integrareU(double U, double t){
    return (U*C)/A * t;
}

void addNewValue(double history[], double value)
{
	int i = 0;
	for (i=1;i<MAX_HISTORY;i++)
	{
		history[i-1] = history[i];
	}
	history[MAX_HISTORY-1] = value;
}

int compareHistory(double history[], double historyC[], double prag)
{
	double m = 0, mC = 0;
	int i = 0;
	for (i=0;i<MAX_HISTORY;i++)
	{
		m += history[i];
		mC += historyC[i];
	}
	//printf("m: %lf    mC: %lf   Dif: %lf\n", m, mC, modul(m-mC));
	if (modul(m - mC) < prag)
		return 0;
	else
		return 1;
	}

void f_estimateH1(c_double *iH1, c_double *iU1, c_bool *oV1, c_double *oH1c, c_bool *oPI_LR1)
{
	printf("estimare1\n");
	H1c_tm1 = H1c_t;
	H1c_t = H1c_tm1 + integrareU(U1_tm1, 0.4)+integrareU(U1_tm2, 0.1);
	*oH1c = H1c_t;
	DH1c_tm2 = DH1c_tm1;
	DH1c_tm1 = DH1c;
	DH1c = H1c_t - H1c_tm1;
	U1_tm2 = U1_tm1;
	U1_tm1 = *iU1;
	H1_tm1 = H1_t;
	H1_t = (*iH1)/100.0;
	DH1 = H1_t - H1_tm1;
	addNewValue(Dh1_history, DH1);
	addNewValue(Dh1c_history, DH1c_tm2);
	if (modul(hRez1/100 - H1_t) < 0.02)
	{
		*oV1 = 1;
		v12 = v11;
		v11 = 1;
	}
	else
	if(DH1 != 0){
	    if (compareHistory(Dh1_history, Dh1c_history, PRAG_1))
    	    {
			if (v11 == 1)// && v12 == 1)
			{
				*oV1 = 1;
			}
			//v12 = v11;
			v11 = 1;
	    }
	    else
	    {
		
			if (v11 == 0)// && v12 == 0)
			{
				*oV1 = 0;
}
			//v12 = v11;
			v11 = 0;
}
}
	else{
	printf("zero1");
		if (DH1c_tm2 != 0 && DH1c_tm2 > PRAG_1)
		{
			*oV1 = 1;
			//v12 = v11;
			v11 = 1;
			
		}
		else
		{
			//v12 = v11;
			v11 = 0;
			*oV1 = 0;
			
		}
	}
	if (modul(hRez1 - *iH1) < PRAG_PI_LR)
		*oPI_LR1 = 1;
	else
		*oPI_LR1 = 0;
}

double nr2 = 0;
double sum2 = 0;
double med2 = 0;

double modul(double value)
{
	if (value < 0)
		return -1*value;
	else
		return value;
}

void f_estimateH2(c_double *iH2, c_double *iU2, c_bool *oV2, c_double *oH2c, c_bool *oPI_LR2)
{
	printf("estimare2\n");
	H2c_tm1 = H2c_t;
	H2c_t = H2c_tm1 + integrareU(U2_tm1, 0.4)+integrareU(U2_tm2, 0.1);
	*oH2c = H2c_t;
	DH2c_tm2 = DH2c_tm1;
	DH2c_tm1 = DH2c;
	DH2c = H2c_t - H2c_tm1;
	U2_tm2 = U2_tm1;
	U2_tm1 = *iU2;
	H2_tm1 = H2_t;
	H2_t = (*iH2)/100.0;
	double m = DH2c_tm2 - DH2;
	DH2 = H2_t - H2_tm1;
	addNewValue(Dh2_history, DH2);
	addNewValue(Dh2c_history, DH2c_tm2);
	if (modul(hRez2/100 - H2_t) < 0.02)
	{
		*oV2 = 1;
		v22 = v21;
		v21 = 1;
	}
	else
	if(DH2 != 0){
	    if (compareHistory(Dh2_history, Dh2c_history, PRAG_2))
    	    {
		    if (v21 == 1)// && v22 == 1)
			{
				*oV2 = 1;
			}
			//v22 = v21;
			v21 = 1;
	    }
	    else
	    {
		    if (v21 == 0)// && v22 == 0)
			{
				*oV2 = 0;
}
			//v22 = v21;
			v21 = 0;

}
}
	else{
	printf("zero2");
		if (DH2c_tm2 != 0 && DH2c_tm2 > PRAG_2)
		{
			*oV2 = 1;
			//v22 = v21;
			v21 = 1;
		}
		else
		{
			//v22 = v21;
			v21 = 0;
			*oV2 = 0;
		}
	}
	if (modul(hRez2 - *iH2) < PRAG_PI_LR)
		*oPI_LR2 = 1;
	else
		*oPI_LR2 = 0;
}

void f_filterH1(c_double *iH1, c_double *oH1_F, c_double *oH1f)
{
	*oH1_F = (-1*a1*H1F_tm1+b0*(*iH1)+b1*H1F_tm1)/a0;
	*oH1f = *oH1_F;
	H1F_tm1 = *oH1_F;
}

void f_filterH2(c_double *iH2, c_double *oH2_F, c_double *oH2f)
{
	*oH2_F = (-1*a1*H2F_tm1+b0*(*iH2)+b1*H2F_tm1)/a0;
	*oH2f = *oH2_F;
	H2F_tm1 = *oH2_F;
}

double uLim1 = 0;
double uLim2 = 0;
double uki1_R = 0;
double uki1_L = 0;
double uki2_R = 0;
double uki2_L = 0;

void f_T1_P(c_double *iH1, c_double *oU1)
{
	double e1 = hRez1/100 - *iH1/100;
	double u1 = kr*e1;
	if (u1 < 0)
		u1 = 0;
	if (u1 > 10)
		u1 = 10;
	uki1_L = u1 - e1*krPI_L;
	uki1_R = u1 - e1*krPI_R;
	*oU1 = u1;
	printf("Reg P 1\n");
}

void f_T1_PI_R(c_double *iH1, c_double *oU1)
{
	double H1m = *iH1/100.0;
	double H1Pm = hRez1/100.0;
	double ePI1 = H1Pm - H1m;
	double ukp1 = krPI_R*ePI1;
	double kArw = (1/Tr_R)*10;
	double arw = (uLim1 - uPI1)*kArw;
	uki1_R = uki1_R+(krPI_R*0.5/Tr_R)*(ePI1+arw);
	uPI1 = ukp1+uki1_R;
	uLim1 = uPI1;
	if (uLim1 < 0)
		uLim1 = 0;
	if (uLim1 > 10)
		uLim1 = 10;
	uki1_L = uLim1 - ePI1*krPI_L;
	*oU1 = uLim1;
	printf("Reg PI Rapid1\n");
}

void f_T1_PI_L(c_double *iH1, c_double *oU1)
{
	double H1m = *iH1/100.0;
	double H1Pm = hRez1/100.0;
	double ePI1 = H1Pm - H1m;
	double ukp1 = krPI_L*ePI1;
	double kArw = (1/Tr_L)*10;
	double arw = (uLim1 - uPI1)*kArw;
	uki1_L = uki1_L+(krPI_L*0.5/Tr_L)*(ePI1+arw);
	uPI1 = ukp1+uki1_L;
	uLim1 = uPI1;
	if (uLim1 < 0)
		uLim1 = 0;
	if (uLim1 > 10)
		uLim1 = 10;
	uki1_R = uLim1 - ePI1*krPI_R;
	*oU1 = uLim1;
	printf("Reg PI Lent1\n");
}

void f_T2_P(c_double *iH2, c_double *oU2)
{
	double e2 = hRez2/100 - *iH2/100;
	double u2 = kr*e2;
	if (u2 < 1 && u2 > 0)
	{
		u2 = u2+1;
	}
	if (u2 < 0)
		u2 = 0;
	if (u2 > 10)
		u2 = 10;
	uki2_L = u2 - e2*krPI_L;
	uki2_R = u2 - e2*krPI_R;
	*oU2 = u2;
	printf("Reg P 2\n");
}

void f_T2_PI_R(c_double *iH2, c_double *oU2)
{
	double H2m = *iH2/100;
	double H2Pm = hRez2/100;
	double ePI2 = H2Pm - H2m;
	double ukp2 = krPI_R*ePI2;
	double kArw = (1/Tr_R)*10;
	double arw = (uLim2 - uPI2)*kArw;
	uki2_R = uki2_R+(krPI_R*0.5/Tr_R)*(ePI2+arw);
	uPI2 = ukp2+uki2_R;
	uLim2 = uPI2;
	if (uLim2 < 1 && uLim2 > 0)
	{
		uLim2 = uLim2+1;
	}
	if (uLim2 < 0)
		uLim2 = 0;
	if (uLim2 > 10)
		uLim2 = 10;
	uki2_L = uLim2 - ePI2*krPI_L;
	*oU2 = uLim2;
	printf("Reg PI Rapid 2\n");
}

void f_T2_PI_L(c_double *iH2, c_double *oU2)
{
	double H2m = *iH2/100;
	double H2Pm = hRez2/100;
	double ePI2 = H2Pm - H2m;
	double ukp2 = krPI_L*ePI2;
	double kArw = (1/Tr_L)*10;
	double arw = (uLim2 - uPI2)*kArw;
	uki2_L = uki2_L+(krPI_L*0.5/Tr_L)*(ePI2+arw);
	uPI2 = ukp2+uki2_L;
	uLim2 = uPI2;
	if (uLim2 < 1 && uLim2 > 0)
	{
		uLim2 = uLim2+1;
	}
	if (uLim2 < 0)
		uLim2 = 0;
	if (uLim2 > 10)
		uLim2 = 10;
	uki2_R = uLim2 - ePI2*krPI_R;
	*oU2 = uLim2;
	printf("Reg PI Lent 2\n");
}

int withPerturbation(c_bool *iV)
{
	return *iV;
}

int withoutPerturbation(c_bool *iV)
{
	return !(*iV);
}

int PIRapid(c_bool *iPI_LR)
{
	return !(*iPI_LR);
}

int PILent(c_bool *iPI_LR)
{
	return *iPI_LR;
}

void copy_c_bool(c_bool *b_source, c_bool *b_dest) {
  *b_dest=*b_source;
}

void c_false(c_bool *b) {
  *b = 0;
}

//3TS