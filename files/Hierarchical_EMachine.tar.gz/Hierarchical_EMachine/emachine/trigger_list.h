/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

/*

  Author: Daniel Iercan, diercan@aut.upt.ro

*/

#ifndef _TRIGGER_LIST_
#define _TRIGGER_LIST_

#include "e_machine.h"

struct _trigger_binding_type;

typedef struct _trigger_binding_type trigger_binding_type;

struct _trigger_list;
typedef struct _trigger_list trigger_list;


/*
*  Initialize trigger list.
*/
void tl_init(trigger_list *list, int connectionIdx);

/*
*  Add a trigger to the trigger list.
*/
void tl_add(trigger_list *list, trigger_binding_type *trigger);

/*
*  Remove a trigger from the trigger list.
*/
void tl_remove(trigger_list *list, trigger_binding_type *trigger);

/*
*  Replace trigger1 with trigger2 in the trigger list.
*/
void tl_replace(trigger_list *list, trigger_binding_type *trigger1, trigger_binding_type *trigger2);

/*
*  Clear trigger list
*/
void tl_clear(trigger_list *list);

/*
* Get the trigger that is after the specified trigger in the specified list
*/
trigger_binding_type *tl_next(trigger_list *list, trigger_binding_type *trigger);

/*
* Get the trigger that is before the specified trigger in the specified list
*/
trigger_binding_type *tl_prev(trigger_list *list, trigger_binding_type *trigger);

/*
*  Copy from listSrc to listDest
*/
void tl_copy(trigger_list *listDest, trigger_list *listSrc);

#endif
