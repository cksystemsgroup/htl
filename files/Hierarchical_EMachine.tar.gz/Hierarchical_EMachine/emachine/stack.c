#include "stack.h"

int _stack[MAX_STACK];
int _top = 0;

void init_stack(){
	_top = 0;
}

int stack_size(void){
	return _top;	
}

void push(int elem){
	_stack[_top++] = elem;
}

int pop(void){
	return _stack[--_top];
}

int is_stack_empty(void){
	return _top == 0;	
}

int is_stack_full(void){
	return _top == MAX_STACK;
}
