/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

/*

  Author: Christoph Kirsch, cm@eecs.berkeley.edu
          Slobodan Matic, matic@eecs.berkeley.edu

*/

#include "e_machine.h"

/*E machine data structures*/
trigger_list free_triggers; 	/*List of free triggers*/
trigger_list wqueue;		/*Write queue*/
trigger_list rqueue;		/*Read queue*/
trigger_list squeue;		/*Switch queue*/
trigger_list parent_stack;	/*Stack of parent triggers*/
trigger_binding_type *R[4];	/*trigger registers*/
trigger_binding_type *Rx;	/*Temporary trigger register*/
trigger_binding_type *Ry;	/*Temporary trigger register used in delete children*/
trigger_binding_type *Rz;	/*Temporary trigger register used in delete children*/

trigger_binding_type allocated_triggers[MAXSCHEDULE]; /* e machine trigger array */

trigger_binding_type tmp_trigger;

annotation_binding_type e_ready[MAXTASK];

int arg1, arg2, arg3, arg4, arg5;

int pc;

unsigned long long mask;     /* Auxiliary mask */
unsigned long long ready;    /* tasks that are in the ready queue */ 
unsigned long long schedule; /* tasks to be scheduled */
unsigned long long running;  /* tasks that are running */

unsigned i, j, k;

int priority, highest_priority;
int highest_priority_task;

#ifdef MEASURE
int idleTime=0;
int emachineTime=0;
#endif


#ifdef OSEK
double average_e_execution_time;
double average_d_execution_time;
double average_s_execution_time;

unsigned int e_execution_time,
  d_execution_time,
  s_execution_time,
  last_system_time,
  current_system_time;
#endif

/* -------------------------------------------------------------------
 *
 * Reset a trigger.
 *
 * Pointer to trigger that has to be reset.
 * ---------------------------------------------------------------- */
void reset_trigger(trigger_binding_type *trigger){
  trigger->address = -1;
  trigger->state = 0;
  trigger->parameter = 0;
  trigger->dependency = 0;
  trigger->initial_dep = 0;

  for(k=0; k<MAX_CONNECTION_LEVEL; k++){
    trigger->prev[k] = NULL;
    trigger->next[k] = NULL;
  }
  trigger->parent = NULL;
  tl_init(&(trigger->children), 2); 
}

/* -------------------------------------------------------------------
 *
 * Free a trigger.
 *
 * Pointer to trigger that has to be freed.
 * ---------------------------------------------------------------- */
void free_trigger(trigger_binding_type *trigger){
  reset_trigger(trigger);

  tl_add(&free_triggers, trigger);
}

/* -------------------------------------------------------------------
 *
 * Recursevly remove triggers from switch queue
 *
 * ---------------------------------------------------------------- */
void delete_children(trigger_list *list){
  trigger_binding_type *t1, *t2;
  if(list!=NULL){
    t1= list->head;
    while(t1!=NULL){
      //printf("remove: %d\n", t1->address);
      t2 = tl_next(list, t1);
      delete_children(&(t1->children));
      //printf("remove\n");
      tl_remove(&squeue, t1);
      free_trigger(t1);
      t1 = t2;
    }
  }
}

/* -------------------------------------------------------------------
 *
 * Function e_machine: check every enabled trigger. For every activated
 * trigger interpret e code. If a task is scheduled post its semaphore.
 *
 * Arguments: trigger_number, not used.
 *
 * ---------------------------------------------------------------- */

#ifdef OSEK
TASK(e_machine_and_drivers)
#else
void e_machine(int trigger_number)
#endif
{
  #ifdef MEASURE
    idleTime = stopTimer();
    printf("\t\t\tIDLE time: %d ns\n", idleTime);
    startTimer();
  #endif
#ifdef OSEK
  getTickCountLow(&last_system_time);

  e_execution_time = 0;
  d_execution_time = 0;
  s_execution_time = 0;
#endif
  unsigned long long temp;

  set_logical_time();

  ready = schedule;

  //sprintf(text_message, "E machine time: %dms", get_logical_time());
	
  //os_print_message(text_message);
  
  // TODO - done
  /**
   * if a task have been finished
   **/

  for(i = 0, mask = 1; i < MAXTASK; i++) {
    if (!is_task_finished(i)){
		ready = ready | mask;
    }
	else{ // if the task is finished
		// if the task have been run and now is completed
		if (running & mask)
		{
			temp = ~mask;
			running = running & temp;
			Rx = rqueue.head;
			while(Rx!=NULL){
				Rx->dependency = Rx->dependency & temp;
				Rx = tl_next(&rqueue, Rx);
			}
		}
	}
		
    mask = mask << 1;
  }

  reset_trigger(&tmp_trigger);
  R[0] = &tmp_trigger;
  R[1] = NULL;
  R[2] = NULL;
  R[3] = NULL;
  while (1) {
    // Resetting i can be avoided if already evaluated triggers cannot
    // become active later in the same reaction, see ordered halt
    // points for Esterel compilation.
    i = 0;

    pc = -1;
    
    //check write queue
    Rx = wqueue.head;
    while ((pc == -1) && (Rx!=NULL)) {
      if ( Rx->trigger->is_active(Rx->state, Rx->parameter, Rx->dependency, Rx->initial_dep)) {
        //active trigger was found			 
        pc = Rx->address;
	R[0] = Rx;
	tl_remove(&wqueue, R[0]);
      }
      else
        Rx = tl_next(&wqueue, Rx);
    }
			 
    //check switch queue
    Rx = squeue.head;
    while ((pc == -1) && (Rx!=NULL)) {
      if ( Rx->trigger->is_active(Rx->state, Rx->parameter, Rx->dependency, Rx->initial_dep)) {
        //active trigger was found			 
        pc = Rx->address;
	R[0] = Rx;
	tl_remove(&squeue, R[0]);
      }
      else
        Rx = tl_next(&squeue, Rx);
			}

    //check read queue
    Rx = rqueue.head;
    while ((pc == -1) && (Rx!=NULL)) {
      if ( Rx->trigger->is_active(Rx->state, Rx->parameter, Rx->dependency, Rx->initial_dep)) {
        //active trigger was found			 
        pc = Rx->address;
	R[0] = Rx;
	tl_remove(&rqueue, R[0]);
      	}
      	else
        Rx = tl_next(&rqueue, Rx);
    }

    if (pc == -1)
      break;

    while (pc != -1) {
      arg1 = program[pc].arg1;
      arg2 = program[pc].arg2;
      arg3 = program[pc].arg3;
      arg4 = program[pc].arg4;
      arg5 = program[pc].arg5;

      switch(program[pc].opcode) {
      case OPCODE_nop:          /* nop() */
		pc++;
		break;
      case OPCODE_sfuture:       /* sfuture(Trigger,Address,Parameter,Dependency) */
      case OPCODE_rfuture:       /* rfuture(Trigger,Address,Parameter,Dependency) */
      case OPCODE_wfuture:       /* wfuture(Trigger,Address,Parameter,Dependency) */
        R[1] = free_triggers.tail;
	tl_remove(&free_triggers, R[1]);
		
        if(program[pc].opcode == OPCODE_sfuture){
	  tl_add(&squeue, R[1]);	
	}
	if(program[pc].opcode == OPCODE_rfuture){
	  tl_add(&rqueue, R[1]);
	}
	if(program[pc].opcode == OPCODE_wfuture){
	  tl_add(&wqueue, R[1]);
	}

	R[1]->trigger = &(trigger_table[arg1]);
	R[1]->address = arg2;
	R[1]->state = R[1]->trigger->save();
        R[1]->parameter = arg3;
        R[1]->dependency = (unsigned long long)arg4 | (((unsigned long long)arg5) << 32);
        R[1]->initial_dep = (unsigned long long)arg4  | (((unsigned long long)arg5) << 32);

#ifdef OSEK
        R[1]->trigger->enable(e_machine_and_drivers, arg3);
#else
        R[1]->trigger->enable(e_machine, arg3);
#endif
		pc++;
		break;
		
      case OPCODE_call:         /* call(Driver) */
		if (driver_table[arg1].protected & ready) {
			sprintf(text_message, "call(%d) exception (deadline violation)", arg1);

			os_print_warning(text_message);
		}
		else {
#ifdef OSEK
			getTickCountLow(&current_system_time);

			e_execution_time = e_execution_time + current_system_time - last_system_time;
#endif

			driver_table[arg1].call();

#ifdef OSEK
			getTickCountLow(&last_system_time);

			d_execution_time = d_execution_time + last_system_time - current_system_time;
#endif
		}
		pc++;	      
		break;
		
	case OPCODE_release:     /* schedule(Task,Annotation,Parameter) */
		mask = ((unsigned long long)1) << arg1;

		if (ready & mask) {
			sprintf(text_message, "release(%d) too early (deadline violation)", arg1);

			os_print_warning(text_message);
		}
		else {
			schedule = schedule | mask;

			e_ready[arg1].annotation = &(annotation_table[arg2]);
			e_ready[arg1].state = e_ready[arg1].annotation->save();
			e_ready[arg1].parameter = arg3;

			// FIXME: 0 argument allows to plugin scheduling algorithm
			e_ready[arg1].annotation->release(0, arg3);
		}

		pc++;
		break;
		
	case OPCODE_if:           /* if(Condition,Then_Address,Else_Address) */
			if (condition_table[arg1].protected & ready) {
				sprintf(text_message, "if(%d, %d, %d) exception (deadline violation)", arg1, arg2, arg3);

				os_print_warning(text_message);
			}
			else if (condition_table[arg1].is_true())
					pc = arg2;
				else
					pc = arg3;
			break;
			
	case OPCODE_jump:         /* jump(Address) */
		if(arg1 < 0) {
			pc++;
			os_print_message("undefined jump -> continue");
		}
		else
			pc = arg1;
		break;
	
	case OPCODE_sub:       /* sub */
		if(arg1 < 0) {
			pc ++;
			os_print_message("undefined sub -> continue");
		}
		else{
			push(pc+1);
			pc = arg1;
		}
		break;
	
        case OPCODE_return:       /* return */
	  if(is_stack_empty()){
	    pc = -1;
            if(R[0]!=NULL){
	      free_trigger(R[0]);
	    }
	  }
	  else{
	    pc = pop();
	  }
	  break;

        case OPCODE_copy_reg:    /* copy register */	
	  R[arg2] = R[arg1];
	  pc++;
	  break;
		
        case OPCODE_push_reg:    /* push register on to parent stack */	
	  if(R[arg1] != NULL)
	    tl_add(&parent_stack, R[arg1]);
	  pc++;
					break;

        case OPCODE_pop_reg:    /* pop register from the stack */	
          if(parent_stack.count>0){
	    R[arg1] = parent_stack.tail;
	    tl_remove(&parent_stack, R[arg1]);
	  }
	  else{
 	    R[arg1] = NULL;
		}
	  pc++;
	  break;
	
        case OPCODE_get_parent:    /* get parent */	
	  if(R[arg1]!=NULL)
	    R[arg2] = R[arg1]->parent;
	  else
	    R[arg2] = NULL;
	  pc++;
	  break;

        case OPCODE_set_parent:    /* set parent */	
	  if(R[arg1]!=NULL){
            R[arg1]->parent = R[arg2];
	    //printf("%d: %d is child of %d\n",pc, R[arg1]->address, (R[arg2]==NULL)?-1:R[arg2]->address);
	  }
	  pc++;
	  break;

        case OPCODE_set_children_parent:    /* set children parent */	
	  //printf("%d: set children\n", pc);
	  if(R[arg1]!=NULL){
	    Rx = R[arg1]->children.head;
	    while(Rx!=NULL){
	      //printf("; %d is parent of %d\n", (R[arg2]==NULL)?-1:R[arg2]->address,  Rx->address);
  	      Rx->parent = R[arg2];
	      Rx = tl_next(&(R[arg1]->children), Rx);
			}
		}
	  pc++;
	  break;

	
        case OPCODE_delete_children:    /* delete children */	
	  //printf("%d", pc);
	  if(R[arg1] != NULL)
	    delete_children(&(R[arg1]->children));
		pc++;
		break;

        case OPCODE_replace_child:    /* replace child */	
	  if(R[arg1]!=NULL){
	    if(R[arg2]!=NULL){
	      if(R[arg3]!=NULL){
		//replace trigger
		tl_replace(&(R[arg1]->children), R[arg2], R[arg3]);
		}
		else{
		//just remove trigger
		tl_remove(&(R[arg1]->children), R[arg2]);	
	      }
	    }
	    else{
	      if(R[arg3]!=NULL){
		//just add new trigger
		tl_add(&(R[arg1]->children), R[arg3]);
	      }
		}
	  }
	  pc++;
	  break;

	case OPCODE_clean_children:    /* clean children */	
	  if(R[arg1]!=NULL)
	    tl_clear(&(R[arg1]->children));
	  pc++;
	  break;
	  
	case OPCODE_copy_children:	  /*Copy children list*/
	  if(R[arg1]!=NULL){
		  if(R[arg2]!=NULL){
			//printf("%d: Copy children...\n", pc);
			tl_copy(&(R[arg1]->children), &(R[arg2]->children));
		  }
		  else
			tl_init(&(R[arg1]->children), 2);
	  }
	  pc++;
		break;
		
	default:
		os_print_error("Unknown opcode");

      } /* switch */
    } /* interpreter while */
  } /* fixed-point while */

#ifdef OSEK
  getTickCountLow(&current_system_time);

  e_execution_time = e_execution_time + current_system_time - last_system_time;
#endif

  highest_priority = -1;
  highest_priority_task = -1;

  for(i = 0, mask = 1; i < MAXTASK; i++) {
    if (schedule & mask) {
      if (e_ready[i].annotation->is_active(e_ready[i].state, e_ready[i].parameter)) {
		priority = e_ready[i].annotation->get_priority(e_ready[i].parameter);

		if ((highest_priority < 0) || (highest_priority > priority)) {
	 		highest_priority = priority;

	  		highest_priority_task = i;
		}
      }
    }

    mask = mask << 1;
  }

  if (highest_priority_task != -1) {
    schedule = schedule & ~(((unsigned long long)1) << highest_priority_task);

    schedule_task(highest_priority_task, highest_priority);
    
    // Keep track the tasks that are running
    running = running | (((unsigned long long)1)  << highest_priority_task);
  }

#ifdef OSEK
  getTickCountLow(&last_system_time);

  s_execution_time = s_execution_time + last_system_time - current_system_time;

  if (d_execution_time > 0) {
    // Measure only if some drivers were called
    average_e_execution_time = 0.99*average_e_execution_time
      + 0.01*((double)e_execution_time);
    average_d_execution_time = 0.99*average_d_execution_time 
      + 0.01*((double)d_execution_time);
    average_s_execution_time = 0.99*average_s_execution_time 
      + 0.01*((double)s_execution_time);
  }

  if (get_logical_time() % 1000 == 0) {
    // Print only every second
    sprintf(text_message,
	    "E: %6.2f, D: %6.2f, S: %6.2f, E/E+D: %6.2f\%",
	    average_e_execution_time,
	    average_d_execution_time,
	    average_s_execution_time,
	    average_e_execution_time * 100.0 / (average_e_execution_time + average_d_execution_time));

    os_print_warning(text_message);
  }          R[1]->queue = &wqueue;

  TerminateTask();

  os_print_error("e_machine_and_drivers: TerminateTask error");
#endif

  #ifdef MEASURE
    emachineTime = stopTimer();
    printf("\t\t\tE code time: %d ns\n", emachineTime);
    printf("\t\t\tDuty: %f%\n", ((float)emachineTime)/((float)emachineTime+idleTime)*100.0);
    startTimer();
  #endif
}

#ifdef OSEK
TASK(e_machine_init)
#else
main(int argc, char *argv[])
#endif
{
  host_id_type host_id;
  int id;
  unsigned start_address;

  //initialize trigger lists
  tl_init(&free_triggers, 0); 	/*List of free triggers*/
  tl_init(&wqueue, 0);		/*Write queue*/
  tl_init(&rqueue, 0);		/*Read queue*/
  tl_init(&squeue, 0);		/*Switch queue*/
  tl_init(&parent_stack, 1);	/*Stack of parent triggers*/

  //build the list of free triggers
  for(i=0; i<MAXSCHEDULE; i++){
    tl_init(&(allocated_triggers[i].children), 2);
    free_trigger(&(allocated_triggers[i]));
  }

#ifdef MEASURE
  startTimer();
#endif

  if (sizeof(int) < 4)
    os_print_error("E machine needs at least 32 bits for data type int");

#ifdef OSEK
  id = 0;

  average_e_execution_time = 0.0;
  average_d_execution_time = 0.0;
  average_s_execution_time = 0.0;
#else
  if (argc > 2)
    os_print_error("Usage: e_machine [host_id]");
  else if (argc == 2) {
    if (sscanf(argv[1], "%d", &id) < 1) {
      sprintf(text_message, "Host id: %s, invalid format", argv[1]);

      os_print_error(text_message);
    }

    if ((id < 0) ||
	(MAXHOST == 0 && id > 0) ||
	((MAXHOST > 0) && (id > MAXHOST - 1))) {
      sprintf(text_message, "Host id: %d, out of range", id);

      os_print_error(text_message);
    }
  } else
    id = 0;
#endif

  host_id = id;

  init_stack();

  os_interface_init();

  s_interface_init();
  
  f_table_init();
  
  f_code_init(host_id);
#if DEBUG
    printf("after f_code_init\n");
#endif

  if (MAXHOST > 0)
    start_address = host_table[host_id].start_address;
  else
    start_address = 0;

  schedule = 0;
  running = 0;

  Rx = free_triggers.tail;
#if DEBUG
    printf("before tl_remove\n");
    printf("free triggers: %d\n", free_triggers.count);
#endif

  tl_remove(&free_triggers, Rx);

#if DEBUG
    printf("after tl_remove\n");
#endif

  Rx->trigger = &(trigger_table[0]);
  Rx->address = start_address;

#ifdef OSEK
  Rx->trigger->enable(e_machine_and_drivers, 0);
#else
  Rx->trigger->enable(e_machine, 0);
#endif

  Rx->state = Rx->trigger->save();
  Rx->parameter = 0;
  Rx->dependency = 0;

  tl_add(&wqueue, Rx);

  //n_enabled_triggers = 1;

#ifdef DISTRIBUTED
  if (host_id == 0) {
    h_interface_init(host_id);

    e_interface_init(host_id);
  } else if (host_id > 0) {
    e_interface_init(host_id);
    
    h_interface_init(host_id);
  }
#else
  e_interface_init();
#endif

#ifdef OSEK
  TerminateTask();

  os_print_error("e_machine_init: TerminateTask error");
#else
  while (wqueue.count > 0) {
    e_machine_wait();
    
    e_machine(0);
  }

  exit(0);
#endif
}
