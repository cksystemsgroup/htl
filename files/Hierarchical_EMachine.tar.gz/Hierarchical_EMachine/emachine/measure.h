#ifndef __MEASURE_H

#include <sys/time.h>

struct timeval start, finish;
unsigned long long msec;
long long seconds;
long long nanosec;

//start the timer
void startTimer();

//stop th timer
int stopTimer();

//compute the time interval in nano seconds
int getTimeInterval(struct timeval *start, struct timeval * finish);

#endif
