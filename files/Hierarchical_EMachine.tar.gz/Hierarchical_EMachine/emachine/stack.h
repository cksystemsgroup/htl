#ifndef __STACK_H

#define  __STACK_H


#define MAX_STACK 32

void init_stack();
int stack_size(void);
void push(int);
int pop(void);
int is_stack_empty(void);
int is_stack_full(void);

#endif
