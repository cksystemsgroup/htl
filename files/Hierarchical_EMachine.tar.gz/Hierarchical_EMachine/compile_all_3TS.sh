rm -r ./binaries

mkdir ./binaries
mkdir ./binaries/0_IO
make all host=IO ID=0
cp e-machine ./binaries/0_IO
cp configurare ./binaries/0_IO

mkdir ./binaries/1_T1
make all host=T1 ID=1
cp e-machine ./binaries/1_T1
cp configurare ./binaries/1_T1

mkdir ./binaries/2_T2
make all host=T2 ID=2
cp e-machine ./binaries/2_T2
cp configurare ./binaries/2_T2
