/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

/*

  Author: Christoph Kirsch, cm@eecs.berkeley.edu
          Slobodan Matic, matic@eecs.berkeley.edu
          Daniel Iercan, daniel.iercan@aut.upt.ro

*/

#ifndef _E_SPEC_
#define _E_SPEC_

#include "spec.h"

#define OPCODE_nop       0
#define OPCODE_wfuture    		1
#define OPCODE_sfuture    		2
#define OPCODE_rfuture    		3
#define OPCODE_call       		4
#define OPCODE_release  		5
#define OPCODE_if        		6
#define OPCODE_jump      		7
#define OPCODE_return    		8
#define OPCODE_sub	   		9
#define OPCODE_copy_reg    		10
#define OPCODE_push_reg    		11
#define OPCODE_pop_reg    		12
#define OPCODE_get_parent    		13
#define OPCODE_set_parent   	 	14
#define OPCODE_set_children_parent    	15
#define OPCODE_delete_children    	16
#define OPCODE_replace_child    	17
#define OPCODE_clean_children    	18
#define OPCODE_copy_children	19

typedef struct {
  int opcode;
  int arg1;
  int arg2;
  int arg3;
  int arg4;
  int arg5;
} instruction_type;

#define NOP()                                  						{OPCODE_nop,       -1,        -1,           -1,			-1, 	-1}
#define WFUTURE(trigger,address,parameter,dependency1, dependency2)  {OPCODE_wfuture,    trigger,   address,      parameter,		dependency1,	dependency2}
#define RFUTURE(trigger,address,parameter,dependency1, dependency2)  {OPCODE_rfuture,    trigger,   address,      parameter,		dependency1,	dependency2}
#define SFUTURE(trigger,address,parameter,dependency1, dependency2)  {OPCODE_sfuture,    trigger,   address,      parameter,		dependency1,	dependency2}
#define CALL(driver)                           						{OPCODE_call,      driver,    -1,           -1,			-1, 	-1}
#define RELEASE(task,annotation,parameter)    						{OPCODE_release,  task,      annotation,   parameter,		-1, 	-1}
#define IF(condition,then_address,else_address)						{OPCODE_if,        condition, then_address, else_address,	-1, 	-1}
#define TERMINATE(task)                        						{OPCODE_terminate, task,      -1,           -1,			-1, 	-1}
#define JUMP(address)                          						{OPCODE_jump,      address,   -1,           -1,			-1, 	-1}
#define RETURN()                               						{OPCODE_return,    -1,        -1,           -1,			-1, 	-1}
#define SUB(address)                          						{OPCODE_sub,      address,   -1,           -1,			-1, 	-1}
#define COPY_REG(Rx, Ry)  								{OPCODE_copy_reg,       Rx,        Ry,           -1,			-1, 	-1}
#define PUSH_REG(Rx) 									{OPCODE_push_reg,       Rx,        -1,           -1,			-1, 	-1}
#define POP_REG(Rx) 									{OPCODE_pop_reg,       Rx,        -1,           -1,			-1, 	-1}
#define GET_PARENT(Rx, Ry)								{OPCODE_get_parent,       Rx,        Ry,           -1,			-1, 	-1}
#define SET_PARENT(Rx, Ry)								{OPCODE_set_parent,       Rx,        Ry,           -1,			-1, 	-1}
#define SET_CHILDREN_PARENT(Rx, Ry) 						{OPCODE_set_children_parent,       Rx,        Ry,           -1,			-1, 	-1}
#define DELETE_CHILDREN(Rx) 							{OPCODE_delete_children,       Rx,        -1,           -1,			-1, 	-1}
#define REPLACE_CHILDREN(Rx, Ry, Rz)						{OPCODE_replace_child,       Rx,        Ry,           Rz,			-1, 	-1}
#define CLEAN_CHILDREN(Rx) 							{OPCODE_clean_children,       Rx,        -1,           -1,			-1, 	-1}
#define COPY_CHILDREN(Rx, Ry) 							{OPCODE_copy_children,       Rx,        Ry,           -1,			-1, 	-1}

#endif


