/*
 * Created on August 12, 2007
 *
 *Copyright (c) 2007 University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF SALZBURG SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */
 
 /*

  Author: Daniel Iercan, daniel.iercan@aut.upt.ro

*/

#include "trigger_list.h"

/*
*  Initialize trigger list.
*/
void tl_init(trigger_list *list, int connectionIdx){
	list->head = NULL;
	list->tail = NULL;
	list->count = 0;
	list->connectionIdx = connectionIdx;
}

/*
*  Add a trigger to the trigger list.
*/
void tl_add(trigger_list *list, trigger_binding_type *trigger){
	list->count++;
	if(list->tail == NULL)
	{
		//this is the first element
		trigger->prev[list->connectionIdx] = NULL;
		trigger->next[list->connectionIdx] = NULL;
		list->tail = list->head = trigger;
	}
	else{
		//add the trigger to the end of the list
		list->tail->next[list->connectionIdx] = trigger;
		trigger->prev[list->connectionIdx] = list->tail;
		trigger->next[list->connectionIdx] = NULL;
		list->tail = trigger;
	}
}

/*
*  Replace trigger1 with trigger2 in the trigger list.
*/
void tl_replace(trigger_list *list, trigger_binding_type *trigger1, trigger_binding_type *trigger2){
        tl_remove(list, trigger1);
	tl_add(list, trigger2);
/*	trigger2->next[list->connectionIdx] = trigger1->next[list->connectionIdx];
	trigger2->prev[list->connectionIdx] = trigger1->prev[list->connectionIdx];
	if(list->head == trigger1)
		list->head = trigger2;

	if(list->tail == trigger1)
		list->tail = trigger2;

	trigger1->next[list->connectionIdx] = trigger1->prev[list->connectionIdx] = NULL;
	*/
}

/*
*  Clear trigger list
*/
void tl_clear(trigger_list *list){
	list->tail = list->head = NULL;
	list->count = 0;
}

/*
*  Remove a trigger from the trigger list.
*/
void tl_remove(trigger_list *list, trigger_binding_type *trigger){
        	
        if((trigger == list->tail) || (trigger == list->head)){
	if(trigger == list->head){
		//first trigger in the list
#if DEBUG
			printf("tl_remove: Is head\n");
#endif
		list->head = trigger->next[list->connectionIdx];
		if(list->head != NULL){
			list->head->prev[list->connectionIdx] = NULL;
		}
	}

	if(trigger == list->tail){
		//last trigger in the list
#if DEBUG
			printf("tl_remove: Is tail\n");
#endif
		list->tail = trigger->prev[list->connectionIdx];
		if(list->tail != NULL){
			list->tail->next[list->connectionIdx] = NULL;
		}
	}
	}
	else{
		//middle trigger
		if(trigger->prev[list->connectionIdx]==NULL || trigger->next[list->connectionIdx]==NULL){
		    return;
		}
#if DEBUG
		printf("tl_remove: middle trigger\n");
#endif
		trigger->prev[list->connectionIdx]->next[list->connectionIdx] = trigger->next[list->connectionIdx];
		trigger->next[list->connectionIdx]->prev[list->connectionIdx] = trigger->prev[list->connectionIdx];
	}

	

	//remove the connections to the other triggers in the list
	trigger->prev[list->connectionIdx] = trigger->next[list->connectionIdx] = NULL;

	list->count--;
}

/*
* Get the trigger that is after the specified trigger in the specified list
*/
trigger_binding_type *tl_next(trigger_list *list, trigger_binding_type *trigger){
	return trigger->next[list->connectionIdx];
}

/*
* Get the trigger that is before the specified trigger in the specified list
*/
trigger_binding_type *tl_prev(trigger_list *list, trigger_binding_type *trigger){
	return trigger->prev[list->connectionIdx];
}


/*
*  Copy from listSrc to listDest
*/
void tl_copy(trigger_list *listDest, trigger_list *listSrc){
	listDest->head = listSrc->head;
	listDest->tail = listSrc->tail;
	listDest->count = listSrc->count;
	listDest->connectionIdx = listSrc->connectionIdx;
}