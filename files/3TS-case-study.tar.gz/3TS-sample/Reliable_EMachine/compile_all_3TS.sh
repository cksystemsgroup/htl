rm -r ./binaries

mkdir ./binaries
mkdir ./binaries/0_IO
make all host=IO ID=0
cp e-machine ./binaries/0_IO
cp configurare ./binaries/0_IO

mkdir ./binaries/1_T11
make all host=T11 ID=1
cp e-machine ./binaries/1_T11
cp configurare ./binaries/1_T11

mkdir ./binaries/2_T12
make all host=T12 ID=2
cp e-machine ./binaries/2_T12
cp configurare ./binaries/2_T12

mkdir ./binaries/3_T21
make all host=T21 ID=3
cp e-machine ./binaries/3_T21
cp configurare ./binaries/3_T21

mkdir ./binaries/4_T22
make all host=T22 ID=4
cp e-machine ./binaries/4_T22
cp configurare ./binaries/4_T22
