/*
 * Real-Time Workshop code generation for Simulink model "t_T1_PI_Fcn.mdl".
 *
 * Model Version                        : 1.99
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Sun Jun 01 02:44:32 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Sun Jun 01 02:44:32 2008
 */

#include "t_T1_PI_Fcn.h"
#include "t_T1_PI_Fcn_private.h"

/* Exported block signals */
real_T Out_Signal_t_T1_PI1;             /* <S4>/Gain1 */
real_T In_Signal_t_T1_PI1;              /* <Root>/in_t_T1_PI1 */
real_T In_Signal_t_T1_PI2;              /* <Root>/in_t_T1_PI2 */

/* Block signals (auto storage) */
BlockIO_t_T1_PI_Fcn t_T1_PI_Fcn_B;

/* Block states (auto storage) */
D_Work_t_T1_PI_Fcn t_T1_PI_Fcn_DWork;

/* Real-time model */
RT_MODEL_t_T1_PI_Fcn t_T1_PI_Fcn_M_;
RT_MODEL_t_T1_PI_Fcn *t_T1_PI_Fcn_M = &t_T1_PI_Fcn_M_;

/* Model step function */
void t_T1_PI_Fcn_step(void)
{

  /* SubSystem: '<S3>/task subsystem' */

  /* Output and update for atomic system: '<S3>/task subsystem' */

  /* Sum: '<S4>/Sum2' incorporates:
   *   Inport: '<Root>/in_t_T1_PI1'
   *   Inport: '<Root>/in_t_T1_PI2'
   */
  t_T1_PI_Fcn_B.Sum2 = - In_Signal_t_T1_PI1 + In_Signal_t_T1_PI2;

  /* DiscreteFilter: '<S4>/Discrete Filter' */
  t_T1_PI_Fcn_B.Discrete_Filter =
    t_T1_PI_Fcn_P.Discrete_Filter_D*t_T1_PI_Fcn_B.Sum2;
  t_T1_PI_Fcn_B.Discrete_Filter +=
    t_T1_PI_Fcn_P.Discrete_Filter_C*t_T1_PI_Fcn_DWork.Discrete_Filter_DSTATE;

  /* Gain: '<S4>/Gain'
   *
   * Regarding '<S4>/Gain':
   *   Gain value: t_T1_PI_Fcn_P.Gain_Gain
   */
  t_T1_PI_Fcn_B.Gain = t_T1_PI_Fcn_B.Discrete_Filter * t_T1_PI_Fcn_P.Gain_Gain;

  /* Sum: '<S4>/Sum' */
  t_T1_PI_Fcn_B.Sum = t_T1_PI_Fcn_B.Sum2 + t_T1_PI_Fcn_B.Gain;

  /* Gain: '<S4>/Gain1'
   *
   * Regarding '<S4>/Gain1':
   *   Gain value: t_T1_PI_Fcn_P.Gain1_Gain
   */
  Out_Signal_t_T1_PI1 = t_T1_PI_Fcn_B.Sum * t_T1_PI_Fcn_P.Gain1_Gain;

  /* DiscreteFilter Block: <S4>/Discrete Filter */
  {
    t_T1_PI_Fcn_DWork.Discrete_Filter_DSTATE = t_T1_PI_Fcn_B.Sum2 +
      t_T1_PI_Fcn_P.Discrete_Filter_A*t_T1_PI_Fcn_DWork.Discrete_Filter_DSTATE;
  }

  /* (no update code required) */
}

/* Model initialize function */
void t_T1_PI_Fcn_initialize(boolean_T firstTime)
{
  if (firstTime) {
    /* registration code */
    rtmSetErrorStatus(t_T1_PI_Fcn_M, (const char_T *)0);

    /* block I/O */
    {
      void *b = (void *) &t_T1_PI_Fcn_B;
      {
        int_T i;

        b =&t_T1_PI_Fcn_B.Sum2;
        for (i = 0; i < 4; i++) {
          ((real_T*)b)[i] = 0.0;
        }
      }

      /* exported global signals */
      Out_Signal_t_T1_PI1 = 0.0;
    }

    /* data type work */
    t_T1_PI_Fcn_DWork.Discrete_Filter_DSTATE = 0.0;

    /* external inputs */
    In_Signal_t_T1_PI1 = 0.0;
    In_Signal_t_T1_PI2 = 0.0;

    /* external outputs */
    Out_Signal_t_T1_PI1 = 0.0;
  }
}

/* Model terminate function */
void t_T1_PI_Fcn_terminate(void)
{
  /* (no terminate code required) */
}

