#ifndef TYPES_H_
#define TYPES_H_

#define MAXDISPLAY 20

typedef int c_int;

typedef unsigned c_bool;

typedef double c_double;

typedef char c_string[MAXDISPLAY];

#endif /*TYPES_H_*/
