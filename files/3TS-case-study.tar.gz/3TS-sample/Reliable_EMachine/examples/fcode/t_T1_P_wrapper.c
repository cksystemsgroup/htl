#include "t_T1_P_wrapper.h"

real_T In_Signal_t_T1_P1;

real_T In_Signal_t_T1_P2;

real_T Out_Signal_t_T1_P1;


extern void init_t_T1_P()
{
    t_T1_P_Fcn_initialize(1);
}

extern void execute_t_T1_P(double *u1,double *u2,double *y1)
{
In_Signal_t_T1_P1 = (real_T)*u1;

In_Signal_t_T1_P2 = (real_T)*u2;

t_T1_P_Fcn_step();
*y1 = (double)Out_Signal_t_T1_P1;

}

extern void terminate_t_T1_P()
{
   t_T1_P_Fcn_terminate();
}

