/*
 * t_T1_P_Fcn.h
 *
 * Real-Time Workshop code generation for Simulink model "t_T1_P_Fcn.mdl".
 *
 * Model Version                        : 1.114
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Sat Jun 14 15:39:21 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Sat Jun 14 15:39:21 2008
 */

#ifndef _RTW_HEADER_t_T1_P_Fcn_h_
# define _RTW_HEADER_t_T1_P_Fcn_h_

#ifndef _t_T1_P_Fcn_COMMON_INCLUDES_
# define _t_T1_P_Fcn_COMMON_INCLUDES_
#include <math.h>
#include <float.h>
#include <string.h>

#include "tmwtypes.h"
#include "simstruc_types.h"
#include "rtlibsrc.h"

#endif                                  /* _t_T1_P_Fcn_COMMON_INCLUDES_ */

#include "t_T1_P_Fcn_types.h"

/* Intrinsic types */
#ifndef POINTER_T
# define POINTER_T
typedef void * pointer_T;
#endif

/* Block signals (auto storage) */
typedef struct _BlockIO_t_T1_P_Fcn {
  real_T Sum2;                          /* '<S4>/Sum2' */
  real_T kR;                            /* '<S4>/kR' */
} BlockIO_t_T1_P_Fcn;

/* Parameters (auto storage) */
struct _Parameters_t_T1_P_Fcn {
  real_T kR_Gain;                       /* Expression: kR1
                                         * '<S4>/kR'
                                         */
  real_T Saturation_UpperSat;           /* Expression: 10
                                         * '<S4>/Saturation'
                                         */
  real_T Saturation_LowerSat;           /* Expression: -10
                                         * '<S4>/Saturation'
                                         */
};

/* Real-time Model Data Structure */
struct _RT_MODEL_t_T1_P_Fcn_Tag {
  const char *errorStatus;
};

/* Real-time Model object */
extern RT_MODEL_t_T1_P_Fcn *t_T1_P_Fcn_M;

/* Macros for accessing real-time model data structure  */

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm) (rtm)->errorStatus
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val) (rtm)->errorStatus = ((val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm) (0.0)
#endif

/* Backward compatibility for real-time model name change */
#define t_T1_P_Fcn_rtO                  t_T1_P_Fcn_M
#define t_T1_P_Fcn_RT_OBJECT            RT_MODEL_t_T1_P_Fcn

/* Block parameters (auto storage) */
extern const Parameters_t_T1_P_Fcn t_T1_P_Fcn_P;

/* Block signals (auto storage) */
extern BlockIO_t_T1_P_Fcn t_T1_P_Fcn_B;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  RTW declares the memory for these signals
 * and exports their symbols.
 *
 */

extern real_T Out_Signal_t_T1_P1;       /* '<S4>/Saturation' */
extern real_T In_Signal_t_T1_P1;        /* '<Root>/in_t_T1_P1' */
extern real_T In_Signal_t_T1_P2;        /* '<Root>/in_t_T1_P2' */

/* Model entry point functions */
extern void t_T1_P_Fcn_initialize(boolean_T firstTime);
extern void t_T1_P_Fcn_step(void);
extern void t_T1_P_Fcn_terminate(void);

/* 
 * The generated code includes comments that allow you to trace directly 
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : t_T1_P_Fcn
 * '<S1>'   : t_T1_P_Fcn/SigSpec_in_t_T1_P1
 * '<S2>'   : t_T1_P_Fcn/SigSpec_in_t_T1_P2
 * '<S3>'   : t_T1_P_Fcn/t_T1_P_Fcn
 * '<S4>'   : t_T1_P_Fcn/t_T1_P_Fcn/task subsystem
 */

#endif                                  /* _RTW_HEADER_t_T1_P_Fcn_h_ */
