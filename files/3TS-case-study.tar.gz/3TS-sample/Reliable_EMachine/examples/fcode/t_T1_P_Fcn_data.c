/*
 * t_T1_P_Fcn_data.c
 *
 * Real-Time Workshop code generation for Simulink model "t_T1_P_Fcn.mdl".
 *
 * Model Version                        : 1.114
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Sat Jun 14 15:39:21 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Sat Jun 14 15:39:21 2008
 */

#include "t_T1_P_Fcn.h"
#include "t_T1_P_Fcn_private.h"

/* Block parameters (auto storage) */
const Parameters_t_T1_P_Fcn t_T1_P_Fcn_P = {
  25.0 ,                                /* kR_Gain : '<S4>/kR' */
  10.0 ,                                /* Saturation_UpperSat : '<S4>/Saturation' */
  -10.0                                 /* Saturation_LowerSat : '<S4>/Saturation' */
};

