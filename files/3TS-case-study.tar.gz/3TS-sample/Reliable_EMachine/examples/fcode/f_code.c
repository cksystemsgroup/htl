/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

/*

  Author: Christoph Kirsch, 	cm@eecs.berkeley.edu
          Slobodan Matic, 		matic@eecs.berkeley.edu
          Daniel Iercan, 		diercan@cs.uni-salzburg.at

*/

#define SIMULATOR

#include <time.h>
#include <stdio.h>

#include "f_code.h"
#include "v_code.h"

#include "t_T1_P_wrapper.h"
#include "t_T1_PI_wrapper.h"
#include "t_T2_P_wrapper.h"
#include "t_T2_PI_wrapper.h"

#define MAX_HISTORY 10
#define SENSOR_NO 3

double Dh1_history[MAX_HISTORY];
double Dh2_history[MAX_HISTORY];
double Dh1c_history[MAX_HISTORY];
double Dh2c_history[MAX_HISTORY];

int v11;
int v12;
int v21;
int v22;

int port = 0;
char ip[16];
double hRez1 = 10;
double hRez2 = 20;
int idSocket;
int conectat;
double uPI1;
double uPI2;
double H1c_tm1;
double H1c_t;
double U1_tm1;
double U1_tm2;
double DH1c;
double U1_tm2;
double U1_tm1;
double H1_tm1;
double H1_t;
double DH1;
double H2c_tm1;
double H2c_t;
double U2_tm1;
double U2_tm2;
double DH2c;
double U2_tm2;
double U2_tm1;
double H2_tm1;
double H2_t;
double DH2;
double H1F_tm1;
double H2F_tm1;
double DH1c_tm1;
double DH1c_tm2;
double DH2c_tm1;
double DH2c_tm2;
void f_code_init(int hostID){
	//3TS
	v11 = 0;
	v12 = 0;
	v21 = 0;
	v22 = 0;
	uPI1 = 0;
	uPI2 = 0;
	uPI1 = 0;
	uPI2 = 0;
	H1c_tm1 = 0;
	H1c_t = 0;
	U1_tm1 = 0;
	U1_tm2 = 0;
	DH1c = 0;
	U1_tm2 = 0;
	U1_tm1 = 0;
	H1_tm1 = 0;
	H1_t = 0;
	DH1 = 0;
	H2c_tm1 = 0;
	H2c_t = 0;
	U2_tm1 = 0;
	U2_tm2 = 0;
	DH2c = 0;
	U2_tm2 = 0;
	U2_tm1 = 0;
	H2_tm1 = 0;
	H2_t = 0;
	DH2 = 0;
	H1F_tm1 = 0;
	H2F_tm1 = 0;
	DH1c_tm1 = 0;
	DH1c_tm2 = 0;
	DH2c_tm1 = 0;
	DH2c_tm2 = 0;
	char linie[256];
	int rez = 0;
	int i = 0;
	for (i = 0;i<MAX_HISTORY;i++)
	{
		Dh1_history[i] = 0;
		Dh2_history[i] = 0;
		Dh1c_history[i] = 0;
		Dh2c_history[i] = 0;
	}
	
	srand(time(NULL));
	
	FILE *fisierConfigurare;
	fisierConfigurare = fopen("config_3TS","r");
	fgets(linie,sizeof(linie),fisierConfigurare);
	linie[strlen(linie)-1] = '\0';
	if (strcmp(linie,"CONFIG_3TS") == 0)
	{
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"IP = %s",ip);
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"Port = %d",&port);
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"h1 = %lf",&hRez1);
		fgets(linie,sizeof(linie),fisierConfigurare);
		linie[strlen(linie)-1] = '\0';
		sscanf(linie,"h2 = %lf",&hRez2);
	}
	if (fisierConfigurare != NULL)
		fclose(fisierConfigurare);

	//if(hostID==0){
		//realizarea conexiunii
		struct sockaddr_in sa;
			
		idSocket = socket(AF_INET, SOCK_STREAM, 0);
		if (idSocket != -1)
		{
			bzero((char *) &sa, sizeof(sa));
			sa.sin_family = AF_INET;
			sa.sin_addr.s_addr = inet_addr(ip);
			sa.sin_port = htons(port);
			conectat = connect(idSocket,(struct sockaddr *) &sa,sizeof(sa));
			if (conectat == -1)
			{
				printf("Client not connected.\n");
				//return 0;
			}
			else
			{
#ifdef SIMULATOR
				if(hostID==0){
					char sendMsg[4]={(char)0, (char)2, (char)8, (char)7};
					write(idSocket,sendMsg,4);
				}
				else{
					char sendMsg[4]={(char)0, (char)2, (char)7};
					write(idSocket,sendMsg,3);
				}
				
				char rcvBuf;
				read(idSocket, &rcvBuf, 1);
				printf("Synchronized!\n");
				
				if(hostID==0){
					//set as regulator
					read(idSocket, &rcvBuf, 1);
					printf("Regulator set!\n");
				}
#endif
				
				printf("Client connected.\n");
			}
		}
	//}
	/*else
	{
	    conectat = -1;
	    printf("Client not connected.\n");
	}
	*/
	
//3TS
//init functions for controllers
  init_t_T1_P();
  init_t_T1_PI();
  init_t_T2_P();
  init_t_T2_PI();
}

void c_connect_sensor_to_return_key(c_bool *sensor) {
  *sensor = os_key_event();
}

void c_connect_sensor_to_random_generator(c_int *sensor) {
  unsigned i, text_message_length;

#ifdef OSEK
  *sensor = (*sensor + 1) % 10;
#else
  *sensor = 1 + (int)(MAXDISPLAY*(double)rand()/(RAND_MAX+1.0));
#endif

  sprintf(text_message, "\t\tSensor reading:  ");

  text_message_length = strlen(text_message);

  for(i = text_message_length; i < *sensor + text_message_length; i++)
    text_message[i] = '*';

  text_message[i] = 0;

  os_print_message(text_message);
}

void c_connect_actuator_to_display(c_string *string) {
  sprintf(text_message, "\t\tActuator update: %s", *string);

  os_print_message(text_message);
}

void c_empty_string(c_string *string) {
  **string = 0;
}

void copy_c_string(c_string *string_source, c_string *string_dest) {
  char *s = (char *) *string_source, *d = (char *) string_dest;

  while (*s)
    *d++ = *s++;

  *d = 0;
}

void c_one(c_int *integer) {
  *integer=1;
}

void copy_c_int(c_int *integer_source, c_int *integer_dest) {
  *integer_dest=*integer_source;
}

void copy_c_double(c_double *d_source, c_double *d_dest){
	*d_dest = *d_source;
}

unsigned c_true() {
  return 1;
}

void c_string_to_string(c_string *string_source, c_string *string_dest) {
  copy_c_string(string_source, string_dest);
}

unsigned c_key_pressed(c_bool *pressed) {
  return *pressed;
}


void c_int_to_int(c_int *integer_source, c_int *integer_dest) {
  copy_c_int(integer_source, integer_dest);
}

void giotto_timer_enable_code(e_machine_type e_machine_func, int relative_time) {
}

int giotto_timer_save_code(void) {
  return get_logical_time();
}

/**
 * dependency is current dependency
 * initial_dep is the initial dependency
 **/
unsigned giotto_timer_trigger_code(int initial_time, int relative_time, unsigned long long dependency, unsigned long long initial_dep) {
	unsigned logic_time = get_logical_time();
	unsigned compute_time = (initial_time + relative_time) % get_logical_time_overflow();
	
	if (initial_dep == 0)
		return (logic_time == compute_time) || relative_time==0;
	
	if (dependency == 0)
		return (logic_time >= compute_time)  || relative_time==0;
		
	return 0;
  //return (get_logical_time() >= (initial_time + relative_time) % get_logical_time_overflow());
}

void c_zero(c_double *var){
	*var=0;
}

//3TS
#define LEN_MSG_GET_HIGHT 1
#define MSG_TYPE 0
#define MSG_TYPE_GET_HEIGHT 71
#define LEN_MSG_RCV_VALUES 7
#define MSG_TYPE_SET_VALUES 70
#define PUMP 1
#define LEN_MSG_SET_VALUE 4

double Convert2BytesToDouble(char *data, int start)
{
	int number = Convert2BytesToInteger(data, start);
	return number*0.01;
}

int Convert2BytesToInteger(char *data, int start)
{
	unsigned int number = 0;
	number = data[start];
	number = number << 8;
	unsigned int no = 0;
	no = data[start+1];
	no = no & 0x00ff;
	number = number | no;
	return number;
}

void ConvertInTo2Bytes(char *data, int value, int position)
{
	char message[2];
	unsigned int val = value;
	val = val >> 8;
	val = val & 0x00FF;
	message[0] = val;
	val = value;
	val = val & 0x00FF;
	message[1] = val;
	memcpy(&data[position], message, sizeof(message));
}

int DoubleToInt(double waterHeight)
{
	int value = 0;
	value = waterHeight*100;
	return value;
}

char buf_read[5+SENSOR_NO*6+2];
c_double h11;
c_double h12;
c_double h13;
c_double h21;
c_double h22;
c_double h23;
//read values from simulator
void f_read(c_double *h1, c_double *h2, c_bool *v1, c_bool *v2)
{
	if (conectat != -1)
	{
		//send request to the simulator
		//printf("READ data 0\n");
		read(idSocket, buf_read, 1);
		if (buf_read[0] == 3)
		{
			read(idSocket, buf_read, 1);
			//printf("SIZE: %D\n", buf_read[0]);
			read(idSocket, buf_read, 5+SENSOR_NO*6+2);
			
			//sensors values
			h11  = Convert2BytesToDouble(buf_read,  5)/100.0;
			h21  = Convert2BytesToDouble(buf_read,  7)/100.0;
			h12  = Convert2BytesToDouble(buf_read, 11)/100.0;
			h22  = Convert2BytesToDouble(buf_read, 13)/100.0;
			h13  = Convert2BytesToDouble(buf_read, 17)/100.0;
			h23  = Convert2BytesToDouble(buf_read, 19)/100.0;
			*v1   = buf_read[23];
			*v2   = buf_read[24];
			//printf("H1: %f H2: %f\n", *h1, *h2);
		}
		else{
			printf("Rcv: %d\n", buf_read[0]);
			printf("Could not get sensors data.\n");
		}
		
		// implement voating for sensor 1
		if(h11 < 70){
			*h1 = h11;
		}
		else if(h12 < 70){
			*h1 = h12;
		}
		else if(h13 < 70){
			*h1 = h13;
		}
		else{
			*h1 = NULL_C_DOUBLE;
			printf("Sensor h1 is faulty.");
		}
		
		// implement voating for sensor 2
		if(h21 < 70){
			*h2 = h21;
		}
		else if(h22 < 70){
			*h2 = h22;
		}
		else if(h23 < 70){
			*h2 = h23;
		}
		else{
			*h2 = NULL_C_DOUBLE;
			printf("Sensor h2 is faulty.");
		}
		//ask for new data
		char sendMsg=(char)7;
		write(idSocket,&sendMsg,1);
	}
	else
		printf("Client not connected.\n");
}

//read reference values
void f_ref(c_double *ref_h1, c_double *ref_h2){
	*ref_h1 = hRez1/100.0;
	*ref_h2 = hRez2/100.0;
}

#define MSG_TYPE_SET_VALUES 40
#define LEN_MSG_SET_VALUES 13
char buf_write[16];
void f_write(c_double *u1, c_double *u2)
{
	if (conectat != -1)
	{
		buf_write[0] = 1;
		buf_write[1] = 4;
		
		//write first command
		int u_int = DoubleToInt(*u1);
		if (u_int < 0)
		    u_int = 0;
		ConvertInTo2Bytes(buf_write, u_int, 2);
		
		//write second command
		u_int = DoubleToInt(*u2);
		if (u_int < 0)
		    u_int = 0;
		ConvertInTo2Bytes(buf_write, u_int, 4);
		//buf_write[6] = 7;
		write(idSocket, buf_write, 6);		
		//printf("U1: %f U2: %f\n", *u1, *u2);
	}
	else
		printf("Client not connected.\n");
}

void addNewValue(double history[], double value)
{
	int i = 0;
	for (i=1;i<MAX_HISTORY;i++)
	{
		history[i-1] = history[i];
	}
	history[MAX_HISTORY-1] = value;
}

int compareHistory(double history[], double historyC[], double prag)
{
	double m = 0, mC = 0;
	int i = 0;
	for (i=0;i<MAX_HISTORY;i++)
	{
		m += history[i];
		mC += historyC[i];
	}
	//printf("m: %lf    mC: %lf   Dif: %lf\n", m, mC, modul(m-mC));
	if (modul(m - mC) < prag)
		return 0;
	else
		return 1;
	}


double nr2 = 0;
double sum2 = 0;
double med2 = 0;

double modul(double value)
{
	if (value < 0)
		return -1*value;
	else
		return value;
}

void f_T1_P(c_double *iH1, c_double *iH1_ref,c_double *oU1)
{
        printf("regulator P_1\n");
        printf("input H P_1: %2.5g------\n",*iH1);
        printf("input H reference signal P_1: %2.5g------\n",*iH1_ref);
        execute_t_T1_P(iH1,iH1_ref,oU1);
        printf("output U P_1: %2.5g------\n",*oU1);
}



void f_T1_PI(c_double *iH1,c_double *iH1_ref, c_double *oU1)
{
        printf("Reg Pi 1\n");
        printf("input H Pi_1: %2.5g------\n",*iH1);
        printf("input H reference signal Pi_1: %2.5g------\n",*iH1_ref);
        execute_t_T1_PI(iH1,iH1_ref,oU1);
        printf("output U Pi_1: %2.5g------\n",*oU1);
}

void f_T2_P(c_double *iH2, c_double *iH2_ref, c_double *oU2)
{
	printf("Reg P 2\n");
        printf("input H P_2: %2.5g------\n",*iH2);
        printf("input H reference signal P_2: %2.5g------\n",*iH2_ref);
        execute_t_T2_P(iH2,iH2_ref,oU2);
        printf("output U P_2: %2.5g------\n",*oU2);
        
}

void f_T2_PI(c_double *iH2, c_double *iH2_ref,c_double *oU2)
{
        printf("Reg Pi 2\n");
        printf("input H Pi_2: %2.5g------\n",*iH2);
        printf("input H reference signal Pi_2: %2.5g------\n",*iH2_ref);
        execute_t_T2_PI(iH2,iH2_ref,oU2);
        printf("output U Pi_2: %2.5g------\n",*oU2);
}

int withPerturbation(c_bool *iV)
{
       printf("PERTURBATIE ---%d\n",*iV);
	return *iV;
}

int withoutPerturbation(c_bool *iV)
{
	return !(*iV);
}

void copy_c_bool(c_bool *b_source, c_bool *b_dest) {
  *b_dest=*b_source;
}

void c_false(c_bool *b) {
  *b = 0;
}

void default_c_double(c_double *d){
	*d = NULL_C_DOUBLE;
}

def_double(c_double  *P_3TS_IO_t_write_input_p_u1)
{
   *P_3TS_IO_t_write_input_p_u1 = 0;
}

