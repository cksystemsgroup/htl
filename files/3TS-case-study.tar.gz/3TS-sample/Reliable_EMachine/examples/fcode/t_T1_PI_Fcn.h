/*
 * t_T1_PI_Fcn.h
 *
 * Real-Time Workshop code generation for Simulink model "t_T1_PI_Fcn.mdl".
 *
 * Model Version                        : 1.99
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Sun Jun 01 02:44:32 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Sun Jun 01 02:44:32 2008
 */

#ifndef _RTW_HEADER_t_T1_PI_Fcn_h_
# define _RTW_HEADER_t_T1_PI_Fcn_h_

#ifndef _t_T1_PI_Fcn_COMMON_INCLUDES_
# define _t_T1_PI_Fcn_COMMON_INCLUDES_
#include <math.h>
#include <float.h>
#include <string.h>

#include "tmwtypes.h"
#include "simstruc_types.h"
#include "rtlibsrc.h"

#endif                                  /* _t_T1_PI_Fcn_COMMON_INCLUDES_ */

#include "t_T1_PI_Fcn_types.h"

/* Intrinsic types */
#ifndef POINTER_T
# define POINTER_T
typedef void * pointer_T;
#endif

/* Block signals (auto storage) */
typedef struct _BlockIO_t_T1_PI_Fcn {
  real_T Sum2;                          /* '<S4>/Sum2' */
  real_T Discrete_Filter;               /* '<S4>/Discrete Filter' */
  real_T Gain;                          /* '<S4>/Gain' */
  real_T Sum;                           /* '<S4>/Sum' */
} BlockIO_t_T1_PI_Fcn;

/* Block states (auto storage) for system: '<Root>' */
typedef struct D_Work_t_T1_PI_Fcn_tag {
  real_T Discrete_Filter_DSTATE;        /* <S4>/Discrete Filter */
} D_Work_t_T1_PI_Fcn;

/* Parameters (auto storage) */
struct _Parameters_t_T1_PI_Fcn {
  real_T Discrete_Filter_A;             /* Computed Parameter: A
                                         * '<S4>/Discrete Filter'
                                         */
  real_T Discrete_Filter_C;             /* Computed Parameter: C
                                         * '<S4>/Discrete Filter'
                                         */
  real_T Discrete_Filter_D;             /* Computed Parameter: D
                                         * '<S4>/Discrete Filter'
                                         */
  real_T Gain_Gain;                     /* Expression: 1/Ti1
                                         * '<S4>/Gain'
                                         */
  real_T Gain1_Gain;                    /* Expression: kR1
                                         * '<S4>/Gain1'
                                         */
};

/* Real-time Model Data Structure */
struct _RT_MODEL_t_T1_PI_Fcn_Tag {
  const char *errorStatus;
};

/* Real-time Model object */
extern RT_MODEL_t_T1_PI_Fcn *t_T1_PI_Fcn_M;

/* Macros for accessing real-time model data structure  */

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm) (rtm)->errorStatus
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val) (rtm)->errorStatus = ((val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm) (0.0)
#endif

/* Backward compatibility for real-time model name change */
#define t_T1_PI_Fcn_rtO                 t_T1_PI_Fcn_M
#define t_T1_PI_Fcn_RT_OBJECT           RT_MODEL_t_T1_PI_Fcn

/* Block parameters (auto storage) */
extern const Parameters_t_T1_PI_Fcn t_T1_PI_Fcn_P;

/* Block signals (auto storage) */
extern BlockIO_t_T1_PI_Fcn t_T1_PI_Fcn_B;

/* Block states (auto storage) */
extern D_Work_t_T1_PI_Fcn t_T1_PI_Fcn_DWork;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  RTW declares the memory for these signals
 * and exports their symbols.
 *
 */

extern real_T Out_Signal_t_T1_PI1;      /* '<S4>/Gain1' */
extern real_T In_Signal_t_T1_PI1;       /* '<Root>/in_t_T1_PI1' */
extern real_T In_Signal_t_T1_PI2;       /* '<Root>/in_t_T1_PI2' */

/* Model entry point functions */
extern void t_T1_PI_Fcn_initialize(boolean_T firstTime);
extern void t_T1_PI_Fcn_step(void);
extern void t_T1_PI_Fcn_terminate(void);

/* 
 * The generated code includes comments that allow you to trace directly 
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : t_T1_PI_Fcn
 * '<S1>'   : t_T1_PI_Fcn/SigSpec_in_t_T1_PI1
 * '<S2>'   : t_T1_PI_Fcn/SigSpec_in_t_T1_PI2
 * '<S3>'   : t_T1_PI_Fcn/t_T1_PI_Fcn
 * '<S4>'   : t_T1_PI_Fcn/t_T1_PI_Fcn/task subsystem
 */

#endif                                  /* _RTW_HEADER_t_T1_PI_Fcn_h_ */
