/*
 * t_T2_PI_Fcn_data.c
 *
 * Real-Time Workshop code generation for Simulink model "t_T2_PI_Fcn.mdl".
 *
 * Model Version                        : 1.99
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Tue Jun 03 16:48:32 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Tue Jun 03 16:48:32 2008
 */

#include "t_T2_PI_Fcn.h"
#include "t_T2_PI_Fcn_private.h"

/* Block parameters (auto storage) */
const Parameters_t_T2_PI_Fcn t_T2_PI_Fcn_P = {
  1.0 ,                                 /* Discrete_Filter_A : '<S4>/Discrete Filter' */
  1.0 ,                                 /* Discrete_Filter_C : '<S4>/Discrete Filter' */
  1.0 ,                                 /* Discrete_Filter_D : '<S4>/Discrete Filter' */
  6.6666666666666666E-002 ,             /* Gain_Gain : '<S4>/Gain' */
  30.0                                  /* Gain1_Gain : '<S4>/Gain1' */
};

