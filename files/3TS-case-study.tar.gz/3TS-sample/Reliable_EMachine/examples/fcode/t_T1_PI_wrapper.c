#include "t_T1_PI_wrapper.h"

real_T In_Signal_t_T1_PI1;

real_T In_Signal_t_T1_PI2;

real_T Out_Signal_t_T1_PI1;


extern void init_t_T1_PI()
{
    t_T1_PI_Fcn_initialize(1);
}

extern void execute_t_T1_PI(double *u1,double *u2,double *y1)
{
In_Signal_t_T1_PI1 = (real_T)*u1;

In_Signal_t_T1_PI2 = (real_T)*u2;

t_T1_PI_Fcn_step();
*y1 = (double)Out_Signal_t_T1_PI1;

}

extern void terminate_t_T1_PI()
{
   t_T1_PI_Fcn_terminate();
}

