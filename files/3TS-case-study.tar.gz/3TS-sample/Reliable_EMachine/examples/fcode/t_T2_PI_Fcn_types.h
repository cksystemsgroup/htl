/*
 * t_T2_PI_Fcn_types.h
 *
 * Real-Time Workshop code generation for Simulink model "t_T2_PI_Fcn.mdl".
 *
 * Model Version                        : 1.99
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Tue Jun 03 16:48:32 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Tue Jun 03 16:48:32 2008
 */

#ifndef _RTW_HEADER_t_T2_PI_Fcn_types_h_
# define _RTW_HEADER_t_T2_PI_Fcn_types_h_

/* Parameters (auto storage) */
typedef struct _Parameters_t_T2_PI_Fcn Parameters_t_T2_PI_Fcn;

/* Forward declaration for rtModel */
typedef struct _RT_MODEL_t_T2_PI_Fcn_Tag RT_MODEL_t_T2_PI_Fcn;

#endif                                  /* _RTW_HEADER_t_T2_PI_Fcn_types_h_ */
