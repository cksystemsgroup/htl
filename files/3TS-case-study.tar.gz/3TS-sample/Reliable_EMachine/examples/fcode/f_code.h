/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

/*

  Author: Christoph Kirsch, 	cm@eecs.berkeley.edu
          Slobodan Matic, 		matic@eecs.berkeley.edu
          Daniel Iercan, 		diercan@cs.uni-salzburg.at


*/

#ifndef _F_CODE_
#define _F_CODE_

#include <errno.h>

#include <arpa/inet.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#include "f_table.h"
#include "f_spec.h"
#include "f_interface.h"
#include "types.h"
#include "v_code.h"
//#include "rg_client.h"
#include "measure.h"

void f_code_init(int hostID);
void c_connect_sensor_to_return_key(c_bool *sensor);
void c_connect_sensor_to_random_generator(c_int *sensor);
void c_connect_actuator_to_display(c_string *string);
void c_empty_string(c_string *string);
void copy_c_string(c_string *string_source, c_string *string_dest) ;
void c_one(c_int *integer);
void copy_c_int(c_int *integer_source, c_int *integer_dest);
unsigned c_true();
void c_string_to_string(c_string *string_source, c_string *string_dest);
unsigned c_key_pressed(c_bool *pressed);
void c_int_to_int(c_int *integer_source, c_int *integer_dest);
void giotto_timer_enable_code(e_machine_type e_machine_func, int relative_time);
int giotto_timer_save_code(void) ;
unsigned giotto_timer_trigger_code(int initial_time, int relative_time, unsigned long long dependency, unsigned long long initial_dep);
void c_zero(c_double *var);

//3TS

void f_read(c_double *h1, c_double *h2,c_bool *v1,c_bool *v2);
void f_ref(c_double *ref_h1, c_double *ref_h2);
void f_write(c_double *u1, c_double *u2);
void f_T1_P(c_double *iH1,c_double *iH1_ref, c_double *oU1);
void f_T1_PI(c_double *iH1,c_double *iH1_ref, c_double *oU1);
void f_T2_P(c_double *iH2, c_double *iH2_ref, c_double *oU2);
void f_T2_PI(c_double *iH2, c_double *iH2_ref, c_double *oU2);
int withPerturbation(c_bool *p);
int withoutPerturbation(c_bool *p);
double modul(double value);
void addNewValue(double history[], double value);
int compareHistory(double history[], double historyC[], double prag);
void copy_c_bool(c_bool *b_source, c_bool *b_dest);
void copy_c_double(c_double *d_source, c_double *d_dest);
void c_false(c_bool *b);

//1TS

void default_c_double(c_double *d);


#endif

		
