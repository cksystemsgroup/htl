/*
 * Real-Time Workshop code generation for Simulink model "t_T2_P_Fcn.mdl".
 *
 * Model Version                        : 1.114
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Sat Jun 14 15:37:42 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Sat Jun 14 15:37:42 2008
 */

#include "t_T2_P_Fcn.h"
#include "t_T2_P_Fcn_private.h"

/* Exported block signals */
real_T Out_Signal_t_T2_P1;              /* <S4>/Saturation */
real_T In_Signal_t_T2_P1;               /* <Root>/in_t_T2_P1 */
real_T In_Signal_t_T2_P2;               /* <Root>/in_t_T2_P2 */

/* Block signals (auto storage) */
BlockIO_t_T2_P_Fcn t_T2_P_Fcn_B;

/* Real-time model */
RT_MODEL_t_T2_P_Fcn t_T2_P_Fcn_M_;
RT_MODEL_t_T2_P_Fcn *t_T2_P_Fcn_M = &t_T2_P_Fcn_M_;

/* Model step function */
void t_T2_P_Fcn_step(void)
{

  /* SubSystem: '<S3>/task subsystem' */

  /* Output and update for atomic system: '<S3>/task subsystem' */

  /* Sum: '<S4>/Sum2' incorporates:
   *   Inport: '<Root>/in_t_T2_P1'
   *   Inport: '<Root>/in_t_T2_P2'
   */
  t_T2_P_Fcn_B.Sum2 = - In_Signal_t_T2_P1 + In_Signal_t_T2_P2;

  /* Gain: '<S4>/kR'
   *
   * Regarding '<S4>/kR':
   *   Gain value: t_T2_P_Fcn_P.kR_Gain
   */
  t_T2_P_Fcn_B.kR = t_T2_P_Fcn_B.Sum2 * t_T2_P_Fcn_P.kR_Gain;

  /* Saturate: '<S4>/Saturation'
   *
   * Regarding '<S4>/Saturation':
   *   Lower limit: t_T2_P_Fcn_P.Saturation_LowerSat
   *   Upper limit: t_T2_P_Fcn_P.Saturation_UpperSat
   */
  if (t_T2_P_Fcn_B.kR >= t_T2_P_Fcn_P.Saturation_UpperSat) {
    Out_Signal_t_T2_P1 = t_T2_P_Fcn_P.Saturation_UpperSat;
  } else if (t_T2_P_Fcn_B.kR <= t_T2_P_Fcn_P.Saturation_LowerSat) {
    Out_Signal_t_T2_P1 = t_T2_P_Fcn_P.Saturation_LowerSat;
  } else {
    Out_Signal_t_T2_P1 = t_T2_P_Fcn_B.kR;
  }

  /* (no update code required) */
}

/* Model initialize function */
void t_T2_P_Fcn_initialize(boolean_T firstTime)
{
  if (firstTime) {
    /* registration code */
    rtmSetErrorStatus(t_T2_P_Fcn_M, (const char_T *)0);

    /* block I/O */
    {
      void *b = (void *) &t_T2_P_Fcn_B;
      {
        int_T i;

        b =&t_T2_P_Fcn_B.Sum2;
        for (i = 0; i < 2; i++) {
          ((real_T*)b)[i] = 0.0;
        }
      }

      /* exported global signals */
      Out_Signal_t_T2_P1 = 0.0;
    }

    /* external inputs */
    In_Signal_t_T2_P1 = 0.0;
    In_Signal_t_T2_P2 = 0.0;

    /* external outputs */
    Out_Signal_t_T2_P1 = 0.0;
  }
}

/* Model terminate function */
void t_T2_P_Fcn_terminate(void)
{
  /* (no terminate code required) */
}

