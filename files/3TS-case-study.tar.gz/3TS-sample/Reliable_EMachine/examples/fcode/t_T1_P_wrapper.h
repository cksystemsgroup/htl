#ifndef __WRAPPER_H
#define __WRAPPER_H

#include "tmwtypes.h"
#include "simstruc_types.h"
#include "t_T1_P_Fcn.h"
extern real_T  In_Signal_t_T1_P1;

extern real_T  In_Signal_t_T1_P2;

extern real_T  Out_Signal_t_T1_P1;


extern void init_t_T1_P();

extern void execute_t_T1_P(double *u1,double *u2, double *y1);

extern void terminate_t_T1_P();

#endif

