/*
 * t_T1_P_Fcn_types.h
 *
 * Real-Time Workshop code generation for Simulink model "t_T1_P_Fcn.mdl".
 *
 * Model Version                        : 1.114
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Sat Jun 14 15:39:21 2008
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Sat Jun 14 15:39:21 2008
 */

#ifndef _RTW_HEADER_t_T1_P_Fcn_types_h_
# define _RTW_HEADER_t_T1_P_Fcn_types_h_

/* Parameters (auto storage) */
typedef struct _Parameters_t_T1_P_Fcn Parameters_t_T1_P_Fcn;

/* Forward declaration for rtModel */
typedef struct _RT_MODEL_t_T1_P_Fcn_Tag RT_MODEL_t_T1_P_Fcn;

#endif                                  /* _RTW_HEADER_t_T1_P_Fcn_types_h_ */
