#ifndef __WRAPPER_H
#define __WRAPPER_H

#include "tmwtypes.h"
#include "simstruc_types.h"
#include "t_T1_PI_Fcn.h"
extern real_T  In_Signal_t_T1_PI1;

extern real_T  In_Signal_t_T1_PI2;

extern real_T  Out_Signal_t_T1_PI1;


extern void init_t_T1_PI();

extern void execute_t_T1_PI(double *u1,double *u2, double *y1);

extern void terminate_t_T1_PI();

#endif

