#include <stdlib.h>
#include "v_interface.h"

/* this function will return 1 with the given probability.*/
int flip_coin(float probability){
	return ((float)rand())/((float)RAND_MAX)<=probability;
}