#ifndef VINTERFACE_H_
#define VINTERFACE_H_

/* this function will return 1 with the given probability.*/
int flip_coin(float probability);

#endif