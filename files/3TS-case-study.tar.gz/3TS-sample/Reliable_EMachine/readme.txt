Author: Daniel Iercan, diercan@cs.uni-salzburg.at

This is the extended emachine that support new TSL features.

Directory strcuture:
	- disassembler 	- contains the source code for classic giotto disassembler
	- emachine 		- contains the source code for the emachine
	- examples		- contains some TSL examples plus the C code neccesarly for this
	- giottoc		- contains the jar file containg the TSL compiler
	- uploader		- contains uploader source code
	
How to build (before you can build or run you need the compiler jar file):
	- if you want to build or run on Linux then you have to edit the os.h file from emachine directory
	  as follows: remove the line '#define MAC_OS_X'
	- to build just type: make all
	- to run just type: make run
	
How to clean:
	- make clean
	
For more information look at makefile