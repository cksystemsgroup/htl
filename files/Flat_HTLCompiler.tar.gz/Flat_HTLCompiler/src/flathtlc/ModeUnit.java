/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package flathtlc;

import flathtlc.InheritTable;
import flathtlc.ProgramSymbolTable;
import flathtlc.SymbolTable;
import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.AActuatorDeviceDriver;
import flathtlc.node.ACommunicatorDeclaration;
import flathtlc.node.ACommunicatorInstance;
import flathtlc.node.AModeDeclaration;
import flathtlc.node.ASensorDeviceDriver;

/**
 * 
 * This class computes the number of units (smallest time unit) for each Giotto
 * mode.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 *         Daniel Iercan, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class ModeUnit extends DepthFirstAdapter {
	public int nUnits = 1;
	
	public int modePeriod;
	
	public int smalestPeriod;
	
	private final String programName;
	
	private final SymbolTable symbolTable;
	
	private final InheritTable inheritTable;

	public ModeUnit(String programName, SymbolTable symbolTable, InheritTable inheritTable){
		this.programName = programName;
		this.symbolTable = symbolTable;
		this.inheritTable = inheritTable;
	}
	
	public void inAModeDeclaration(AModeDeclaration node) {
		modePeriod = Integer.parseInt(node.getModePeriod().getText());
		smalestPeriod = modePeriod;
	}
	
	public void outAModeDeclaration(AModeDeclaration node) {
					
		nUnits=modePeriod/smalestPeriod;
		
		//System.out.println("Mode "+node.getModeName().getText()+", Number of units="+nUnits+ ", Unit period="+smalestPeriod);
	}

	public static int gcd(int a, int b) {
		if (b == 0)
			return a;
		else
			return gcd(b, a % b);
	}

	public static int lcm(int a, int b) {
		return (a * b) / gcd(a, b);
	}
	

	public void outASensorDeviceDriver(ASensorDeviceDriver node){
		String commName = node.getCommunicatorName().getText();
		int commInstance = Integer.parseInt(node.getCommunicatorInstance().getText());
		int commPeriod = getCommunicatorPeriod(commName);
		
		if(commInstance > 0)
			smalestPeriod = gcd(smalestPeriod, commInstance*commPeriod);
		
	}
	
	public void outAActuatorDeviceDriver(AActuatorDeviceDriver node){
		String commName = node.getCommunicatorName().getText();
		int commInstance = Integer.parseInt(node.getCommunicatorInstance().getText());
		int commPeriod = getCommunicatorPeriod(commName);
		
		if(commInstance > 0)
			smalestPeriod = gcd(smalestPeriod, commInstance*commPeriod);
	}
	
	public void outACommunicatorInstance(ACommunicatorInstance node){
		String commName = node.getCommunicatorPortName().getText();
		int commInstance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
		int commPeriod = getCommunicatorPeriod(commName);
		
		if(commInstance > 0)
			smalestPeriod = gcd(smalestPeriod, commInstance*commPeriod);
	}
	
	/**
	 * 
	 * @param name
	 * @return communicator period
	 */
	private int getCommunicatorPeriod(String name){
		int period=0;
		
		String program = programName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				period = Integer.parseInt(((ACommunicatorDeclaration) pSymbolTable.communicators
						.get(name)).getCommunicatorPeriod().getText());
				break;
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return period;
	}
}
