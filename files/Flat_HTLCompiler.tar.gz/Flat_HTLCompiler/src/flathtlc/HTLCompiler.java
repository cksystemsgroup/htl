/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package flathtlc;

import flathtlc.CST2AST;
import flathtlc.DependencyTable;
import flathtlc.ECode;
import flathtlc.FTable;
import flathtlc.Flattening;
import flathtlc.FrequencyChecker;
import flathtlc.HTable;
import flathtlc.InheritTable;
import flathtlc.ProgramSymbolTable;
import flathtlc.SchedulabilityChecker;
import flathtlc.SymbolTable;
import flathtlc.TypeChecker;
import flathtlc.lexer.Lexer;
import flathtlc.node.Start;
import flathtlc.parser.Parser;

import java.io.File;
import java.io.FileReader;
import java.io.PushbackReader;
import java.util.Vector;


/**
 * 
 * This class contains the main method for tslc. Some code fragments are
 * protected by the copyright of the SableCC team.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 *         Daniel Iercam, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class HTLCompiler {
	private static boolean pureGiotto = true;

	private static boolean dynamicGiotto = false;

	private static boolean simulinkGiotto = false;
	
	private static String currentHost;
	
	public static int codeSize = 0;
	
	public static boolean noSchedulability = false;

	private static void displayCopyright() {
		System.out.println();
		System.out.println("This is the HTL compiler tslc version 0.2");
		System.out.println();
		System.out
				.println("Copyright (C) 2005 The Regents of the University of California.");
		System.out.println("All rights reserved.");
		System.out.println();
		System.out.println("See the COPYRIGHT file for details.");
		System.out.println();
		System.out.println("This software comes with ABSOLUTELY NO WARRANTY.");
		System.out.println();
	}

	private static void displayUsage() {
		System.out
				.println("Usage: tslc [-d destination | -annotated | -dynamic | -simulink | -host] filename");
	}

	public static void main(String[] arguments) {
		String d_option = null;
		Vector filename = new Vector();

		if (arguments.length == 0) {
			displayCopyright();
			displayUsage();
			System.exit(1);
		}

		displayCopyright();

		{
			int arg = 0;

			while (arg < arguments.length) {
				if (arguments[arg].equals("-d")) {
					if ((d_option == null) && (++arg < arguments.length)) {
						d_option = arguments[arg];
					} else {
						displayUsage();
						System.exit(1);
					}
				} else if (arguments[arg].equals("-annotated")) {
					if (pureGiotto) {
						pureGiotto = false;
					} else {
						displayUsage();
						System.exit(1);
					}
				} else if (arguments[arg].equals("-dynamic")) {
					if (!dynamicGiotto) {
						dynamicGiotto = true;
					} else {
						displayUsage();
						System.exit(1);
					}
				} else if (arguments[arg].equals("-simulink")) {
					if (!simulinkGiotto) {
						simulinkGiotto = true;
					} else {
						displayUsage();
						System.exit(1);
					}
				} 
				else if (arguments[arg].equals("-host")) {
					if ((currentHost == null) && (++arg < arguments.length)) {
						currentHost = arguments[arg];
					} else {
						displayUsage();
						System.exit(1);
					}
				}
				else if (filename.size() == 0) {
					filename.addElement(arguments[arg]);
				} else {
					displayUsage();
					System.exit(1);
				}

				arg++;
			}

			if (filename.size() == 0) {
				displayUsage();
				System.exit(1);
			}
		}

		try {
			for (int i = 0; i < filename.size(); i++) {
				processHTL((String) filename.elementAt(i), d_option);
			}
		} catch (Exception e) {
			System.out.println(e);
			System.exit(1);
		} catch (Throwable e) {
			System.out.println(e);
			System.exit(1);
		} finally {
			//System.exit(0);
		}
	}

	public static void processHTL(String grammar, String destDir)
			throws Exception, Throwable {
		File in;
		File dir;

		in = new File(grammar);
		in = new File(in.getAbsolutePath());

		if (destDir == null) {
			dir = new File(in.getParent());
		} else {
			dir = new File(destDir);
			dir = new File(dir.getAbsolutePath());
		}

		processGiotto(in, dir);
	}

	public static void processGiotto(File in, File dir) throws Exception,
			Throwable {
		if (!in.exists()) {
			System.out.println("ERROR: Giotto program file " + in.getName()
					+ " does not exist.");
			System.exit(1);
		}

		if (!dir.exists()) {
			System.out.println("ERROR: destination directory " + dir.getName()
					+ " does not exist.");
			System.exit(1);
		}

		System.out.println("-- Generating code for " + in.getName() + " in "
				+ dir.getPath());

		if (pureGiotto)
			System.out.println("-- Disregard annotations");

		if (dynamicGiotto)
			System.out.println("-- Dynamic Giotto (Prototype)");

		if (simulinkGiotto)
			System.out
					.println("-- Generate Simulink-compatible code (Prototype)");

		System.out.println();

		FileReader temp;

		// Build the AST
		final Start tree = new Parser(new Lexer(new PushbackReader(
				temp = new FileReader(in)))).parse();

		temp.close();

		try {
			SymbolTable symbolTable;
			InheritTable inheritTable;
			FTable functionTable;
			//STable scheduleTable;
			ECode ecode;
			DependencyTable dependencyTable;
			HTable hostTable;

			// Apply concrete to abstract syntax tree translations
			tree.apply(new CST2AST());
			//System.out.println("CST2AST\n");

			// Get symbol table
			tree.apply(symbolTable = new SymbolTable(dir));
			System.out.println("Symbol Table... OK");

			// Get Inherit Table
			tree.apply(inheritTable = new InheritTable(symbolTable));
			System.out.println("Inherit Table... OK");
			
			// Get Host Table
			hostTable = new HTable(symbolTable, inheritTable, pureGiotto, currentHost);
			hostTable.computeHTable(tree);
			System.out.println("Host Table... OK");
			
			// Type check
			tree.apply(new TypeChecker(symbolTable, inheritTable));
			System.out.println("Type Checker... OK");
									
			// Get dependency table
			tree.apply(dependencyTable=new DependencyTable(symbolTable));
			System.out.println("Dependency Table... OK");
			
			// Frequency check
			tree.apply(new FrequencyChecker(symbolTable, dependencyTable, inheritTable));
			System.out.println("Frequency Checker... OK");
			
			if(!noSchedulability){
				//Schedulability check
				inheritTable.getRoorProgramDeclaration().apply(new SchedulabilityChecker(symbolTable, inheritTable, dependencyTable, hostTable));
				System.out.println("Schedulability Checker... OK");
			}
			else{
				System.out.println("Schedulability Checker... NO");
			}
			
			// Time safety check
			//tree.apply(new TimeSafetyChecker(symbolTable));
			//System.out.println("TimeSafetyChecker... OK");
			
			// Generate function table
//			tree.apply(functionTable = new FTable(symbolTable, dependencyTable, inheritTable));
//			System.out.println("Function Table... OK");

			// Generate schedule table
			//tree.apply(scheduleTable = new STable(symbolTable));

			// Generate E code
//			tree.apply(ecode = new ECode(symbolTable, dependencyTable, inheritTable, functionTable));
//			System.out.println("E Code... OK");
			
			
			//*****************************************************************
			//Flatten the program
			((ProgramSymbolTable)symbolTable.programs.get(
					inheritTable.getRootProgramName())).program.apply(new Flattening(symbolTable));
			System.out.println("Flattening... OK");
			
			// Get Flatten Symbol Table
			tree.apply(symbolTable = new SymbolTable(dir));
			System.out.println("Flatten Symbol Table... OK");

			// Get Flatten Inherit Table
			tree.apply(inheritTable = new InheritTable(symbolTable));
			System.out.println("Flatten Inherit Table... OK");
			
			// Get Host Table
			hostTable = new HTable(symbolTable, inheritTable, pureGiotto, currentHost);
			hostTable.computeHTable(tree);
			System.out.println("Flatten Host Table... OK");
			
			//Flatten Type check
			//tree.apply(new TypeChecker(symbolTable, inheritTable));
			//System.out.println("Flatten Type Checker... OK");
									
			// Get flatten dependency table
			tree.apply(dependencyTable=new DependencyTable(symbolTable));
			System.out.println("Flatten Dependency Table... OK");
			
			//Flatten Frequency check
			//tree.apply(new FrequencyChecker(symbolTable, dependencyTable, inheritTable));
			//System.out.println("Flatten Frequency Checker... OK");
			
			// Generate flatten function table
			tree.apply(functionTable = new FTable(symbolTable, dependencyTable, inheritTable, pureGiotto));
			System.out.println("Flatten Function Table... OK");

			//Flatten Generate E code
			tree.apply(ecode = new ECode(symbolTable, dependencyTable, inheritTable, functionTable, hostTable, pureGiotto));
			System.out.println("Flatten E Code... OK");
			codeSize = ecode.program.size();
			
			//Generate host table
			tree.apply(hostTable);
			System.out.println("Generate host table... OK");
			System.out.println("Complete.");

		} catch (Exception e) {
		    e.printStackTrace();
			System.out.println("Error: "+e.getMessage());
		}
	}
}
