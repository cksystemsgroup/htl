/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package flathtlc;

import flathtlc.CodeGen;
import flathtlc.DependencyTable;
import flathtlc.FTable;
import flathtlc.HTable;
import flathtlc.InheritTable;
import flathtlc.ModeUnit;
import flathtlc.ModuleSymbolTable;
import flathtlc.ProgramSymbolTable;
import flathtlc.StringCast;
import flathtlc.StringComparator;
import flathtlc.SymbolTable;
import flathtlc.TypedTreeMap;
import flathtlc.Utils;
import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.AActualPorts;
import flathtlc.node.AActuatorDeviceDriver;
import flathtlc.node.ACommunicatorDeclaration;
import flathtlc.node.ACommunicatorInstance;
import flathtlc.node.AConcreteActualPort;
import flathtlc.node.AHostDeclaration;
import flathtlc.node.AModeDeclaration;
import flathtlc.node.AModeSwitch;
import flathtlc.node.AModuleDeclaration;
import flathtlc.node.APortDeclaration;
import flathtlc.node.AProgramDeclaration;
import flathtlc.node.AProgramDeclarationList;
import flathtlc.node.ASensorDeviceDriver;
import flathtlc.node.AStatePort;
import flathtlc.node.ATaskDeclaration;
import flathtlc.node.ATaskInvocation;
import flathtlc.node.NodeCast;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;



/**
 * 
 * This class implements the e code generation for the embedded machine, which
 * is the target platform of tslc.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 *         Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 */
public class ECode extends CodeGen {
	private FTable functionTable;

	private InheritTable inheritTable;

	private final Hashtable modeUnits = new Hashtable();

	private ModeUnit currentModeUnit;

	private int minUnitPeriod = -1;

	public final ArrayList program = new ArrayList();

	private String currentModeName = null;
	
	private String currentProgramName = null;
	
	private String currentModuleName = null;
	
	private boolean isModuleOnHost;
	
	private ProgramSymbolTable programSymbolTable;

	private ModuleSymbolTable moduleSymbolTable;

	private Hashtable modeAddresses;

	private Hashtable programAddresses;
	
	private Hashtable moduleAddresses;
	
	private final HTable hostTable;
	
	private final boolean pureGiotto;
	
	private ComputePrecedenceSets precedenceSets;

	private static final int giottoTriggerIndex = 0;

	private static final int nopCode = 0;

	private static final int futureCode = 1;

	private static final int callCode = 2;

	private static final int releaseCode = 3;

	private static final int ifCode = 4;

	private static final int jumpCode = 5;

	private static final int returnCode = 6;
	
	private DependencyTable dependencyTable;

	public ECode(SymbolTable symbolTable, DependencyTable dependencyTable, InheritTable inheritTable, FTable functionTable, HTable hostTable, boolean pureGiotto) {
		super(symbolTable, "ecode", "e_code.c", "e_code.h", "e_spec.txt",
				"e_code.b");

		this.functionTable = functionTable;
		this.inheritTable = inheritTable;
		this.dependencyTable=dependencyTable;
		this.pureGiotto = pureGiotto;
		this.hostTable = hostTable;
	}

	// Action code

	public void emitCFileHeader(AProgramDeclarationList node) {
		emit("Header");

		emit("Include");

		node.apply(new ComputeModeUnits());

		node.apply(new GenECode());
	}

	public void emitCFileBody(AProgramDeclarationList node) {
		emit("ProgramHeader");

		int address = 0;

		for (ListIterator iterator = program.listIterator(); iterator.hasNext(); address++) {
			Instruction instruction = (Instruction) iterator.next();

			if (address != 0)
				emit("ProgramComma");

			instruction.emitCode(address);
		}

		emit("ProgramEnd");
	}

	public void emitHFileHeader(AProgramDeclarationList node) {
		emit("Header");
	}

	public void emitHFileBody(AProgramDeclarationList node) {
		emit("ProgramSize", new String[] { Integer.toString(program.size()),
				Integer.toString(program.size()), Integer.toString(countFutureInstructions()),/*Integer.toString(maxUnits), */
				Integer.toString(minUnitPeriod) });
	}
	
	private int countFutureInstructions(){
	    final Iterator it=program.iterator();
	    int counter=0;
	    while(it.hasNext()){
	        if(((Instruction)it.next()).opcode==futureCode){
	            counter++;
	        }
	    }
	    return counter;
	}

	public void emitBFile(AProgramDeclarationList node) {
		emitBinaryCode(program.size());
		emitBinaryCode(minUnitPeriod);

		for (ListIterator iterator = program.listIterator(); iterator.hasNext();) {
			Instruction instruction = (Instruction) iterator.next();

			emitBinaryCode(instruction.opcode);
			emitBinaryCode(instruction.arg1);
			emitBinaryCode(instruction.arg2);
			emitBinaryCode(instruction.arg3);
			emitBinaryCode(instruction.arg4);
		}
	}

	private class ComputeModeUnits extends DepthFirstAdapter {
		private String programName;
		private String moduleName;
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			programName = node.getProgramName().getText();
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			programName = "";
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			moduleName = node.getModuleName().getText();
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			moduleName = "";
		}
		
		public void inAModeDeclaration(AModeDeclaration node) {
			ModeUnit modeUnit;

			node.apply(modeUnit = new ModeUnit(programName, symbolTable, inheritTable));
			
			if(minUnitPeriod==-1){
				minUnitPeriod = modeUnit.smalestPeriod;
			}
			else{
				minUnitPeriod = ModeUnit.gcd(minUnitPeriod, modeUnit.smalestPeriod);
			}

			final String modeName = node.getModeName().getText();

			modeUnits.put(programName + "."+moduleName+"."+modeName, modeUnit);
		}
	}
	
	private class ComputeHigherReadCommInstance extends DepthFirstAdapter{
		public int higherOffset=0;
		public ACommunicatorInstance higherCommInstance;
		
		private boolean inAInputList;
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts().equals(node)){
				inAInputList = true;
			}
			else{
				inAInputList = false;
			}
		}
		
		
		public void inACommunicatorInstance(ACommunicatorInstance node){
			if(inAInputList){
				int commPeriod = getCommunicatorPeriod(node.getCommunicatorPortName().getText());
				int instance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
				
				if(commPeriod*instance > higherOffset){
					higherOffset = commPeriod*instance;
					higherCommInstance = node;
				}
			}
		}
	}
	
	private class ComputePrecedenceSets extends DepthFirstAdapter{
		
		public Map precedenceTasks = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		public Map precedenceReadSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		private boolean isPrecedenceTask = false;
		private boolean inAInputActualList = false;
		
		public void inATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
			String sufix = currentProgramName+"."+currentModuleName+"."+currentModeName;
			
			Map modeDpendencies = (Map)dependencyTable.taskDependencies.get(sufix);
			ArrayList taskDependencies = (ArrayList)modeDpendencies.get(taskName);
			if(taskDependencies.size()>0){
				precedenceTasks.put(taskName, node);
				isPrecedenceTask = true;
			}
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			isPrecedenceTask = false;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAInputActualList = true;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAInputActualList=false;
    		}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(inAInputActualList && isPrecedenceTask){
				precedenceReadSet.put(node.getCommunicatorPortName().getText(), node);
			}
		}
	}
	
	private ACommunicatorDeclaration getCommunicator(String name){
		String program = currentProgramName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				return (ACommunicatorDeclaration)pSymbolTable.communicators.get(name);
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return null;
	}
	
	private int getCommunicatorPeriod(String name){
		ACommunicatorDeclaration comm = getCommunicator(name);		
		
		if(comm != null)
			return Integer.parseInt(comm.getCommunicatorPeriod().getText());
		else
			return 0;
	}
	
	private String getCommunicatorType(String name){
		ACommunicatorDeclaration comm = getCommunicator(name);		
		
		if(comm != null)
			return comm.getTypeName().getText();
		else
			return "";
	}
	
	private boolean isEnabled(int unitPeriod, int unit, int commPeriod, int commInstance) {
		return (unitPeriod * unit == (commPeriod * commInstance) % currentModeUnit.modePeriod);
	}
	
	private boolean isEnabled(int unitPeriod, int unit, int offset){
		return (unitPeriod * unit == offset);
	}
		
	private void fixupFuture(Instruction instruction, int address) {
		if (instruction.opcode == futureCode) {
			final int nextAddress = instruction.arg2;

			instruction.arg2 = address;

			if (nextAddress < -1)
				fixupFuture((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-future instruction.");
	}
	
	private void fixupIf(Instruction instruction, int address) {
		if (instruction.opcode == ifCode || instruction.opcode == futureCode) {
			final int nextAddress = instruction.arg2;

			instruction.arg2 = address;

			if (nextAddress < -1)
				fixupIf((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-future instruction.");
	}

	private void fixupJump(Instruction instruction, int address) {
		if (instruction.opcode == jumpCode) {
			final int nextAddress = instruction.arg1;

			instruction.arg1 = address;

			if (nextAddress < -1)
				fixupJump((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-jump instruction.");
	}

	private class GenProgramECode extends DepthFirstAdapter{
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			String programName = node.getProgramName().getText();
			int programAddress = program.size();
			FixupChain fixupChain;
			
			if(programAddresses.containsKey(programName)){
				fixupChain = (FixupChain)programAddresses.get(programName);
				final int fixupProgramAddress = fixupChain.address;

				if (fixupProgramAddress < -1) {
					fixupJump((Instruction) program
							.get(-(fixupProgramAddress + 2)),
							programAddress);
				} else if (fixupProgramAddress == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous program name declaration.");
			} else
				programAddresses.put(programName, new FixupChain(
						programAddress, programName));
				
		}
		
		public void outACommunicatorDeclaration(ACommunicatorDeclaration node){
	    	String name = node.getCommunicatorName().getText();
	    	String initDriver = node.getInitDriver().getText();
	    	
	    	// init driver for each communicator
			final int driverIndex = functionTable.getInitCommDriverIndex(currentProgramName, name, initDriver);

			program.add(new Instruction(callCode, driverIndex,
					"Call initialization driver: "
					+ functionTable.getInitCommDriverWrapperName(currentProgramName, name, initDriver)));
			
	    }
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			String moduleName = node.getModuleName().getText();
			//generate future 0 to each module in the program
			int fixupModuleAddress = -(program.size()+2);
			FixupChain fixupChain = new FixupChain(fixupModuleAddress, moduleName);
			
			moduleAddresses.put(moduleName, fixupChain);
			
			program.add(new Instruction(futureCode, giottoTriggerIndex,
					-1, 0,0,0,
					"Triggered jump to module: " + moduleName ));
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			program.add(new Instruction(returnCode, "Return from the program "+currentProgramName+"."));
		}
	}
	
	private class GenModuleECode extends DepthFirstAdapter{
		
		private String modeName;
		private String taskName;
		private boolean inAActualInputList;
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			String moduleName = node.getModuleName().getText();
			int moduleAddress = program.size();
			FixupChain fixupChain;
			
			if(moduleAddresses.containsKey(moduleName)){
				fixupChain = (FixupChain)moduleAddresses.get(moduleName);
				final int fixupModuleAddress = fixupChain.address;

				if (fixupModuleAddress < -1) {
					fixupFuture((Instruction) program
							.get(-(fixupModuleAddress + 2)),
							moduleAddress);
				} 
				else if (fixupModuleAddress == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous module name declaration.");
			} else
				moduleAddresses.put(moduleName, new FixupChain(
						moduleAddress, moduleName));
		}
		
		public void inAModeDeclaration(AModeDeclaration node){
			modeName = node.getModeName().getText();
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			modeName = "";
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			taskName = "";
		}
		
		public void inAActualPorts(AActualPorts node){
    		if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAActualInputList=true;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAActualInputList=false;
    		}
    	}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!inAActualInputList){
				ATaskDeclaration taskDecl = (ATaskDeclaration)moduleSymbolTable.tasks.get(taskName);
				
				if(taskDecl.getTaskFunction()!=null){
					String name = node.getPortName().getText();
			    	String initDriver = ((APortDeclaration)moduleSymbolTable.ports.get(name)).getInitDriver().getText();
			    	
			    	// init driver for each communicator
					final int driverIndex = functionTable.getInitPortDriverIndex(currentProgramName, currentModuleName, modeName, taskName, name, initDriver);
		
					program.add(new Instruction(callCode, driverIndex,
							"Call initialization driver: "
							+ functionTable.getInitPortDriverWrapperName(currentProgramName, currentModuleName, modeName, taskName, name, initDriver)));
				}
			}
		}
		
		public void inATaskDeclaration(ATaskDeclaration node){
			taskName = node.getTaskName().getText();
		}
		
		public void inAStatePort(AStatePort node){
			String name = node.getStateName().getText();
	    	String initDriver = node.getInitDriver().getText();
	    	//String type = node.getTypeName().getText();
	    	
	    	// init driver for each communicator
			final int driverIndex = functionTable.getInitStateDriverIndex(currentProgramName, currentModuleName, taskName, name, "state", initDriver);

			program.add(new Instruction(callCode, driverIndex,
					"Call initialization state driver: "
					+ functionTable.getInitStateDriverWrapperName(currentProgramName, currentModuleName, taskName, name, "state", initDriver)));
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			//generate jump to start mode
			String startMode = node.getStartMode().getText();
			String unitStartMode = startMode + Integer.toString(0);
			int fixupAddress = -(program.size()+2);
			FixupChain fixupChain = new FixupChain(fixupAddress, 0, startMode);
			
			modeAddresses.put(unitStartMode, fixupChain);
			
			program.add(new Instruction(jumpCode, -1,
					"Triggered jump to unit 0 of start mode "+startMode+" of module " + currentModuleName ));
		}
	}
	
	private class GenModeECode extends DepthFirstAdapter{
		public void outAModeDeclaration(AModeDeclaration node){
			generateModeOtherUnitECode(node);
		}
		
		private void fixupModeUnitAddress(AModeDeclaration node, int unit){
			String modeName = node.getModeName().getText();
			String unitModeName = modeName+Integer.toString(unit);
			String futureUnitMode = modeName+"future"+Integer.toString(unit);
			int unitModeAddress = program.size();
			FixupChain fixupChain;
			
			if(modeAddresses.containsKey(unitModeName)){
				fixupChain = (FixupChain)modeAddresses.get(unitModeName);
				final int fixupModeAddress = fixupChain.address;

				if (fixupModeAddress < -1) {
					fixupJump((Instruction) program
							.get(-(fixupModeAddress + 2)),
							unitModeAddress);
				} else if (fixupModeAddress == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous program name declaration.");
			} else
				modeAddresses.put(unitModeName, new FixupChain(
						unitModeAddress, unit, modeName));
			
			if(modeAddresses.containsKey(futureUnitMode)){
				fixupChain = (FixupChain)modeAddresses.get(futureUnitMode);
				final int fixupModeAddress = fixupChain.address;

				if (fixupModeAddress < -1) {
					fixupFuture((Instruction) program
							.get(-(fixupModeAddress + 2)),
							unitModeAddress);
				} else if (fixupModeAddress == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous program name declaration.");
			} else{
				modeAddresses.put(futureUnitMode, new FixupChain(
						unitModeAddress, unit, modeName));
			}
		}
				
		private void generateModeOtherUnitECode(AModeDeclaration node){
			for(int u=0; u<currentModeUnit.nUnits; u++){
				fixupModeUnitAddress(node, u);
				//generate commUpdate ECode
				//generate call sensor device drivers
				node.apply(new GenCommunicatorUpdate(u));
				
				if(u==0){
					//future 0 to mode switch
					program.add(new Instruction(futureCode, giottoTriggerIndex,
							program.size()+2, 0,0,0,
							"Triggered jump to mode switch tests: " + currentModeName ));
				}
				else{
					//future 0 action code
					program.add(new Instruction(futureCode, giottoTriggerIndex,
							program.size()+2, 0,0,0,
							"Triggered jump to mode action address: " + currentModeName ));
				}
				
				//generate return
				program.add(new Instruction(returnCode, "Return from mode "+currentModeName+", unit" + u + "."));
				
				if(u==0){
					//generate mode switch test ECode
					node.apply(new GenModeSwitchTests(u));
				}
				
				//generate update comm read by non-prec tasks
				//generate call actuator device drivers
				String actionAdd = currentModeName + u + "action";
				FixupChain chain;
				int add = program.size();
				
				if(modeAddresses.containsKey(actionAdd)){
					chain = (FixupChain)modeAddresses.get(actionAdd);
					
					if(chain.address <-1){
						Instruction inst = (Instruction)program.get(-(chain.address+2));
						chain.address = add;
						
						fixupIf(inst, add);
					}
					else{
						throw new RuntimeException("Ambiguous program name declaration.");
					}
				}
				else{
					chain = new FixupChain(add, u, currentModeName);
					modeAddresses.put(actionAdd, chain);
				}
				
				if(isModuleOnHost){
					node.apply(new GenCommunicatorRead(u));
					
					//release non-prec tasks
					node.apply(new GenNonPrecedenceTaskECode(u));
				}
				
				if(u==0 && isModuleOnHost){
					//generate delay future to update comm read by prec tasks
					node.apply(new GenReadSetPrecedenceTaskTriggers(u));
					//generate delay future to release prec tasks
					node.apply(new GenPrecedenceTaskTriggers(u));
				}
				
				//generate future to next unit
				int nextUnit = (u+1)%currentModeUnit.nUnits;
				String nextUnitName = currentModeName + "future" + Integer.toString(nextUnit);
				int nextUnitAddress=-1;
				if(modeAddresses.containsKey(nextUnitName)){
					chain=(FixupChain)modeAddresses.get(nextUnitName);
					nextUnitAddress = chain.address;
					if(chain.address<-1){
						chain.address = -(program.size()+2);
					}
				}
				else{
					chain = new FixupChain(-(program.size()+2), nextUnit, currentModeName);
					modeAddresses.put(nextUnitName, chain);
				}
				program.add(new Instruction(futureCode, giottoTriggerIndex,
						nextUnitAddress, currentModeUnit.smalestPeriod,0,0,
						"Triggered jump to next mode unit address: " + currentModeName +", "+nextUnit));
				
				//return from action unit
				program.add(new Instruction(returnCode, "Return from mode action: "+currentModeName+", " + u + "."));
				
				if(u==0){
					//generate ECode to update comm read by prec tasks
					node.apply(new GenReadSetPrecedenceTaskECode(u));
				
					//generate ECode to release prec tasks
					node.apply(new GenPrecedenceTaskECode(u));
				}
			}
		}
	}
	
	private abstract class GenModeElementECode extends DepthFirstAdapter{
		protected int unit;
		
		public GenModeElementECode(int unit){
			this.unit = unit;
		}
		
	}
	
	private class GenCommunicatorUpdate extends GenModeElementECode{
		
		private String task;
		private boolean inAOutputList=false;
		private int outPos=0;
		
		public GenCommunicatorUpdate(int unit){
			super(unit);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			task = node.getTaskName().getText();
			outPos = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			task = null;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void inAConcreteActualPort(AConcreteActualPort node){
			if(inAOutputList)
				outPos++;
		}
		
		public void inACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(task)))
				return;
			if(inAOutputList){
				String name = node.getCommunicatorPortName().getText();
				int commPeriod = getCommunicatorPeriod(name);
				int commInstance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
				if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
					String type = getCommunicatorType(name);
				
					//generate code to update written communicators
					int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
							currentModeName, task, name, outPos, type, "output");
					String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
							currentModeName, task, name, outPos, type, "output");
					
					program.add(new Instruction(callCode, driverIndex,
							"Call copy driver: "
							+ driverName));					
				}
				
				outPos++;
			}
		}
		
		public void inASensorDeviceDriver(ASensorDeviceDriver node){
			
			String name = node.getCommunicatorName().getText();
			int commPeriod = getCommunicatorPeriod(name);
			int commInstance = Integer.parseInt(node.getCommunicatorInstance().getText());
			if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
				int driverIndex = functionTable.getDeviceDriverIndex(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				String driverName = functionTable.getDeviceDriverWrapperName(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				program.add(new Instruction(callCode, driverIndex,
						"Call device driver: "
						+ driverName));
			}
		}
	}
	
	private class GenCommunicatorRead extends GenModeElementECode{
		private String task;
		private boolean inAOutputList=false;
		private int inPos=0;
		
		public GenCommunicatorRead(int unit){
			super(unit);
		}
						
		public void inATaskInvocation(ATaskInvocation node){
			task = node.getTaskName().getText();
			inPos = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			task = null;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void inAConcretActualPort(AConcreteActualPort node){
			if(!inAOutputList)
				inPos++;
		}
		
		public void inACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(task)))
				return;
			if(!precedenceSets.precedenceTasks.containsKey(task)){
				if(!inAOutputList){
					String name = node.getCommunicatorPortName().getText();
					int commPeriod = getCommunicatorPeriod(name);
					int commInstance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
					if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
						String type = getCommunicatorType(name);
						
						//generate code to update written communicators
						int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
								currentModeName, task, name, inPos, type, "input");
						String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
								currentModeName, task, name, inPos, type, "input");
						
						program.add(new Instruction(callCode, driverIndex,
								"Call copy driver: "
								+ driverName));
					}
					inPos++;
				}
			}
		}
		
		public void inAActuatorDeviceDriver(AActuatorDeviceDriver node){
			String name = node.getCommunicatorName().getText();
			int commPeriod = getCommunicatorPeriod(name);
			int commInstance = Integer.parseInt(node.getCommunicatorInstance().getText());
			if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
				int driverIndex = functionTable.getDeviceDriverIndex(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				String driverName = functionTable.getDeviceDriverWrapperName(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				program.add(new Instruction(callCode, driverIndex,
						"Call device driver: "
						+ driverName));
			}
		}
		
	}
	
	private class GenModeSwitchTests extends GenModeElementECode{
		
		public GenModeSwitchTests(int unit){
			super(unit);
		}
		
		public void inAModeSwitch(AModeSwitch node){
			String destMode = node.getDestinationMode().getText();
			String condName = node.getConditionFunction().getText();
			
			int conditionIndex = functionTable.getConditionIndex(currentProgramName, currentModuleName,
					currentModeName, destMode, condName);
			String condWrapperName =  functionTable.getConditionWrapperName(currentProgramName, currentModuleName,
					currentModeName, destMode, condName);
			
			String destActionAdd = destMode + unit + "action";
			FixupChain chain;
			int destAddress =  -1;
			
			if(modeAddresses.containsKey(destActionAdd)){
				chain = (FixupChain)modeAddresses.get(destActionAdd);
				destAddress = chain.address;
				
				if(chain.address<-1){
					chain.address = -(program.size()+2);
				}
				
			}
			else{
				chain = new FixupChain(-(program.size()+2), unit, currentModeName);
				modeAddresses.put(destActionAdd, chain);
			}
			
			program.add(new Instruction(ifCode, conditionIndex,
					destAddress, program.size()+1, "If switch condition: "
							+ condWrapperName));
			
		}
	}
	
	private class GenNonPrecedenceTaskECode extends GenModeElementECode{
		
		public GenNonPrecedenceTaskECode(int unit){
			super(unit);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
					
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(!precedenceSets.precedenceTasks.containsKey(taskName)){
				ComputeHigherReadCommInstance higherInstance = new ComputeHigherReadCommInstance();
				node.apply(higherInstance);
				
				if(isEnabled(currentModeUnit.smalestPeriod, unit, higherInstance.higherOffset)){
					final int taskIndex = functionTable.getTaskIndex(currentProgramName, currentModuleName, taskName);
					
					program.add(new Instruction(releaseCode, taskIndex, 0,
							0 , "Release task: "
									+ functionTable
											.getTaskWrapperName(currentProgramName, currentModuleName, taskName)));
				}
			}
			
		}
	}
	
	public class GenReadSetPrecedenceTaskTriggers extends GenModeElementECode{
		
		private String taskName;
		private boolean inAOutputList;
		private int inPosition;
		
		public GenReadSetPrecedenceTaskTriggers(int unit){
			super(unit);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
			inPosition = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			taskName = "";
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!inAOutputList){
				inPosition++;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName) && !inAOutputList){
				String commName = node.getCommunicatorPortName().getText();
				int period = getCommunicatorPeriod(commName);
				int instance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
				
				String keyAddress=currentModeName+taskName+inPosition; 
				
				FixupChain fixupChain = new FixupChain(-(program.size()+2), unit, currentModeName);
				
				modeAddresses.put(keyAddress, fixupChain);
				
				program.add(new Instruction(futureCode, giottoTriggerIndex,
						-1, period*instance,0,0,
						"Triggered jump to E Code that will update the communicator '" + commName +"' read by task '"+taskName+"'"));
			}
			
			if(!inAOutputList){
				inPosition++;
			}
		}
	}
	
	private class GenReadSetPrecedenceTaskECode extends GenModeElementECode{
		
		private String taskName;
		private boolean inAOutputList;
		private int inPosition;
		
		public GenReadSetPrecedenceTaskECode(int unit){
			super(unit);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
			inPosition = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			taskName = "";
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!inAOutputList){
				inPosition++;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName) && !inAOutputList && isModuleOnHost){
				String commName = node.getCommunicatorPortName().getText();
				String keyAddress=currentModeName+taskName+inPosition; 
				
				FixupChain fixupChain = (FixupChain)modeAddresses.get(keyAddress);
				int adr = fixupChain.address;
				int realAdr = program.size();
				
				if (adr < -1) {
					fixupFuture((Instruction) program
							.get(-(adr + 2)),
							realAdr);
				} 
				else if (adr == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous module name declaration.");
				
				program.add(new Instruction(futureCode, giottoTriggerIndex,
						realAdr+2, 0,0,0,
						"Triggered jump to real E Code that will update the communicator '" + commName +"' read by task '"+taskName+"'"));
				program.add(new Instruction(returnCode, "Retrun from delay comm update: "+commName));
				//generate code to read communicators
				String type = getCommunicatorType(commName);
				int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
						currentModeName, taskName, commName, inPosition, type, "input");
				String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
						currentModeName, taskName, commName, inPosition, type, "input");
				
				program.add(new Instruction(callCode, driverIndex,
						"Call copy driver: "
						+ driverName));
				program.add(new Instruction(returnCode, "Retrun from real comm update: "+commName));
			}
			
			if(!inAOutputList){
				inPosition++;
			}
		}
	}
	
	public class GenPrecedenceTaskTriggers extends GenModeElementECode{
		
		public GenPrecedenceTaskTriggers(int unit){
			super(unit);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName)){
				ComputeHigherReadCommInstance higherInstance=new ComputeHigherReadCommInstance();
				node.apply(higherInstance);
				
				String keyAddress=currentModeName+taskName; 
				
				FixupChain fixupChain = new FixupChain(-(program.size()+2), unit, currentModeName);
				
				modeAddresses.put(keyAddress, fixupChain);
				
				long depList=0;
				
				ArrayList taskDeps=(ArrayList)((Map)dependencyTable.taskDependencies.get(currentProgramName+"."+currentModuleName+"."+currentModeName)).get(taskName);
				
				Iterator depIt = taskDeps.iterator();
				while(depIt.hasNext()){
					ATaskInvocation dep = (ATaskInvocation)depIt.next();
					int idx = functionTable.getTaskIndex(currentProgramName, currentModuleName, dep.getTaskName().getText());
					depList = depList | (0x01 << idx);
				}
				
				program.add(new Instruction(futureCode, giottoTriggerIndex,
						-1, higherInstance.higherOffset,(int)(depList & 0xFFFFFFFFl),(int)((depList >> 32) & 0xFFFFFFFFl),
						"Triggered jump to E Code that will release task '"+taskName+"'"));
			}
		}
	}
	
	private class GenCopyTaskOutputPorts extends DepthFirstAdapter{
		private String taskName;
		private int inPosition;
		private boolean inAOutputList;
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
			inPosition = 0;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(!inAOutputList){
				String portName = node.getPortName().getText();
				String type = ((APortDeclaration)moduleSymbolTable.ports.get(portName)).getPortType().getText();
				int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
						currentModeName, taskName, portName, inPosition, type, "input");
				String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
						currentModeName, taskName, portName, inPosition, type, "input");
				
				program.add(new Instruction(callCode, driverIndex,
						"Call copy driver: "
						+ driverName));
				inPosition++;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(!inAOutputList){
				inPosition++;
			}
		}
	}
	
	private class GenPrecedenceTaskECode extends GenModeElementECode{
		
		public GenPrecedenceTaskECode(int unit){
			super(unit);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName) && isModuleOnHost){
				ComputeHigherReadCommInstance higherInstance=new ComputeHigherReadCommInstance();
				node.apply(higherInstance);
				
				String keyAddress=currentModeName+taskName; 
				
				FixupChain fixupChain = (FixupChain)modeAddresses.get(keyAddress);
				int adr = fixupChain.address;
				int realAdr = program.size();
				
				if (adr < -1) {
					fixupFuture((Instruction) program
							.get(-(adr + 2)),
							realAdr);
				} 
				else if (adr == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous module name declaration.");
								
				program.add(new Instruction(futureCode, giottoTriggerIndex,
						realAdr+2, 0,0,0,
						"Triggered jump to E Code that will release task '"+taskName+"'"));
				
				program.add(new Instruction(returnCode, "Retrun from task release: "+taskName));
				
				//copy ports
				node.apply(new GenCopyTaskOutputPorts());
				
				final int taskIndex = functionTable.getTaskIndex(currentProgramName, currentModuleName, taskName);
					
				program.add(new Instruction(releaseCode, taskIndex, 0,
						0 , "Release task: "
								+ functionTable
									.getTaskWrapperName(currentProgramName, currentModuleName, taskName)));
				
				program.add(new Instruction(returnCode, "Retrun from real task release: "+taskName));
				
			}
		}
	}
	
	private class GenECode extends DepthFirstAdapter {
	
	    public void inAProgramDeclarationList(AProgramDeclarationList node){
	    	programAddresses = new Hashtable();
	    }
	    
	    public void outAProgramDeclarationList(AProgramDeclarationList node){
	    	programAddresses = null;
	    } 
	    
	    public void inAProgramDeclaration(AProgramDeclaration node){
	    	currentProgramName = node.getProgramName().getText();
	    	programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(currentProgramName);
	    
	    	moduleAddresses = new Hashtable();
	    	    	
	    	node.apply(new GenProgramECode());
	    }
	    
	    public void outAProgramDeclaration(AProgramDeclaration node){
	    	currentProgramName = null;
	    	moduleAddresses = null;
	    }

	    public void inAModuleDeclaration(AModuleDeclaration node){
	    	currentModuleName = node.getModuleName().getText();
	    	moduleSymbolTable = (ModuleSymbolTable)programSymbolTable.modules.get(currentModuleName);
	    	modeAddresses = new Hashtable();
	    	
	    	AModuleDeclaration rootModule = inheritTable.getRootModule(currentProgramName, currentModuleName);
	    	if(rootModule.getHostDeclaration()!=null){
	    		isModuleOnHost = ((AHostDeclaration)rootModule.getHostDeclaration())
	    				.getHostName().getText().equals(hostTable.currentHost);
	    	}
	    	else{
	    		isModuleOnHost = true;
	    	}
	    	
	    	if(pureGiotto){
	    		isModuleOnHost = true;
	    	}
	    	
	    	node.apply(new GenModuleECode());
	    }
	    
	    public void outAModuleDeclaration(AModuleDeclaration node){
	    	currentModuleName = null;
	    	modeAddresses = null;
	    }
	    
	    public void inAModeDeclaration(AModeDeclaration node){
	    	currentModeName = node.getModeName().getText();
	    	precedenceSets = new ComputePrecedenceSets();
	    	node.apply(precedenceSets);
	    	
	    	currentModeUnit = (ModeUnit)modeUnits.get(currentProgramName + "."+currentModuleName+"."+currentModeName);	    	
	    	
	    	node.apply(new GenModeECode());
	    }
	    
	    public void outAModeDeclaration(AModeDeclaration node){
	    	currentModeName = null;
	    	currentModeUnit = null;
	    	precedenceSets = null;
	    }
	}

	// Misc code

	private class FixupChain {
		private int address = 0;

		private int unit = 0;

		private String name = null;
		
		public FixupChain(int address, String name){
			this.address = address;
			this.name = name;

		}

		public FixupChain(int address, int unit, String name) {
			this.address = address;
			this.unit = unit;
			this.name = name;
		}
	}

	private class Instruction {
		int opcode = 0;

		int arg1 = -1;

		int arg2 = -1;

		int arg3 = -1;
		
		int arg4 = -1;
		
		int arg5 = -1;

		String comment = "";

		public Instruction(int opcode) {
			this.opcode = opcode;
		}

		public Instruction(int opcode, String comment) {
			this.opcode = opcode;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1) {
			this.opcode = opcode;
			this.arg1 = arg1;
		}

		public Instruction(int opcode, int arg1, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1, int arg2, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1, int arg2, int arg3) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
		}

		public Instruction(int opcode, int arg1, int arg2, int arg3,
				String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;

			this.comment = comment;
		}
		
		public Instruction(int opcode, int arg1, int arg2, int arg3, int arg4,
				String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
			this.arg4 = arg4;

			this.comment = comment;
		}
		
		public Instruction(int opcode, int arg1, int arg2, int arg3, int arg4, int arg5, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
			this.arg4 = arg4;
			this.arg5 = arg5;

			this.comment = comment;
		}

		public void emitCode(int address) {
			switch (opcode) {
			case nopCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("NOP");
				break;
			case futureCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("FUTURE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),Integer.toString(arg4),Integer.toString(arg5),
								comment });
				break;
			case callCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("CALL", new String[] { Integer.toString(arg1), comment });
				break;
			case releaseCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RELEASE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),
								comment });
				break;
			case ifCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("IF",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),
								comment });
				break;
			case jumpCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("JUMP", new String[] { Integer.toString(arg1), comment });
				break;
			case returnCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RETURN", new String[] { comment });
				break;
			}
		}
	}
}
