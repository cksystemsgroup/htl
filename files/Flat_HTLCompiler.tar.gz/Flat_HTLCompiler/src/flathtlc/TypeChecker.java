/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package flathtlc;

import flathtlc.InheritTable;
import flathtlc.ModuleSymbolTable;
import flathtlc.ProgramSymbolTable;
import flathtlc.ScopedSymbolTable;
import flathtlc.StringCast;
import flathtlc.StringComparator;
import flathtlc.SymbolTable;
import flathtlc.TypedTreeMap;
import flathtlc.TypedTreeMapCast;
import flathtlc.Utils;
import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.AActualPorts;
import flathtlc.node.AActuatorDeviceDriver;
import flathtlc.node.ACommunicatorDeclaration;
import flathtlc.node.ACommunicatorInstance;
import flathtlc.node.AConcreteActualPort;
import flathtlc.node.AFormalPort;
import flathtlc.node.AModeDeclaration;
import flathtlc.node.AModeSwitch;
import flathtlc.node.AModuleDeclaration;
import flathtlc.node.AParentTask;
import flathtlc.node.APortDeclaration;
import flathtlc.node.AProgramDeclaration;
import flathtlc.node.AProgramDeclarationList;
import flathtlc.node.ARefineProgram;
import flathtlc.node.ASensorDeviceDriver;
import flathtlc.node.ASwitchPort;
import flathtlc.node.ATaskDeclaration;
import flathtlc.node.ATaskInvocation;
import flathtlc.node.Node;
import flathtlc.node.NodeCast;
import flathtlc.node.TIdent;
import flathtlc.node.Token;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;


/**
 * 
 * This class implements type checking.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 *         Daniel Iercam, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class TypeChecker extends DepthFirstAdapter {
	private SymbolTable symbolTable;

	private InheritTable inheritTable;

	private boolean inATaskInvocation = false;

	private HashSet taskInvocations = null;

	private Map portUpdates = null;

	private HashSet modeSwitches = null;
	
	private Map moduleWriteSet = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, TypedTreeMapCast.instance);

	private boolean inAActualOutputList = false;

	private ProgramSymbolTable programSymbolTable;

	private ModuleSymbolTable moduleSymbolTable;
	
	private Map writeSet;

	private String moduleName;

	private String programName;
	
	private String taskName;
	
	private TypedTreeMap modeTaskParents;

	public TypeChecker(SymbolTable symbolTable, InheritTable inheritTable) {
		this.symbolTable = symbolTable;
		this.inheritTable = inheritTable;
	}

	// Action code

	public void inAProgramDeclarationList(AProgramDeclarationList node) {
		// test that a communicator is not declar by a program and a sud-program
		// of the program
		testCommunicatorDeclaration(new HashSet(), inheritTable
				.getRootProgramName());
	}

	private void testCommunicatorDeclaration(HashSet commSet, String programName) {
		// add all the communicators defined in program to the communicators set
		ProgramSymbolTable pst = (ProgramSymbolTable) symbolTable.programs
				.get(programName);

		Iterator commIt = pst.communicators.entrySet().iterator();
		while (commIt.hasNext()) {
			Map.Entry entry = (Map.Entry) commIt.next();

			if (!commSet.add(entry.getKey())) {
				// communicator is redeclared
				errorCommunicator(entry.getValue());
			}
		}

		// perform the test for each sub-program
		if (inheritTable.programSubPrograms.containsKey(programName)) {
			Iterator subIt = ((ArrayList) inheritTable.programSubPrograms
					.get(programName)).iterator();
			while (subIt.hasNext()) {
				String prog = (String) subIt.next();
				testCommunicatorDeclaration((HashSet) commSet.clone(), prog);
			}
		}
	}

	public void outAProgramDeclarationList(AProgramDeclarationList node) {
		inheritTable.getRoorProgramDeclaration().apply(new CheckCommWriteSet());
	}
	
	private class CheckCommWriteSet extends DepthFirstAdapter{
		private TypedTreeMap writeSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		private TypedTreeMap moduleWriteSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		private TypedTreeMap modeWriteSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		
		private ProgramSymbolTable programSymbolTable;
		private ModuleSymbolTable moduleSymbolTable;
		
		private ATaskInvocation taskInvoc;
		private boolean isAbstract;
		private boolean inAnOutputList;
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(node.getProgramName().getText());
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			moduleWriteSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
			moduleSymbolTable = (ModuleSymbolTable) programSymbolTable.modules.get(node.getModuleName().getText());
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			
			putAll(moduleWriteSet, writeSet);
		}
		
		//put all entries from source to destination
		//and check for unicity
		private void putAll(Map source, Map destination){
			Iterator it=source.entrySet().iterator();
			
			while(it.hasNext()){
				Entry entry =  (Entry)it.next();
				String commName = (String)entry.getKey();
				
				TIdent oldValue;
				if((oldValue = (TIdent)destination.put(commName, entry.getValue())) != null){
					errorWriteCommunicator(commName, oldValue, (TIdent)entry.getValue());
				}
			}
		}
		
		public void inAModeDeclaration(AModeDeclaration node){
			modeWriteSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance); 
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			if(node.getRefineProgram()!=null){
				CheckCommWriteSet commWriteSet = new CheckCommWriteSet();
				AProgramDeclaration refProg = ((ProgramSymbolTable)symbolTable.programs.get(((ARefineProgram)node.getRefineProgram()).getProgramName().getText())).program;
				refProg.apply(commWriteSet);
				putAll(commWriteSet.modeWriteSet, modeWriteSet);
			}
			
			//update module write set
			moduleWriteSet.putAll(modeWriteSet);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskInvoc = node;
			isAbstract = ((ATaskDeclaration)moduleSymbolTable.tasks.get(node.getTaskName().getText())).getTaskFunction() == null;
		}
		
		public void inAModeSwitch(AModeSwitch node){
			taskInvoc = null;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(taskInvoc!=null)
				inAnOutputList = node == taskInvoc.getOutputActualPorts();
			else{
				inAnOutputList = false;
				isAbstract = false;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(inAnOutputList && !isAbstract){
				modeWriteSet.put(node.getCommunicatorPortName().getText()+", "+
						node.getCommunicatorInstanceNumber().getText(), taskInvoc.getTaskName());
			}
		}
	}
		
	public void inAProgramDeclaration(AProgramDeclaration node) {
		programName = node.getProgramName().getText();
		programSymbolTable = (ProgramSymbolTable) symbolTable.programs
				.get(programName);
	}

	public void outAProgramDeclaration(AProgramDeclaration node) {
		programSymbolTable = null;
		programName = "";
	}

	public void inAModuleDeclaration(AModuleDeclaration node) {
		moduleName = node.getModuleName().getText();
		moduleSymbolTable = (ModuleSymbolTable) programSymbolTable.modules
				.get(moduleName);
		writeSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
	}

	public void outAModuleDeclaration(AModuleDeclaration node) {
		// test to see if the start mode exists
		TIdent startModeIdent = node.getStartMode();
		if (!moduleSymbolTable.modes.containsKey(startModeIdent.getText())) {
			errorMessage(startModeIdent, startModeIdent.getText(),
					"mode in moule " + moduleName);
		}

		String key = moduleName;
		if(inheritTable.moduleParents.containsKey(moduleName)){
			key = (String)inheritTable.moduleParents.get(moduleName);
		}
		
		if(moduleWriteSet.containsKey(key)){
			TypedTreeMap parentWriteSet = (TypedTreeMap)moduleWriteSet.get(key);
			parentWriteSet.putAll(writeSet);
		}
		else{		
			moduleWriteSet.put(moduleName, writeSet);
		}
		
		moduleSymbolTable = null;
		moduleName = "";
		writeSet = null;
	}
	
	public void inATaskDeclaration(ATaskDeclaration node) {
		node.apply(new ScopedSymbolTable(symbolTable));
	}

	public void outATaskDeclaration(ATaskDeclaration node) {
	}

	public void inAModeDeclaration(AModeDeclaration node) {
		taskInvocations = new HashSet();
		portUpdates = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		modeSwitches = new HashSet();
		modeTaskParents = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
	}

	public void outAModeDeclaration(AModeDeclaration node) {
		taskInvocations = null;
		portUpdates = null;
		modeSwitches = null;
		
		programSymbolTable.program.apply(new TestSiblingParentTask());
	}

	private class TestSiblingParentTask extends DepthFirstAdapter{
		private String crrModuleName;
		
		public TestSiblingParentTask(){
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			crrModuleName = node.getModuleName().getText();
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			if(!crrModuleName.equals(moduleName)){
				if(node.getParentTask()!=null){
					String parentTaskName = ((AParentTask)node.getParentTask()).getTaskName().getText();
					if(modeTaskParents.containsKey(parentTaskName)){
						errorSiblingParentTask((TIdent)modeTaskParents.get(parentTaskName));
					}
				}
			}
		}
	}
	
	public void outARefineProgram(ARefineProgram node) {
		String name = node.getProgramName().getText();

		// test for refinement program definition
		if (!symbolTable.programs.containsKey(name)) {
			errorMessage(node.getProgramName(), name, "program");
		}
	}
	
	private boolean isRootProgram(){
		return inheritTable.getRootProgramName().equals(programName);
	}
	
	public void inATaskInvocation(ATaskInvocation node) {
		String name = node.getTaskName().getText();

		taskName = name;
		
		// test task declaration
		if (!moduleSymbolTable.tasks.containsKey(name)) {
			errorMessage(node.getTaskName(), name, "task in module "
					+ moduleName);
		}

		// test that a task is invoke only once in a mode
		if (!taskInvocations.add(name)) {
			errorTaskInvocation(node.getTaskName(), ((AModeDeclaration)node.parent().parent()).getModeName());
		}
		
		if(!isRootProgram() && node.getParentTask()==null){
			errorSubProgram(node.getTaskName());
		}
		else{
			if(node.getParentTask()!=null && modeTaskParents.put(((AParentTask)node.getParentTask()).getTaskName().getText(),
					((AParentTask)node.getParentTask()).getTaskName()) != null){
				errorParentTaskRedeclared(((AParentTask)node.getParentTask()).getTaskName());
			}
		}
		
		if(isRootProgram() && node.getParentTask()!=null){
			errorParentRoot(node.getTaskName());
		}
		
		inATaskInvocation = true;
	}

	class ActualParametersTable extends DepthFirstAdapter {
		public ArrayList inputParamters = new ArrayList();

		public ArrayList outputParamters = new ArrayList();

		private boolean inOutputList = false;

		public void inAActualPorts(AActualPorts node) {
			if (((ATaskInvocation) node.parent()).getOutputActualPorts() == node) {
				inOutputList = true;
			}
		}

		public void outAActualPorts(AActualPorts node) {
			inOutputList = false;
		}

		public void outAConcreteActualPort(AConcreteActualPort node) {
			if (inOutputList)
				outputParamters.add(node);
			else {
				inputParamters.add(node);
			}
		}

		public void outACommunicatorInstance(ACommunicatorInstance node) {
			if (inOutputList)
				outputParamters.add(node);
			else {
				inputParamters.add(node);
			}
		}
	}

	public void outATaskInvocation(ATaskInvocation node) {
		inATaskInvocation = false;

		taskName = null;
		
		ScopedSymbolTable scopedSymbolTable = new ScopedSymbolTable(symbolTable);
		((ATaskDeclaration) moduleSymbolTable.tasks.get(node.getTaskName()
				.getText())).apply(scopedSymbolTable);

		ActualParametersTable actualParametersTable = new ActualParametersTable();
		node.apply(actualParametersTable);

		// test input actual parameters
		testActualParamters(node.getTaskName(),
				actualParametersTable.inputParamters,
				scopedSymbolTable.inputFormalPorts, scopedSymbolTable, "input");

		// test output actual parameters
		testActualParamters(node.getTaskName(),
				actualParametersTable.outputParamters,
				scopedSymbolTable.outputFormalPorts, scopedSymbolTable,
				"output");
	}
	
	/**
	 * 
	 * @param name
	 * @return communicator type
	 */
	private String getCommunicatorType(String name){
		String type="";
		
		String program = programName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				type = ((ACommunicatorDeclaration) pSymbolTable.communicators
						.get(name)).getTypeName().getText();
				break;
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return type;
	}
	
	/**
	 * 
	 * @param name
	 * @return communicator type
	 */
	private boolean isCommunicator(String name){
		boolean res=false;
		
		String program = programName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				res=true;
				break;
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return res;
	}

	private void testActualParamters(TIdent task, ArrayList actualPorts,
			ArrayList formalPorts, ScopedSymbolTable scopedSymboltable,
			String message) {
		if (actualPorts.size() != formalPorts.size()) {
			errorActualListLength(task, message);
		}

		// check types
		for (int i = 0; i < actualPorts.size(); i++) {
			String actualType = "";
			TIdent sourcePort = null;
			if (actualPorts.get(i) instanceof AConcreteActualPort) {
				// get type for the case Port is used
				actualType = ((APortDeclaration) moduleSymbolTable.ports
						.get(((AConcreteActualPort) actualPorts.get(i))
								.getPortName().getText())).getPortType()
						.getText();
				sourcePort = ((AConcreteActualPort) actualPorts.get(i))
						.getPortName();
			} else {
				// get type for the case communicator instance is used
				ACommunicatorInstance commInst = (ACommunicatorInstance) actualPorts
						.get(i);
				sourcePort = commInst.getCommunicatorPortName();
				String commName = commInst.getCommunicatorPortName().getText();
				actualType = getCommunicatorType(commName);
			}

			String formalType = ((AFormalPort) formalPorts.get(i)).getTypeName().getText();
			TIdent destinationPort = ((AFormalPort)formalPorts.get(i)).getPortName();

			if (actualType.compareTo(formalType) != 0) {
				// different types
				errorTaskInvokePortType(task, destinationPort, sourcePort);
			}
		}
	}

	public void outASensorDeviceDriver(ASensorDeviceDriver node){
		String name=node.getCommunicatorName().getText();
		String instance = node.getCommunicatorInstance().getText();
		
		if(!isCommunicator(name)){
			errorMessage(node.getCommunicatorName(), node.getCommunicatorName().getText(), "communicator");
		}
				
		// a communicator can be updated by only one task in the same mode
		TIdent oldValue;
		if ((oldValue = (TIdent)portUpdates.put(name+instance, node.getDriverName())) != null) {
			errorPortUpdate(node.getCommunicatorName(),
					node.getCommunicatorName().getText(), "communicator", oldValue, node.getDriverName());
		}
		
		writeSet.put(name, node.getCommunicatorName());
	}
	
	public void outAActuatorDeviceDriver(AActuatorDeviceDriver node){
		String name=node.getCommunicatorName().getText();
		
		if(!isCommunicator(name)){
			errorMessage(node.getCommunicatorName(), node.getCommunicatorName().getText(), "communicator");
		}
	}
	
	public void inAModeSwitch(AModeSwitch node) {
		String name = node.getDestinationMode().getText();

		// test mode declaration
		if (!moduleSymbolTable.modes.containsKey(name)) {
			errorMessage(node.getDestinationMode(), name, "mode in module "
					+ moduleName);
		}

		// test that a task is invoke only once in a mode
		if (!modeSwitches.add(name)) {
			errorModeSwitch(node.getDestinationMode());
		}
	}

	public void outAModeSwitch(AModeSwitch node) {
	}

	public void inAActualPorts(AActualPorts node) {
		if (inATaskInvocation) {
			if (((ATaskInvocation) node.parent()).getOutputActualPorts() == node) {
				inAActualOutputList = true;
			}
		}

	}

	public void outAActualPorts(AActualPorts node) {
		inAActualOutputList = false;
	}

	public void outAConcreteActualPort(AConcreteActualPort node) {
		String name = node.getPortName().getText();

		// test for port declaration
		if (!moduleSymbolTable.ports.containsKey(name)) {
			errorMessage(node.getPortName(), name, "port in module "
					+ moduleName);
		}

		if (inAActualOutputList) {
			// a port can be updated by only one task in the same mode
			TIdent oldValue;
			if ( (oldValue = (TIdent)portUpdates.put(name, ((ATaskInvocation)node.parent().parent().parent()).getTaskName()))!=null) {
				errorPortUpdate(node.getPortName(), name, "Port", oldValue, (TIdent)portUpdates.get(name));
			}
		}
	}
		
	public void outACommunicatorInstance(ACommunicatorInstance node) {
		String name = node.getCommunicatorPortName().getText();
		String instance = node.getCommunicatorInstanceNumber().getText();

		if (!isCommunicator(name)) {
			errorMessage(node.getCommunicatorPortName(), name,
			"communicator");
		}
		
		if (inAActualOutputList) {
			// write communicators		
			// a communicator can be updated by only one task in the same mode
			boolean isAbstract = Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName));
			TIdent oldValue;
			if (!isAbstract && (oldValue = (TIdent)portUpdates.put(name+instance, ((ATaskInvocation)node.parent().parent().parent().parent()).getTaskName()))!=null) {
				errorPortUpdate(node.getCommunicatorPortName(),
						node.getCommunicatorPortName().getText(), "communicator", oldValue, ((TIdent)portUpdates.get(name+instance)));
			}
			
			if(!isAbstract)
				writeSet.put(name, node.getCommunicatorPortName());
		}
	}
	
	public void outASwitchPort(ASwitchPort node){
		String name=node.getPortName().getText();
		
		boolean isComm = isCommunicator(name); 
		
		if(!moduleSymbolTable.ports.containsKey(name) && 
				!isComm){
			//switch port is not delcared as a port or as a communicator
			//that can be read
			errorSwitchPort(node.getPortName());
		}
	}

	public void outAParentTask(AParentTask node){
		String parentTaskName=node.getTaskName().getText();
		
		if(!inheritTable.programParents.containsKey(programName)){
			errorParentTask(node.getTaskName());
		}
		
		ProgramSymbolTable pSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(inheritTable.programParents.get(programName));
		ModuleSymbolTable mSymbolTable = (ModuleSymbolTable)pSymbolTable.modules.get(inheritTable.moduleParents.get(moduleName));
		
		if(!mSymbolTable.tasks.containsKey(parentTaskName)){
			//task does not exists in parent module
			errorParent(node.getTaskName());
		}
		
		ATaskDeclaration t = (ATaskDeclaration)mSymbolTable.tasks.get(parentTaskName);
		if(t.getTaskFunction()!=null){
			//task is not an abstract one
			errorParentAbstract(node.getTaskName());
		}
	}
	
	// Misc code

	private static void errorMessage(Token token, String name, String message) {
		throw new RuntimeException("[" + token.getLine() + "," + token.getPos()
				+ "] " + name + " is not declared as " + message + ".");
	}
	
	private static void errorParentTask(TIdent ident){
		throw new RuntimeException("["+ident.getLine()+","+ident.getPos()+" ]"+
				"You can not specify a parent for a task invoked in a program that has no parent.");
	}

	private static void errorTaskInvocation(Token token, TIdent modeName) {
		throw new RuntimeException("[" + token.getLine() + "," + token.getPos()
				+ "] " + "Task " + token.getText()
				+ " is invoked multiple times in the same mode "+"["+modeName.getLine()+", "+modeName.getPos()+
				"]"+modeName.getText()+".");
	}

	private static void errorPortUpdate(Token token, String portName, String message, TIdent task1, TIdent task2) {
		throw new RuntimeException("[" + token.getLine() + "," + token.getPos()
				+ "] " + message + " " + portName + " is updated by multiple tasks."+
				" ["+task1.getLine()+","+task1.getPos()+"]"+task1.getText()+ " and"+
				" ["+task2.getLine()+","+task2.getPos()+"]"+task2.getText());
	}

	private static void errorModeSwitch(Token token) {
		throw new RuntimeException("[" + token.getLine() + "," + token.getPos()
				+ "] " + "Mode switch to mode: " + token.getText()
				+ " is multiple times in the same mode.");
	}

	private static void errorActualListLength(Token taskToken, String message) {
		throw new RuntimeException("[" + taskToken.getLine() + ","
				+ taskToken.getPos() + "]" + " Number of " + message
				+ " ports mismatch at task invocation " + taskToken.getText());
	}

	private static void errorTaskInvokePortType(Token taskToken,
			Token destinationPortToken, Token sourcePortToken) {
		throw new RuntimeException("[" + taskToken.getLine() + ","
				+ taskToken.getPos() + "]" + " Type mismatch at task "
				+ taskToken.getText() + " invoke ;" + " Formal port "
				+ destinationPortToken.getText() + " ["
				+ destinationPortToken.getLine() + ","
				+ destinationPortToken.getPos() + "]" + ", actual port "
				+ sourcePortToken.getText() + " [" + sourcePortToken.getLine()
				+ "," + sourcePortToken.getPos() + "].");
	}

	private static void errorCommunicator(Object comm) {
		Token commToken = null;
		if (comm instanceof ACommunicatorDeclaration) {
			ACommunicatorDeclaration genComm = (ACommunicatorDeclaration) comm;
			commToken = genComm.getCommunicatorName();
		}
		throw new RuntimeException("[" + commToken.getLine() + ", "
				+ commToken.getPos() + "]" + " Communicator "
				+ commToken.getText()
				+ " is already declared in a super-program");
	}
	
	private static void errorWriteCommunicator(String comm, TIdent id1, TIdent id2) {
				
		throw new RuntimeException("Communicator "
				+ comm
				+ " is written by more then one module. "+
				"["+id1.getLine()+","+id1.getPos()+"]"+id1.getText()+ " and "+
				"["+id2.getLine()+","+id2.getPos()+"]"+id2.getText()
				);
	}
	
	private static void errorParent(TIdent task){
		throw new RuntimeException("[" + task.getLine() + ", "
				+ task.getPos() + "] Task "+task.getText()+
				" is not declared in the super-modules.");
	}
	
	private static void errorParentRoot(TIdent task){
		throw new RuntimeException("[" + task.getLine() + ", "
				+ task.getPos() + "] Task "+task.getText()+
				" can't have a parent task. It is in the root program.");
	}
	
	private static void errorSubProgram(TIdent task){
		throw new RuntimeException("[" + task.getLine() + ", "
				+ task.getPos() + "] Task "+task.getText()+
				" should have a parent task. It is in a sub-program.");
	}
	
	private static void errorParentAbstract(TIdent task){
		throw new RuntimeException("[" + task.getLine() + ", "
				+ task.getPos() + "] Task "+task.getText()+
				" is not an abstract task.");
	}
	
	private static void errorSwitchPort(TIdent port){
		throw new RuntimeException("[" + port.getLine() + ", "
				+ port.getPos() + "] Port "+port.getText()+
				" is not declared as a module port or as a communicator.");
	}
	
	private static void errorParentTaskRedeclared(TIdent parentTask){
		throw new RuntimeException("[" + parentTask.getLine() + ", "
				+ parentTask.getPos() + "] Task "+parentTask.getText()+
				" is declared as a parent task for more then one task invocation in the same mode.");
	}
	
	private static void errorSiblingParentTask(TIdent parentTask){
		throw new RuntimeException("[" + parentTask.getLine() + ", "
				+ parentTask.getPos() + "] Task "+parentTask.getText()+
				" is declared as a parent task in one of the sibling modules.");
	}
	
	public String toString() {
		return symbolTable.toString();
	}
}
