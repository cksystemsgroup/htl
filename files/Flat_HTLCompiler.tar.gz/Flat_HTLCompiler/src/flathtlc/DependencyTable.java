/*
 * Created on May 5, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */
package flathtlc;

import flathtlc.ArrayListCast;
import flathtlc.ModuleSymbolTable;
import flathtlc.ProgramSymbolTable;
import flathtlc.StringCast;
import flathtlc.StringComparator;
import flathtlc.SymbolTable;
import flathtlc.TypedTreeMap;
import flathtlc.TypedTreeMapCast;
import flathtlc.Utils;
import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.AActualPorts;
import flathtlc.node.AConcreteActualPort;
import flathtlc.node.AModeDeclaration;
import flathtlc.node.AModeSwitch;
import flathtlc.node.AModuleDeclaration;
import flathtlc.node.AProgramDeclaration;
import flathtlc.node.ASwitchPort;
import flathtlc.node.ATaskDeclaration;
import flathtlc.node.ATaskInvocation;
import flathtlc.node.Node;
import flathtlc.node.NodeCast;
import flathtlc.node.TIdent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;


/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at
 * 
 * This class represents a dependency table
 */
public class DependencyTable extends DepthFirstAdapter {

    public final Map taskDependencies = new TypedTreeMap(
            StringComparator.instance, StringCast.instance,
            TypedTreeMapCast.instance);

    private Map dependencies;
    
    private ArrayList dependencyList;

    private String programName;
    
    private String moduleName;
    
    private String modeName;
        
    private ModePortTable modePortTable;
        
    private boolean inAInputList;
    
    private SymbolTable symbolTable;
    
    private ProgramSymbolTable programSymbolTable;
    
    private ModuleSymbolTable moduleSymbolTable;
    
    private String taskName;
        
    private ATaskInvocation taskInvoke;
    
    private AModeSwitch modeSwitch;
    
	public DependencyTable(SymbolTable symbolTable) {
		this.symbolTable = symbolTable;
    }
	
    public void inAProgramDeclaration(AProgramDeclaration node) {
    	programName = node.getProgramName().getText();
    	programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(node.getProgramName().getText());
    }

    public void outAProgramDeclaration(AProgramDeclaration node) {      

    }

    public void inAModuleDeclaration(AModuleDeclaration node) {
    	moduleName = node.getModuleName().getText();
    	moduleSymbolTable = (ModuleSymbolTable)programSymbolTable.modules.get(moduleName);
    }

    public void outAModuleDeclaration(AModuleDeclaration node) {      

    }
	
    /**
     * This class contains information about what task reads each port 
     * in a mode and what task writes that port 
     * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
     *
     */
    class ModePortTable extends DepthFirstAdapter{
    	public final Map portWriters=new TypedTreeMap(StringComparator.instance, 
    			StringCast.instance, NodeCast.instance);
    	public final Map portReaders=new TypedTreeMap(StringComparator.instance, 
    			StringCast.instance, ArrayListCast.instance);
    	
    	private boolean inOutputList = false;
    	private ATaskInvocation taskInvoke;

    	public void inATaskInvocation(ATaskInvocation node){
			taskInvoke=node;
		}
    	
		public void inAActualPorts(AActualPorts node) {
			Node n = node.parent();
			if(n instanceof ATaskInvocation){
				if (((ATaskInvocation) n).getOutputActualPorts() == node) {
					inOutputList = true;
				}
				else{
					inOutputList = false;
				}
			}
		}

		public void outAActualPorts(AActualPorts node) {
			inOutputList = false;
		}
		
		public void inAConcreteActualPort(AConcreteActualPort node){
			String portName = node.getPortName().getText();
			
			if(inOutputList){
				portWriters.put(portName, taskInvoke);
			}
			else{
				ArrayList readerList;
				if(portReaders.containsKey(portName)){
					readerList = (ArrayList)portReaders.get(portName);
				}
				else{
					readerList = new ArrayList();
					portReaders.put(portName, readerList);
				}
				
				readerList.add(taskInvoke);
			}
		}
    }
    
    public void inAModeDeclaration(AModeDeclaration node) {
    	modeName = node.getModeName().getText();
    	dependencies=new TypedTreeMap( StringComparator.instance, 
    			StringCast.instance, ArrayListCast.instance);
    	
    	modePortTable=new ModePortTable();
    	node.apply(modePortTable);
    }
    
    public void outAModeDeclaration(AModeDeclaration node) {      
    	taskDependencies.put(programName+"."+moduleName+"."+modeName, dependencies);
    	node.apply(new TestClosedLoops(dependencies, node));
    	dependencies = null;
    }
    
    class TestClosedLoops extends DepthFirstAdapter{
    	private Map taskDep;
    	private AModeDeclaration mode;
    	
    	public TestClosedLoops(Map taskDep, AModeDeclaration mode){
    		this.taskDep = taskDep;
    		this.mode=mode;
    	}
    	
    	public void outATaskInvocation(ATaskInvocation node){
    		testDep(node.getTaskName().getText(), node, taskDep);
    	}
    	
    	/**
    	 * Test for closed loops
    	 * @param taskName
    	 * @param node
    	 * @param taskDepMap
    	 */
    	 private void testDep(String taskName, ATaskInvocation node, Map taskDepMap){
	    	String crrNodeName=node.getTaskName().getText();
	    	
	    	ArrayList depList = (ArrayList)taskDepMap.get(crrNodeName);
	    	Iterator depIt = depList.iterator();
	    	while(depIt.hasNext()){
	    		ATaskInvocation taskInvoke=(ATaskInvocation)depIt.next();
	    		String name=taskInvoke.getTaskName().getText();
	    		if(name.equals(taskName)){
	    			//error closed loop
	    			dependencyError(mode.getModeName());
	    		}
	    		testDep(taskName, taskInvoke, taskDepMap);
	    	}
    	 }
    }
    
    public void inATaskInvocation(ATaskInvocation node){
    	dependencyList = new ArrayList();
    	taskName = node.getTaskName().getText();
    	taskInvoke = node;
    }
    
    public void outATaskInvocation(ATaskInvocation node){
    	dependencies.put(node.getTaskName().getText(), dependencyList);
    	dependencyList=null;
    	taskInvoke = null;
    }   
    
    public void inAModeSwitch(AModeSwitch node){
    	dependencyList = new ArrayList();
    	modeSwitch = node;
    }
    
    public void outAModeSwitch(AModeSwitch node){
    	dependencies.put(node.getDestinationMode().getText(), dependencyList);
    	dependencyList=null;
    	modeSwitch = null;
    }
    
    public void inAActualPorts(AActualPorts node) {
    	Node n = node.parent();
		if(n instanceof ATaskInvocation){
			if (((ATaskInvocation) node.parent()).getOutputActualPorts() == node) {
				inAInputList = false;
			}
			else{
				inAInputList = true;
			}
		}
	}

	public void outAActualPorts(AActualPorts node) {
		inAInputList = false;
	}
	
	public void inASwitchPort(ASwitchPort node){
		String portName = node.getPortName().getText();
		
		if(moduleSymbolTable.ports.containsKey(portName)){
			ATaskInvocation depInvoke = (ATaskInvocation)modePortTable.portWriters.get(portName); 
			ATaskDeclaration depTask = (ATaskDeclaration)moduleSymbolTable.tasks.get(depInvoke.getTaskName().getText());
			
			if(Utils.isAbstract(depTask)){
				errorAbstractSwitchDep(modeSwitch, depInvoke, Utils.isAbstract(depTask)?"Abstract":"Concret");
			}
			
			if(modePortTable.portWriters.containsKey(portName))
				dependencyList.add(depInvoke);
		}
	}
	
	public void inAConcreteActualPort(AConcreteActualPort node){
		String portName = node.getPortName().getText();
		
		if(inAInputList){
			ATaskInvocation depInvoke = (ATaskInvocation)modePortTable.portWriters.get(portName);
			if(depInvoke == null){
				errorPortNotWritten(node.getPortName());
				return;
			}
			ATaskDeclaration currentTask = (ATaskDeclaration)moduleSymbolTable.tasks.get(taskName);
			ATaskDeclaration depTask = (ATaskDeclaration)moduleSymbolTable.tasks.get(depInvoke.getTaskName().getText());
			
			if(Utils.isAbstract(currentTask) ^ Utils.isAbstract(depTask)){
				errorAbstractConcretDep(taskInvoke, Utils.isAbstract(currentTask)?"Abstract":"Concret", depInvoke, Utils.isAbstract(depTask)?"Abstract":"Concret");
			}
			
			if(modePortTable.portWriters.containsKey(portName))
				dependencyList.add(depInvoke);
		}
	}
	
	//misc code
	private static void dependencyError(TIdent pMode){
		throw new RuntimeException("["+pMode.getLine()+", "+pMode.getPos()+"]"+
				"There is a closed loop in invocated task in mode "+
				pMode.getText());
	}
	
	private static void errorAbstractConcretDep(ATaskInvocation currentTask, String msg1, ATaskInvocation depInvoke, String msg2){
		throw new RuntimeException("["+currentTask.getTaskName().getLine()+", "+currentTask.getTaskName().getPos()+"] "+
				msg1+" task "+currentTask.getTaskName().getText() + " can not depende on "+msg2+" task "+
				"["+depInvoke.getTaskName().getLine()+", "+depInvoke.getTaskName().getPos()+"]"+depInvoke.getTaskName().getText()+".");
	}
	
	private static void errorAbstractSwitchDep(AModeSwitch modeSwitch, ATaskInvocation depInvoke, String msg){
		throw new RuntimeException("["+modeSwitch.getDestinationMode().getLine()+", "+modeSwitch.getDestinationMode().getPos()+"] "+
				" Mode switch to "+modeSwitch.getDestinationMode().getText() + " can not depende on "+msg+" task "+
				"["+depInvoke.getTaskName().getLine()+", "+depInvoke.getTaskName().getPos()+"]"+depInvoke.getTaskName().getText()+".");
	}
	
	private static void errorPortNotWritten(TIdent port){
		throw new RuntimeException("["+port.getLine()+", "+port.getPos()+"]"
				+ "Port "+port.getText()+" read but never written.");
	}
}
