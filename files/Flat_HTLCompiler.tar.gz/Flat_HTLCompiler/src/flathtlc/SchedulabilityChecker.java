/*
 * Created on May 7, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */

package flathtlc;
import flathtlc.ComputeTaskBounds;
import flathtlc.DependencyTable;
import flathtlc.HTable;
import flathtlc.HashSetCast;
import flathtlc.InheritTable;
import flathtlc.ModeElements;
import flathtlc.ModeUnit;
import flathtlc.ModuleSymbolTable;
import flathtlc.ProgramSymbolTable;
import flathtlc.StringCast;
import flathtlc.StringComparator;
import flathtlc.SymbolTable;
import flathtlc.TypedTreeMap;
import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.AHostDeclaration;
import flathtlc.node.AModeDeclaration;
import flathtlc.node.AModeSwitch;
import flathtlc.node.AModuleDeclaration;
import flathtlc.node.AProgramDeclaration;
import flathtlc.node.ATaskDeclaration;
import flathtlc.node.ATaskInvocation;
import flathtlc.node.ATaskWcet;
import flathtlc.node.Cast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import java.util.Map.Entry;


/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 *
 */
public class SchedulabilityChecker extends DepthFirstAdapter {
	private final SymbolTable symbolTable;
	private final InheritTable inheritTable;
	private final DependencyTable dependencyTable;
	private final HTable hostTable;
	
	private String programName;
	
	private ActiveModules activeModules;
	
	private ArrayList modeCombinations;
	
	private HashSet scheduledModeCombinations = new HashSet();
		
	public SchedulabilityChecker(SymbolTable symbolTable, InheritTable inheritTable, DependencyTable dependencyTable, HTable hostTable){
		this.symbolTable = symbolTable;
		this.inheritTable = inheritTable;
		this.dependencyTable = dependencyTable;
		this.hostTable = hostTable;
	}
	
	public void outAProgramDeclaration(AProgramDeclaration node){
		programName = node.getProgramName().getText();
		activeModules = new ActiveModules();
		node.apply(activeModules);
		modeCombinations = getAllModeCombinations(activeModules.modes, activeModules.smallestPeriod);
		
		Iterator it=modeCombinations.iterator();
		while(it.hasNext()){
			testSchedulability((ArrayList)it.next(),new ArrayList(),0);
		}
	}
	
	/**
	 * Test program schedulability
	 *
	 */
	private void testSchedulability(ArrayList mc, ArrayList currentRunningTasks, int t){
		//if was schedule before return
		if(scheduledModeCombinations.contains(modeCombination2Str(mc)+taskSet2Str(currentRunningTasks))){
			return;
		}
		else{
			//store the combination
			scheduledModeCombinations.add(modeCombination2Str(mc)+taskSet2Str(currentRunningTasks));
		}
		
		//find the next moment when a switch can take plase
		//store the time interval
		int smallestTime = 0;
		boolean switchExists = false;
		ArrayList switchingModes = new ArrayList();
		do{
			for(int i = 0; i < mc.size(); i++){
				ModeCombinationElement modeCombElem = (ModeCombinationElement)mc.get(i);
				modeCombElem.currentUnit++;
				
				if(modeCombElem.currentUnit==modeCombElem.maxUnits){
					switchExists = true;
					switchingModes.add(new Integer(i));
				}
			}
			smallestTime += activeModules.smallestPeriod;
		}while(!switchExists);
			
		//test schedulability for mc, currentRunningTasks, t, and for p time units
		testModeCombSchedulability(mc, currentRunningTasks, t, smallestTime);
		t+=smallestTime;
		
		//if hyperperiod was reached return
		if(hyperperiodBoundaryReached(mc)){
			return;
		}
			
		
		int switches[] = new int[switchingModes.size()];
		int maxIndex[] = new int[switchingModes.size()];
		
		for(int i=0; i< switches.length; i++){
			switches[i] = -1;
			maxIndex[i] = ((ModeCombinationElement)mc.get(((Integer)switchingModes.get(i)).intValue())).modeSwitches.size();
		}
		//for all switch possible combinations recompute mc, call testSchedulability again
		//for new mc, currentRunningTasks and t+p
		//update release and termination times for new added tasks
		do{
			ArrayList newMc = new ArrayList();
			for(int i=0, j=0 ; i < mc.size(); i++){
				if(j < switchingModes.size() && ((Integer)switchingModes.get(j)).intValue()==i){
					if(switches[j]!=-1){
						ModeCombinationElement mcElem = (ModeCombinationElement)mc.get(((Integer)switchingModes.get(j)).intValue());
						ArrayList module = (ArrayList)activeModules.modes.get(mcElem.moduleIndex);
						ModeCombinationElement newMode = (ModeCombinationElement)((ModeCombinationElement)module.get(((Integer)mcElem.modeSwitches.get(switches[j])).intValue())).clone();
						newMode.currentUnit = 0;
						newMode.maxUnits = Integer.parseInt(newMode.mode.getModePeriod().getText()) / activeModules.smallestPeriod;
						newMode.taskSet.updateTasks(t);
						newMc.add(newMode);
					}
					else{
						ModeCombinationElement mcElem = (ModeCombinationElement)((ModeCombinationElement)mc.get(((Integer)switchingModes.get(j)).intValue())).clone();
						mcElem.currentUnit = 0;
						mcElem.taskSet.updateTasks(t);
						newMc.add(mcElem);
					}
					j++;
				}
				else{
					ModeCombinationElement mcElem = (ModeCombinationElement)((ModeCombinationElement)mc.get(i)).clone();
					newMc.add(mcElem);					
				}
			}
			
			//clone tasks
			ArrayList crrTasks = new ArrayList();
			Iterator it = currentRunningTasks.iterator();
			while(it.hasNext()){
				crrTasks.add(((TaskEntry)it.next()).clone());
			}
			
			testSchedulability(newMc, crrTasks, t);
		}while(nextSwitches(switches, maxIndex));
	}
	
	private boolean nextSwitches(int[] switches, int[] maxIndex){	
		int i=0;
		
		for(; i<switches.length; i++){
			if(switches[i]+1 < maxIndex[i]){
				switches[i]++;
				break;
			}
			else{
				switches[i]=-1;
			}
		}
		
		if(i<switches.length){
			return true;
		}
		else{
			return false;
		}
	}
	
	/**
	 * Test schedulability for the specufied mode combination, starting form t
	 * and for interval milisecond
	 * @param mc
	 * @param currentTasks
	 * @param t
	 * @param interval
	 */
	public void testModeCombSchedulability(ArrayList mc, ArrayList currentTasks, int t, int interval){
		int oldT = t;
		while(t<(oldT+interval)){			
			Iterator it = mc.iterator();
			//add new active tasks to current tasks set
			while(it.hasNext()){
				ModeCombinationElement mcElem = (ModeCombinationElement)it.next();
				
				Iterator tasksIt = mcElem.taskSet.tasks.iterator();
				
				while(tasksIt.hasNext()){
					TaskEntry taskEntry = ((TaskEntry)((TaskEntry)tasksIt.next()).clone());
					
					if(taskEntry.releaseTime == t){
						addTaskEDFOrder(currentTasks, taskEntry);
					}
					else{
						if(taskEntry.releaseTime > t)
							break;//there will be no active task
					}
				}
			}
					
			//update remaining wcets
			if(currentTasks.size() > 0){
				//test schedulability
				int maxWcet=0;
				int i;
				for(i=0; i < currentTasks.size(); i++){
					TaskEntry task = (TaskEntry)currentTasks.get(i); 
					maxWcet += task.currentWcet;
					
					if(maxWcet+t > task.initTerminationTime)
						errorNotSchedulable();
				}
				
				int tt = activeModules.smallestEventPeriod;
				while(true){
					TaskEntry crrEntry = (TaskEntry)currentTasks.get(0);
					if(crrEntry.currentWcet > tt){
						crrEntry.currentWcet -= tt;
						//this task was run for the tt ms
						break;
					}
					
					if(crrEntry.currentWcet == tt){
						crrEntry.currentWcet -= tt;
						//task finished, remove from crr task set
						currentTasks.remove(0);
						break;
					}
					
					if(crrEntry.wcet < tt){
						tt -= crrEntry.wcet; //more then needed for this task
						currentTasks.remove(0);
						if(currentTasks.size() == 0)
							break;//no active task
					}
					
				}
			}
			
			t += activeModules.smallestEventPeriod;
		}
		
		//test if remaining tasks are schedulable
		int maxWcet=0;
		int i;
		for(i=0; i < currentTasks.size(); i++){
			TaskEntry task = (TaskEntry)currentTasks.get(i); 
			maxWcet += task.currentWcet;
			
			if(maxWcet+t > task.initTerminationTime)
				errorNotSchedulable();
		}
	}
	
	/**
	 * Convert a mode combination to a String
	 * @param mc
	 * @return
	 */
	private String modeCombination2Str(ArrayList mc){
		Iterator it = mc.iterator();
		String str="";
		TreeSet	sortedNames = new TreeSet();
		while(it.hasNext()){
			ModeCombinationElement mcElem = (ModeCombinationElement)it.next();
			sortedNames.add(mcElem.mode.getModeName().getText()+mcElem.maxUnits+mcElem.currentUnit);
		}
		
		it = sortedNames.iterator();
		while(it.hasNext()){
			str+=(String)it.next();
		}
		
		//System.out.println(str);
		
		return str;
	}
	
	/**
	 * Convert a task set to a String
	 * @param taskSet
	 * @return
	 */
	private String taskSet2Str(ArrayList taskSet){
		Iterator it = taskSet.iterator();
		String str="";
		TreeSet	sortedNames = new TreeSet();
		while(it.hasNext()){
			TaskEntry taskEntry = (TaskEntry)it.next();
			sortedNames.add(taskEntry.taskName+taskEntry.currentWcet+taskEntry.wcet);
		}
		
		it = sortedNames.iterator();
		while(it.hasNext()){
			str+=(String)it.next();
		}
		
		return str;
	}
	
	/**
	 * Add a task to the task set so that the set is ordered by EDF
	 * @param taskSet
	 * @param task
	 */
	private void addTaskEDFOrder(ArrayList taskSet, TaskEntry task){
		for(int i=0; i<taskSet.size();i++){
			TaskEntry crrEntry = (TaskEntry)taskSet.get(i);
			if(crrEntry.initTerminationTime > task.initTerminationTime){
				taskSet.add(i, task);
				return;
			}
		}
		taskSet.add(task);
	}
	
	/**
	 * Add a task to the task set so that the set is ordered by
	 * earliest release time
	 * @param taskSet
	 * @param task
	 */
	private void addTaskERFOrder(ArrayList taskSet, TaskEntry task){
		for(int i=0; i<taskSet.size();i++){
			TaskEntry crrEntry = (TaskEntry)taskSet.get(i);
			if(crrEntry.releaseTime > task.releaseTime){
				taskSet.add(i, task);
				return;
			}
		}
		taskSet.add(task);
	}
		
	/**
	 * Get all modules that are on this host
	 * 
	 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2006
	 *
	 */
	private class ActiveModules extends DepthFirstAdapter{
		public ArrayList modules = new ArrayList();
		public ArrayList modes = new ArrayList();
		public int smallestPeriod=-1;
		public int smallestEventPeriod=-1;
		
		private ArrayList moduleModes;
		
		private String moduleName;
		
		private boolean isOnHost;
		
		private ArrayList modeSwitches;
		
		public void outAprogramDeclaration(AProgramDeclaration node){
			smallestEventPeriod = ModeUnit.gcd(smallestEventPeriod, smallestPeriod);
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			moduleModes = new ArrayList();
			moduleName = node.getModuleName().getText();
			isOnHost = isModuleOnHost(node);
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			if(isOnHost){
				modules.add(node);
				modes.add(moduleModes);
				
				Iterator it = moduleModes.iterator();
				while(it.hasNext()){
					ModeCombinationElement mcElem = (ModeCombinationElement)it.next();
					for(int i=0;i<mcElem.modeSwitches.size(); i++){
						String destMode = (String)mcElem.modeSwitches.get(i);
						for(int j=0; j<moduleModes.size(); j++){
							ModeCombinationElement mcElem2 = (ModeCombinationElement)moduleModes.get(j);
							if(mcElem2.mode.getModeName().getText().equals(destMode)){
								mcElem.modeSwitches.set(i, new Integer(j));
								break;
							}
						}
					}
				}
			}
		}
		
		public void inAModeDeclaration(AModeDeclaration node){
			if(isOnHost){
				modeSwitches = new ArrayList();
			}
		}
		
		public void outAModeSwitch(AModeSwitch node){
			if(isOnHost){
				modeSwitches.add(node.getDestinationMode().getText());
			}
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			if(isOnHost){
				ModeCombinationElement modeCombinationElement = new ModeCombinationElement();
				modeCombinationElement.mode = node;
				modeCombinationElement.taskSet = new TaskSet(node, programName, moduleName);
				modeCombinationElement.modeSwitches = modeSwitches;
				modeCombinationElement.moduleIndex = modes.size();
				modeCombinationElement.modeIndex = moduleModes.size();
				moduleModes.add(modeCombinationElement);
				
				ModeUnit modeUnit = new ModeUnit(programName, symbolTable, inheritTable);
				node.apply(modeUnit);
				
				if(smallestEventPeriod==-1)
					smallestEventPeriod = modeUnit.smalestPeriod;
				else
					smallestEventPeriod = ModeUnit.gcd(smallestEventPeriod, modeUnit.smalestPeriod);
				
				int period = Integer.parseInt(node.getModePeriod().getText());
				
				//update smallest period
				if(smallestPeriod==-1){
					smallestPeriod = period;
				}
				else{
					smallestPeriod = ModeUnit.gcd(smallestPeriod, period);
				}
			}
		}
	}
	
	/**
	 * Generate al posible modes combinations
	 * @param modes
	 * @return
	 */
	private ArrayList getAllModeCombinations(ArrayList modes, int smallestPeriod){
		ArrayList combinations = new ArrayList();
		ArrayList combination;
		int index[] = new int[modes.size()];
		
		index[0] = -1;//the first combination will be for all index set to 0
		for(int i=1; i<index.length; i++){
			index[i] = 0;
		}
		
		while((combination = generateModeCombination(index, modes, smallestPeriod))!=null){
			combinations.add(combination);
		}
		
		return combinations;
	}
	
	/**
	 * Generate a new mode combination
	 * @param index
	 * @param modes
	 * @return
	 */
	private ArrayList generateModeCombination(int index[], ArrayList modes, int smallestPeriod){
		ArrayList mc = new ArrayList();
		int i;
		
		for(i=0;i<index.length;i++){
			ArrayList moduleModes=(ArrayList)modes.get(i);
			if(index[i]<(moduleModes.size()-1)){
				index[i]++;
				break;
			}
			else{
				index[i]=0;
			}
		}
		
		if(i==index.length)
			return null;
		else{
			for(i=0; i<index.length;i++){
				ModeCombinationElement modeComb = (ModeCombinationElement)((ArrayList)modes.get(i)).get(index[i]);
				addMode2ModeCombinationList(modeComb, mc, smallestPeriod);
			}
			return mc;
		}
	}
	
	/**
	 * Add a mode to the a mode combination list
	 * @param modeDecl
	 * @param modeCombList
	 * @param smallestPeriod
	 */
	private void addMode2ModeCombinationList(ModeCombinationElement modeComb, ArrayList modeCombList, int smallestPeriod){
		int modePeriod = Integer.parseInt(modeComb.mode.getModePeriod().getText());
		modeComb.currentUnit = 0;
		modeComb.maxUnits = modePeriod / smallestPeriod;
		
		modeCombList.add(modeComb.clone());
	}
	
	/**
	 * Test to see if the hyperperiod boundary was reached
	 * @param modeCombination
	 * @return
	 */
	private boolean hyperperiodBoundaryReached(ArrayList modeCombination){
		boolean bdry = true;
		for(int i=0;i<modeCombination.size();i++){
			ModeCombinationElement modeCombElem = (ModeCombinationElement)modeCombination.get(i);
			bdry = bdry && modeCombElem.isChecked();
			
			if(!bdry)
				break;
		}
		
		return bdry;
	}
			
	//misc code
	private class ModeCombinationElement{
		public AModeDeclaration mode;	//mode declaration object
		public int maxUnits = 0;			//maximum number of units in the mode
		public int currentUnit = 0;			//number of tested units
		public TaskSet taskSet;
		public ArrayList modeSwitches;	//possible switches
		public int moduleIndex = 0;
		public int modeIndex = 0;
		
		public boolean isChecked(){
			return maxUnits==currentUnit;
		}
		
		public Object clone(){
			ModeCombinationElement cloneObj = new ModeCombinationElement();
			cloneObj.mode = this.mode;
			cloneObj.maxUnits = this.maxUnits;
			cloneObj.currentUnit = this.currentUnit;
			cloneObj.taskSet = (TaskSet)this.taskSet.clone();			
			cloneObj.modeSwitches = this.modeSwitches;
			cloneObj.moduleIndex = this.moduleIndex;
			cloneObj.modeIndex = this.modeIndex;
			return cloneObj;
		}
	}
	
	private class TaskEntry{
		public String taskName;
		public int releaseTime;
		public int terminationTime;
		public int initReleaseTime;
		public int initTerminationTime;
		public int modePeriod;
		public int wcet;
		public int currentWcet;
		
		public Object clone(){
			TaskEntry taskEntry=new TaskEntry();
			taskEntry.taskName = ""+this.taskName;
			taskEntry.releaseTime = this.releaseTime;
			taskEntry.terminationTime = this.terminationTime;
			taskEntry.initReleaseTime = this.initReleaseTime;
			taskEntry.initTerminationTime = this.initTerminationTime;
			taskEntry.modePeriod = this.modePeriod;
			taskEntry.wcet = this.wcet;
			taskEntry.currentWcet = this.currentWcet;
			
			return taskEntry;
		}
	}
	
	private class TaskEntryCast implements Cast{
		
		public Object cast(Object o) {
			return (TaskEntry)o;
		}
		
	}
	
	private class TaskSet{
		public ArrayList tasks = new ArrayList();
		private ArrayList initTasks;
		private AModeDeclaration mode;
		
		private String moduleName;
		private String programName;
		
		private TaskSet(){
			
		}
		
		public TaskSet(AModeDeclaration mode, String programName, String moduleName){
			this.mode = mode;
			this.programName = programName;
			this.moduleName = moduleName;
			
			ComputeTaskSet taskSet = new ComputeTaskSet(tasks, this.programName, this.moduleName);
			this.mode.apply(taskSet);
			
			initTasks = cloneTaskSet(tasks);
		}
		
		/**
		 * Update task release and termination times relative to specified time
		 * @param t
		 */
		public void updateTasks(int t){
			tasks = cloneTaskSet(initTasks);
			Iterator it = tasks.iterator();
			
			while(it.hasNext()){
				TaskEntry taskEntry=(TaskEntry)it.next();
				taskEntry.initReleaseTime += t;
				taskEntry.initTerminationTime += t;
				taskEntry.releaseTime += t;
				taskEntry.terminationTime += t;
				taskEntry.currentWcet = taskEntry.wcet;
			}
		}
		
		private ArrayList cloneTaskSet(ArrayList tasks){
			ArrayList taskSet = new ArrayList();
			
			Iterator it = tasks.iterator();
			while(it.hasNext()){
				taskSet.add(((TaskEntry)it.next()).clone());
			}
			
			return taskSet;
		}
		
		public Object clone(){
			TaskSet taskSet= new TaskSet();
			
			taskSet.mode = mode;
			taskSet.programName = programName;
			taskSet.moduleName = moduleName;
			taskSet.initTasks = initTasks;
			
			Iterator it = tasks.iterator();
			while(it.hasNext()){
				taskSet.tasks.add(((TaskEntry)it.next()).clone());
			}
			
			return taskSet;
		}
	}
	
	private class ComputeTaskSet extends DepthFirstAdapter{
		private ArrayList taskSet;
		private int modePeriod;
		
		private String programName;
		private String moduleName;
		
		private ProgramSymbolTable programSymbolTable;
		private ModuleSymbolTable moduleSymbolTable;
		
		public ComputeTaskSet(ArrayList taskSet, String programName, String moduleName){
			this.taskSet = taskSet;
			this.programName = programName;
			this.moduleName = moduleName;
			
			programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(programName);			
			moduleSymbolTable = (ModuleSymbolTable)programSymbolTable.modules.get(moduleName);
		}
		
		public void inAModeDeclaration(AModeDeclaration node){
			modePeriod = Integer.parseInt(node.getModePeriod().getText());
			
			String modeName = node.getModeName().getText();
																		
			Map taskDep = new TypedTreeMap(StringComparator.instance, StringCast.instance, 
					HashSetCast.instance);
			Map modeDep = ((Map)dependencyTable.taskDependencies.get(programName+"."+moduleName+"."+modeName));
			Iterator it = modeDep.entrySet().iterator();
					
			//compute dependency set
			HashSet depSet;
			while(it.hasNext()){
				Entry entry = (Entry)it.next();
				depSet = new HashSet();
				ArrayList depList = (ArrayList)entry.getValue();
				
				Iterator itDepList = depList.iterator();
				while(itDepList.hasNext()){
					String depTask = ((ATaskInvocation)itDepList.next()).getTaskName().getText();
					depSet.add(depTask);
				}
				
				taskDep.put(entry.getKey(), depSet);
			}
			
			ModeElements modeElements = new ModeElements();
			node.apply(modeElements);
			
			it = taskDep.entrySet().iterator();
			Map taskSet = new TypedTreeMap(StringComparator.instance, StringCast.instance,
					new TaskEntryCast());
			//compute task set without precedencies
			while(it.hasNext()){
				Entry entry = (Entry)it.next();
				
				String taskName = (String)entry.getKey();
				depSet = (HashSet)entry.getValue();
				
				if(depSet.isEmpty()){
					ATaskInvocation taskInvoke = (ATaskInvocation) modeElements.taskInvocations.get(taskName);
					
					if(taskInvoke == null)
						continue;
					
					// proccess task
					ComputeTaskBounds taskBounds = new ComputeTaskBounds(programName, moduleName, 
							node.getModeName().getText(), symbolTable, inheritTable);
					
					taskInvoke.apply(taskBounds);
					
					int wcet = getWcet((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName));
					
					TaskEntry taskEntry = getTaskBounds((ArrayList)modeDep.get(taskName), taskSet, taskBounds.higherReadInstance, taskBounds.lowerWriteInstance, wcet);
					taskEntry.wcet = wcet;
					taskEntry.taskName = taskName;
					taskEntry.modePeriod = modePeriod;
					taskEntry.currentWcet = wcet;
					taskSet.put(taskName, taskEntry);
					
					//update dep sets for other tasks
					Iterator it2 = taskDep.entrySet().iterator();
					while(it2.hasNext()){
						Entry entry2 = (Entry)it2.next();
						
						HashSet depSet2 = (HashSet)entry2.getValue();
						if(depSet2.contains(taskName)){
							depSet2.remove(taskName);
						}
					}
				}
			}
			
			it = taskSet.entrySet().iterator();
			while(it.hasNext()){
				Entry entry = (Entry)it.next();
				
				TaskEntry taskEntry = (TaskEntry)entry.getValue();
				
				addTaskERFOrder(this.taskSet, taskEntry);
			}
		}
		
		private int getWcet(ATaskDeclaration task){
			int wcet = 0;
			if(task.getTaskWcet()!=null){
				wcet = Integer.parseInt(((ATaskWcet)task.getTaskWcet()).getWcetMap().getText());
			}
			
			return wcet;
		}
		
		private TaskEntry getTaskBounds(ArrayList depList, Map taskSet, int higherReadInstance, int lowerWriteInstance, int wcet){
			TaskEntry taskEntry = new TaskEntry();
			taskEntry.releaseTime = higherReadInstance;
			taskEntry.terminationTime = higherReadInstance+wcet;
			taskEntry.initReleaseTime = higherReadInstance;
			taskEntry.initTerminationTime = lowerWriteInstance;
			
			Iterator itDepList = depList.iterator();
			while(itDepList.hasNext()){
				String taskName = ((ATaskInvocation)itDepList.next()).getTaskName().getText();
				TaskEntry entry = (TaskEntry)taskSet.get(taskName);
				if(entry.terminationTime > taskEntry.releaseTime){
					taskEntry.releaseTime = entry.terminationTime;
					taskEntry.terminationTime = entry.terminationTime+wcet;
				}
			}
			
			if(taskEntry.terminationTime > taskEntry.initTerminationTime){
				errorNotSchedulable();
			}
			
			return taskEntry;
		}
	}
	
	private boolean isModuleOnHost(AModuleDeclaration pModule){
		if(hostTable.currentHost==null || pModule.getHostDeclaration()==null
				|| hostTable.currentHost.equals(((AHostDeclaration)pModule.
						getHostDeclaration()).getHostName().getText())){
			return true;
		}
		return false;
	}
	
	public static void errorNotSchedulable(){
		throw new RuntimeException("Program not schedulable.");
	}
}