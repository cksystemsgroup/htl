/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * This file is part of SableCC.                             *
 * See the file "LICENSE" for copyright information and the  *
 * terms and conditions for copying, distribution and        *
 * modification of SableCC.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package flathtlc;

import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.Node;
import flathtlc.node.Token;

/**
 * Simple AST walker. This is simple Abstract Syntax Tree walker which will
 * visit each of the nodes and print on standard output the name of particular
 * node visited. This class can be very usefull while testing the tree structure
 * for a given input. Check PrintTree class.
 * 
 * @author Mariusz Nowostawski
 */
public class PrintWalker extends DepthFirstAdapter {

	int indent = 0;

	void indent() {
		String s = new String("");
		for (int i = 0; i < indent; i++)
			s += " ";
		System.out.print(s);
	}

	public void defaultIn(Node node) {
		indent();
		System.out.println(node.getClass().getName().substring(
				"giotto".length() + 1));
		indent++;
	}

	public void defaultOut(Node node) {
		indent--;
	}

	public void defaultCase(Node node) {
		indent();
		System.out.println(node.getClass().getName().substring(
				"giotto".length() + 1)
				+ ": " + ((Token) node).getText());
	}

}
