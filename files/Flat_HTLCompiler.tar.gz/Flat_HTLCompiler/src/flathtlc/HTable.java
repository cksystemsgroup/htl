/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package flathtlc;

import flathtlc.CodeGen;
import flathtlc.InheritTable;
import flathtlc.StringCast;
import flathtlc.StringComparator;
import flathtlc.SymbolTable;
import flathtlc.TypedTreeMap;
import flathtlc.analysis.DepthFirstAdapter;
import flathtlc.node.AHostDeclaration;
import flathtlc.node.AIpDeclaration;
import flathtlc.node.AModuleDeclaration;
import flathtlc.node.AProgramDeclaration;
import flathtlc.node.AProgramDeclarationList;
import flathtlc.node.Node;
import flathtlc.node.TIdent;
import flathtlc.node.TNumber;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.ListIterator;
import java.util.Map;

/**
 * 
 * This class implements code generation of the host annotations. A host
 * annotation defines a unique host id etc.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 * 		   Daniel Iercan, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class HTable extends CodeGen {
	public final Map moduleHost = new TypedTreeMap(StringComparator.instance,
			StringCast.instance, StringCast.instance);
	
	private boolean pureGiotto;
	public final String currentHost;
	
	private final ArrayList orderedHosts = new ArrayList();

	private final Hashtable hostTable = new Hashtable();
	
	private final InheritTable inheritTable;
	
	private String crrProgramName;
	private boolean inRootProgram;
	private String crrModuleName;
	
	private boolean currentHostFound = false;
	
	private final HashSet rootModulesOnKnownHost = new HashSet();
	private final HashSet rootModulesOnUnknownHost = new HashSet();

	public HTable(SymbolTable symbolTable, InheritTable inheritTable, boolean pureGiotto, String currentHost) {
		super(symbolTable, "htable", "h_table.c", "h_table.h", "h_spec.txt");

		this.inheritTable = inheritTable;
		this.currentHost = currentHost;
		this.pureGiotto = pureGiotto;
	}

	// Action code

	public void emitCFileHeader(AProgramDeclarationList node) {
		emit("Header");

		emit("Include");
	}

	public void emitCFileBody(AProgramDeclarationList node) {
		ListIterator iterator;

		for (iterator = hostIterator(); iterator.hasNext();) {
			final String hostName = (String) iterator.next();

			final Host host = (Host) hostTable.get(hostName);

			emit("HostInitializationWrapper", new String[] { host.hostInitName,
					host.initName });
		}

		int nHosts = 0;

		if (pureGiotto) {
			emit("HostTableHeader");

			emit("Semicolon");
		} else {
			emit("HostTableHeader");

			emit("HostTableBegin");

			for (iterator = hostIterator(); iterator.hasNext(); nHosts++) {
				final String hostName = (String) iterator.next();

				if (nHosts != 0)
					emit("TableComma");

				final Host host = (Host) hostTable.get(hostName);

				emit("HostTableElement", new String[] { hostName,
						host.hostInitName, Integer.toString(host.startAddress),
						host.ip, host.port });
			}

			emit("TableEnd");
		}
	}

	public void emitHFileHeader(AProgramDeclarationList node) {
		emit("Header");
	}

	public void emitHFileBody(AProgramDeclarationList node) {
		int nHosts = hostTable.size();

		if (pureGiotto)
			nHosts = 0;

		emit("TableSize", new String[] { Integer.toString(nHosts) });
	}

	private class ComputeHEntry extends DepthFirstAdapter {
		private class GenHostPriorityAllocation extends DepthFirstAdapter {
			private String hostName;

			public GenHostPriorityAllocation(String hostName) {
				this.hostName = hostName;
			}

			// FIXME: Add priorities.
		}

		private String ipToString(AIpDeclaration node) {
			return node.getA().getText() + "."
					+ node.getB().getText() + "."
					+ node.getC().getText() + "."
					+ node.getD().getText();
		}
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			crrProgramName = node.getProgramName().getText();
			inRootProgram = inheritTable.getRootProgramName().equals(crrProgramName);
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			crrProgramName = "";
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			crrModuleName = node.getModuleName().getText();
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			if(inRootProgram){
				if(node.getHostDeclaration() != null){
					AHostDeclaration hostDecl = (AHostDeclaration)node.getHostDeclaration();
					String hostName = hostDecl.getHostName().getText();
					rootModulesOnKnownHost.add(crrModuleName);
					
					moduleHost.put(crrProgramName+"."+crrModuleName, hostName);
					
					if(currentHost==null || currentHost.equals("") || currentHost.equals(hostDecl.getHostName().getText())){
						currentHostFound = true;
					}
					
					if(!hostTable.contains(hostDecl.getHostName().getText()))
						generateHostEntry(hostDecl);
				}
				else{
					rootModulesOnUnknownHost.add(crrModuleName);
				}
				
				if(!rootModulesOnKnownHost.isEmpty() && !rootModulesOnUnknownHost.isEmpty()){
					errorHosts();
				}
			}
			else
			{
				if(node.getHostDeclaration()!=null){
					errorHostInSubModule(node.getModuleName());
				}
				
				AModuleDeclaration module = inheritTable.getRootModule(crrProgramName, crrModuleName);
				
				if(module.getHostDeclaration()!=null){
					moduleHost.put(crrProgramName+"."+crrModuleName, 
							((AHostDeclaration)module.getHostDeclaration()).getHostName().getText());
				}
			}
			
			crrModuleName = "";
		}
		
		public void outAProgramDeclarationList(AProgramDeclarationList node){
			if(!currentHostFound){
				throw new RuntimeException("Specified host '"+currentHost+"' could not be found in the program.");
			}
		}
		
		private Host getHostEntry(AHostDeclaration node){
			String port = node.getHostPort().getText();
			String hostIP = "";
			int A,B,C,D;
			TNumber aIdent, bIdent, cIdent, dIdent;
			
			aIdent = ((AIpDeclaration)node.getHostIp()).getA();
			bIdent = ((AIpDeclaration)node.getHostIp()).getB();
			cIdent = ((AIpDeclaration)node.getHostIp()).getC();
			dIdent = ((AIpDeclaration)node.getHostIp()).getD();
			
			A = Integer.parseInt(aIdent.getText());
			B = Integer.parseInt(bIdent.getText());
			C = Integer.parseInt(cIdent.getText());
			D = Integer.parseInt(dIdent.getText());
			
			if(A>255){
				errorIPNumber(aIdent);
			}
			
			if(B>255){
				errorIPNumber(bIdent);
			}
			
			if(C>255){
				errorIPNumber(cIdent);
			}
			
			if(D>255){
				errorIPNumber(dIdent);
			}
			
			hostIP = ""+A+"."+B+"."+C+"."+D;
			
			return new Host(node.getHostName().getText() ,hostIP, port);
		}

		private void generateHostEntry(AHostDeclaration node) {
			final String hostName = node.getHostName().getText();

			node.apply(new GenHostPriorityAllocation(hostName));

			if (!hostTable.containsKey(hostName)) {
				orderedHosts.add(hostName);

				final String hostIP = ipToString((AIpDeclaration) node.getHostIp());
				final String hostPort = node.getHostPort().getText();

				hostTable.put(hostName, new Host(hostName, hostIP, hostPort));
			} //else
				//throw new RuntimeException("Ambiguous host names.");
		}
	}

	public void computeHTable(Node node) {
		if (!pureGiotto)
			node.apply(new ComputeHEntry());
	}

	private class Host {
		private String name;

		private String ip;

		private String port;

		private int startAddress = 0;

		private String initName;

		private String hostInitName;

		public Host(String name, String ip, String port) {
			this.name = name;
			this.ip = ip;
			this.port = port;

			this.initName = generateInitName(name);
			this.hostInitName = generateHostName(initName);
		}
	}

	// Misc code

	private String generateHostName(String hostName) {
		return generateName("host", hostName);
	}

	public ListIterator hostIterator() {
		return orderedHosts.listIterator();
	}

	public void addStartAddress(String hostName, int startAddress) {
		((Host) hostTable.get(hostName)).startAddress = startAddress;
	}
	
	private static void errorIPNumber(TNumber number){
		throw new RuntimeException("["+number.getLine()+", "+number.getPos()+"] "+
				number.getText()+" is gratter then 255."
				);
	}
	
	private static void errorHosts(){
		throw new RuntimeException("Either all the root modules or none specify a host.");
	}
	
	private static void errorHostInSubModule(TIdent module){
		throw new RuntimeException("["+module.getLine()+", "+module.getPos()+"] "+
				" There is a host specified for module "+module.getText()+
				", but this is a sub-module."
				);
	}
}
