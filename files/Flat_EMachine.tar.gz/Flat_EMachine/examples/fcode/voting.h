#ifndef VOTING_H_
#define VOTING_H_

#define NULL_C_DOUBLE 1000000000l
#define NULL_C_BOOL 1000

#include "types.h"

void voting_c_double(c_double *port, c_double port_array[], unsigned length);
void reset_port_history_c_double(c_double port_array[], unsigned length);

void voting_c_bool(c_bool *port, c_bool port_array[], unsigned length);
void reset_port_history_c_bool(c_bool port_array[], unsigned length);

#endif /*VOTING_H_*/

