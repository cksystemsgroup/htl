#include "voting.h"

void voting_c_double(c_double *port, c_double port_array[], unsigned length){
	unsigned idx;
	
	for(idx=0; idx<length; idx++){
		if(port_array[idx]<NULL_C_DOUBLE){
			*port = port_array[idx];
			//printf("Value found: DOUBLE %f\n", *port);
			return;
		}
	}
	printf("Value NOT found\n");
}

void reset_port_history_c_double(c_double port_array[], unsigned length){
	unsigned idx;
	
	for(idx=0; idx<length; idx++)
		port_array[idx] = NULL_C_DOUBLE;
}

void voting_c_bool(c_bool *port, c_bool port_array[], unsigned length){
	unsigned idx;
	
	for(idx=0; idx<length; idx++){
		if(port_array[idx]<NULL_C_BOOL){
			*port = port_array[idx];
			//printf("Value found: BOOL %u \n", *port);
			return;
		}
	}
	printf("Value NOT found\n");
}

void reset_port_history_c_bool(c_bool port_array[], unsigned length){
	unsigned idx;
	
	for(idx=0; idx<length; idx++)
		port_array[idx] = NULL_C_BOOL;
}
