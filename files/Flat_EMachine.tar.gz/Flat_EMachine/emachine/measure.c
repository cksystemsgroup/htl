#include <stdio.h>
#include <sys/time.h>
#include "measure.h"

void startTimer(){
    gettimeofday(&start, NULL);
}

int stopTimer(){
    gettimeofday(&finish, NULL);
    seconds = finish.tv_sec*1000 - start.tv_sec*1000;
    nanosec = finish.tv_usec - start.tv_usec;
	msec = seconds*1000+nanosec;
    return msec;
}

int getTimeInterval(struct timeval *start, struct timeval * finish){
	long long seconds, nanosec;
	seconds = finish->tv_sec*1000 - start->tv_sec*1000;
    nanosec = finish->tv_usec - start->tv_usec;
    return seconds*1000+nanosec;
}
