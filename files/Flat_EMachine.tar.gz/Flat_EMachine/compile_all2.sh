make all host=SMCUFL ID=0
cp e-machine ./binaries/0_SMCUFL

make all host=SMCUFR ID=1
cp e-machine ./binaries/1_SMCUFR

make all host=SMCURL ID=2
cp e-machine ./binaries/2_SMCURL

make all host=SMCURR ID=3
cp e-machine ./binaries/3_SMCURR

make all host=CONTROL ID=4
cp e-machine ./binaries/4_CONTROL

make all host=STEER ID=5
cp e-machine ./binaries/5_STEER

make all host=FAULT ID=6
cp e-machine ./binaries/6_FAULT

make all host=POWER ID=7
cp e-machine ./binaries/7_POWER
