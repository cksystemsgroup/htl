/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package htlc;

import htlc.analysis.DepthFirstAdapter;
import htlc.node.AActualPortList;
import htlc.node.AActualPortTail;
import htlc.node.AConcreteActualPortList;
import htlc.node.AConcreteFormalPortList;
import htlc.node.AConcreteStatePortList;
import htlc.node.AConcreteSwitchPortList;
import htlc.node.AFormalPortList;
import htlc.node.AFormalPortTail;
import htlc.node.AStatePortList;
import htlc.node.AStatePortTail;
import htlc.node.ASwitchPortList;
import htlc.node.ASwitchPortTail;

import java.util.LinkedList;
import java.util.ListIterator;


/**
 * 
 * This class implements a tree walker that converts the concrete syntax tree
 * into an abstract syntax tree.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 * 		   Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 */
public class CST2AST extends DepthFirstAdapter {

	public void outAConcreteActualPortList(AConcreteActualPortList node) {
		final LinkedList actualPortList = new LinkedList();

		actualPortList.add(node.getActualPort());

		for (ListIterator iterator = node.getActualPortTail().listIterator(); iterator
				.hasNext();) {
			final AActualPortTail actualPortTail = (AActualPortTail) iterator
					.next();
			
			actualPortList.add(actualPortTail.getActualPort());
		}

		node.replaceBy(new AActualPortList(actualPortList));
	}
	
	public void outAConcreteFormalPortList(AConcreteFormalPortList node) {
		final LinkedList formalPortList = new LinkedList();

		formalPortList.add(node.getFormalPort());

		for (ListIterator iterator = node.getFormalPortTail().listIterator(); iterator
				.hasNext();) {
			final AFormalPortTail formalPortTail = (AFormalPortTail) iterator
					.next();

			formalPortList.add(formalPortTail.getFormalPort());
		}

		node.replaceBy(new AFormalPortList(formalPortList));
	}
	
	public void outAConcreteStatePortList(AConcreteStatePortList node) {
		final LinkedList statePortList = new LinkedList();

		statePortList.add(node.getStatePort());

		for (ListIterator iterator = node.getStatePortTail().listIterator(); iterator
				.hasNext();) {
			final AStatePortTail statePortTail = (AStatePortTail) iterator
					.next();

			statePortList.add(statePortTail.getStatePort());
		}

		node.replaceBy(new AStatePortList(statePortList));
	}
	
	public void outAConcreteSwitchPortList(AConcreteSwitchPortList node) {
		final LinkedList switchPortList = new LinkedList();

		switchPortList.add(node.getSwitchPort());

		for (ListIterator iterator = node.getSwitchPortTail().listIterator(); iterator
				.hasNext();) {
			final ASwitchPortTail switchPortTail = (ASwitchPortTail) iterator
					.next();
			
			switchPortList.add(switchPortTail.getSwitchPort());
		}

		node.replaceBy(new ASwitchPortList(switchPortList));
	}
}
