/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package htlc;

import htlc.analysis.DepthFirstAdapter;
import htlc.node.AActuatorDeviceDriver;
import htlc.node.ACommunicatorDeclaration;
import htlc.node.ACommunicatorInstance;
import htlc.node.AModeDeclaration;
import htlc.node.AModuleDeclaration;
import htlc.node.AParentTask;
import htlc.node.AProgramDeclaration;
import htlc.node.ARefineProgram;
import htlc.node.ASensorDeviceDriver;
import htlc.node.ASwitchPort;
import htlc.node.ATaskDeclaration;
import htlc.node.ATaskInvocation;
import htlc.node.ATaskWcet;
import htlc.node.TIdent;
import htlc.node.Token;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;


/**
 * 
 * This class checks whether the input program is 'well-timed'.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu Arkadeb Ghosal,
 *         arkadeb@eecs.berkeley.edu, 
 *         Daniel Iercan, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class FrequencyChecker extends DepthFirstAdapter {
    
    private Token modePeriodToken = null;

    private SymbolTable symbolTable;

    private DependencyTable dependencyTable;
    
    private InheritTable inheritTable;

    private int modePeriod;
    
    private String programName;
    
    private String moduleName;
    
    private Token modeToken;

    private ModeElements modeElements;
    
    private ModeElements superModeElements;

    public FrequencyChecker(SymbolTable symbolTable,
            DependencyTable pDependencyTable, InheritTable inheritTable) {
        this.symbolTable = symbolTable;

        dependencyTable = pDependencyTable;
        
        this.inheritTable = inheritTable;
    }
    
    public void inAProgramDeclaration(AProgramDeclaration node){
    	programName = node.getProgramName().getText();
    }
    
    public void outAProgramDeclaration(AProgramDeclaration node){
    	programName = "";
    }

    public void inAModuleDeclaration(AModuleDeclaration node){
    	moduleName = node.getModuleName().getText();
    }
    
    public void outAModuleDeclaration(AModuleDeclaration node){
    	moduleName = "";
    }
    
    public void inACommunicatorDeclaration(ACommunicatorDeclaration node){
    	Token communucatorPeriod=node.getCommunicatorPeriod();
    	
    	int commPeriod=Integer.parseInt(communucatorPeriod.getText());
    	
    	if (commPeriod == 0){
    		errorZero(communucatorPeriod);
    	}
    }
        
    public void inAModeDeclaration(AModeDeclaration node) {
    	modeToken = node.getModeName();
    	
        modePeriodToken = node.getModePeriod();

        modePeriod = Integer.parseInt(modePeriodToken.getText());

        if (modePeriod == 0)
            errorZero(modePeriodToken);
        
        modeElements = new ModeElements();
        node.apply(modeElements);
        
        if(!inheritTable.getRootProgramName().equals(programName))
        	superModeElements = getSuperModeElements();
        else
        	superModeElements = null;
    }

    /**
	 * 
	 * @param name
	 * @return communicator period
	 */
	private int getCommunicatorPeriod(String name){
		int period=0;
		
		String program = programName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				period = Integer.parseInt(((ACommunicatorDeclaration) pSymbolTable.communicators
						.get(name)).getCommunicatorPeriod().getText());
				break;
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return period;
	}
    
	public void outACommunicatorInstance(ACommunicatorInstance node){
		String commName=node.getCommunicatorPortName().getText();
		int period = getCommunicatorPeriod(commName);
		int instance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
		
		if(modePeriod % period !=0){
			//communicator period does not devide modePeriod
			errorDevide(node.getCommunicatorPortName(), modeToken);
		}
		
		if(period*instance>modePeriod){
			//communicatro instance is to big
			errorInstance(node.getCommunicatorPortName());
		}
	}
	
	public void outASensorDeviceDriver(ASensorDeviceDriver node){
		String commName=node.getCommunicatorName().getText();
		int period = getCommunicatorPeriod(commName);
		int instance = Integer.parseInt(node.getCommunicatorInstance().getText());
		
		if(modePeriod % period !=0){
			//communicator period does not devide modePeriod
			errorDevide(node.getCommunicatorName(), modeToken);
		}
		
		if(period*instance>modePeriod){
			//communicatro instance is to big
			errorInstance(node.getCommunicatorName());
		}
	}
	
	public void outAActuatorDeviceDriver(AActuatorDeviceDriver node){
		String commName=node.getCommunicatorName().getText();
		int period = getCommunicatorPeriod(commName);
		int instance = Integer.parseInt(node.getCommunicatorInstance().getText());
		
		if(modePeriod % period !=0){
			//communicator period does not devide modePeriod
			errorDevide(node.getCommunicatorName(), modeToken);
		}
		
		if(period*instance>modePeriod){
			//communicatro instance is to big
			errorInstance(node.getCommunicatorName());
		}
	}
	
	public void outASwitchPort(ASwitchPort node){
		String commName=node.getPortName().getText();
		int period = getCommunicatorPeriod(commName);
		
		if(period>0){
			//it is a communicator
			if(modePeriod % period !=0){
				//communicator period does not devide modePeriod
				errorDevide(node.getPortName(), modeToken);
			}
		}
	}
	
    public void outAModeDeclaration(AModeDeclaration node) {
        modePeriodToken = null;
        if(node.getRefineProgram() != null){
        	((ProgramSymbolTable)symbolTable.programs.get(((ARefineProgram)node.
        			getRefineProgram()).getProgramName().getText())).program.apply(
        					new TestSubProgramModesPeriod(Integer.parseInt(
        							node.getModePeriod().getText())));
        }
    }

    private class TestSubProgramModesPeriod extends DepthFirstAdapter{
    	private int period = 0;
    	
    	public TestSubProgramModesPeriod(int period){
    		this.period = period;
    	}
    	
    	public void outAModeDeclaration(AModeDeclaration node){
    		int period1 = Integer.parseInt(node.getModePeriod().getText());
    		
    		if(period1 != period){
    			throw new RuntimeException("["+node.getModePeriod().getLine()+", "+node.getModePeriod().getPos()+"]"+
    					"The sub-mode should have the same period as the super-mode.");
    		}
    	}
    }
    
    private ModeElements getModeElements(String programName, String moduleName, String modeName){
    	if(moduleName == null)
    		return null;
    	if(modeName == null)
    		return null;
    	
    	ProgramSymbolTable progSymbols = ((ProgramSymbolTable)symbolTable.programs.get(programName));
    	ModuleSymbolTable moduleSymbols = ((ModuleSymbolTable)progSymbols.modules.get(moduleName));
    	AModeDeclaration modeDecl = (AModeDeclaration)moduleSymbols.modes.get(modeName);
    	
    	ModeElements elem = new ModeElements();
    	modeDecl.apply(elem);
    	
    	return elem;
    }
    
    private ModeElements getSuperModeElements(){
    	String superProgramName = (String)inheritTable.programParents.get(programName);
    	String superModuleName = (String)inheritTable.moduleParents.get(moduleName);
    	String superModeName = (String)inheritTable.modeParents.get(modeToken.getText());
    	
    	return getModeElements(superProgramName, superModuleName, superModeName);
    }
    
    private ArrayList getParentTaskDepList(String taskName){
    	String superProgramName = (String)inheritTable.programParents.get(programName);
    	String superModuleName = (String)inheritTable.moduleParents.get(moduleName);
    	String superModeName = (String)inheritTable.modeParents.get(modeToken.getText());
    	
    	Map map=(Map)dependencyTable.taskDependencies.get(superProgramName+"."+superModuleName+"."+superModeName);
    	ArrayList dependencies = (ArrayList)(map.get(taskName));
    	
    	return dependencies;
    }
    
    private ComputeTaskBounds getParentBounds(ATaskInvocation parentTask){
    	String superProgramName = (String)inheritTable.programParents.get(programName);
    	String superModuleName = (String)inheritTable.moduleParents.get(moduleName);
    	String superModeName = (String)inheritTable.modeParents.get(modeToken.getText());
    	
    	ComputeTaskBounds bounds = new ComputeTaskBounds(superProgramName, superModuleName, superModeName, symbolTable, inheritTable);
    	parentTask.apply(bounds);
    	
    	return bounds;
    }
    
    private int getParentWCET(String taskName){
    	String superProgramName = (String)inheritTable.programParents.get(programName);
    	String superModuleName = (String)inheritTable.moduleParents.get(moduleName);
    	//String superModeName = (String)inheritTable.modeParents.get(modeToken.getText());
    	
    	ProgramSymbolTable progSymbols = ((ProgramSymbolTable)symbolTable.programs.get(superProgramName));
    	ModuleSymbolTable moduleSymbols = ((ModuleSymbolTable)progSymbols.modules.get(superModuleName));
    	
    	int wcet = 0;
    	ATaskDeclaration task = (ATaskDeclaration)moduleSymbols.tasks.get(taskName);
    	if(task.getTaskWcet()!=null){
    		wcet = Integer.parseInt(((ATaskWcet)task.getTaskWcet()).getWcetMap().getText());
    	}
    	
    	return wcet;
    }
    
    public void outATaskInvocation(ATaskInvocation node){
    	TaskTimeConstrains timeConstrains = new TaskTimeConstrains(programName, symbolTable, inheritTable);
    	node.apply(timeConstrains);
    	
    	if(timeConstrains.inputParam>0 && timeConstrains.outputParam>0 && timeConstrains.higherReadCommInstance>=timeConstrains.lowerWriteCommInstance){
    		errorConstrains(node.getTaskName());
    	}
    	
    	Map map=(Map)dependencyTable.taskDependencies.get(programName+"."+moduleName+"."+modeToken.getText());
    	ArrayList dependencies = (ArrayList)(map.get(node.getTaskName().getText()));
    	
    	Iterator itDep = dependencies.iterator();
    	while(itDep.hasNext()){
    		ATaskInvocation taskInvok = (ATaskInvocation)itDep.next();
    		TaskTimeConstrains timeConstrains2=new TaskTimeConstrains(programName, symbolTable, inheritTable);
    		
    		taskInvok.apply(timeConstrains2);
    		
    		if(timeConstrains2.higherReadCommInstance >= timeConstrains.lowerWriteCommInstance){
    			causalityError(taskInvok.getTaskName(), node.getTaskName());
    		}
    	}
    	
    	if(node.getParentTask() != null){
    		String parentTaskName = ((AParentTask)node.getParentTask()).getTaskName().getText();
    		ArrayList superDependencies = getParentTaskDepList(parentTaskName);
    		if(!checkDependenciesInherit(dependencies, superDependencies)){
    			errorDepInherit(node.getTaskName());
    		}
    		
    		// test task bounds
    		ATaskInvocation parentInvoke = (ATaskInvocation)superModeElements.taskInvocations.get(parentTaskName);
    		ComputeTaskBounds taskBounds = new ComputeTaskBounds(programName, moduleName, modeToken.getText(), symbolTable, inheritTable);
    		node.apply(taskBounds);
        	ComputeTaskBounds parentBounds = getParentBounds(parentInvoke);
        	
        	if(taskBounds.higherReadInstance > parentBounds.higherReadInstance ){
        		errorBounds(node.getTaskName(), "'higher read instance' grater then its parent.");
        	}
        	
        	if(taskBounds.lowerWriteInstance < parentBounds.lowerWriteInstance){
        		errorBounds(node.getTaskName(), "'lower wite instance', lower then its parent.");
        	}
        	
        	//test wcet
        	int wcet = 0;
        	ProgramSymbolTable progSymbols = ((ProgramSymbolTable)symbolTable.programs.get(programName));
        	ModuleSymbolTable moduleSymbols = ((ModuleSymbolTable)progSymbols.modules.get(moduleName));
        	ATaskDeclaration task = (ATaskDeclaration)moduleSymbols.tasks.get(node.getTaskName().getText());
        	if(task.getTaskWcet()!=null){
        		wcet = Integer.parseInt(((ATaskWcet)task.getTaskWcet()).getWcetMap().getText());
        	}
        	
        	int parentWcet = getParentWCET(parentTaskName);
        	
        	if(wcet > parentWcet){
        		errorParentWcet(node.getTaskName());
        	}
    	}
    }
    
    private boolean checkDependenciesInherit(ArrayList dependencies, ArrayList parentDependencies){
    	Iterator itParentDep = parentDependencies.iterator();
    	
    	while(itParentDep.hasNext()){
    		String parentDepTask = ((ATaskInvocation)itParentDep.next()).getTaskName().getText();
    		
    		Iterator itDep = dependencies.iterator();
    		boolean depFound=false;
    		while(itDep.hasNext()){
    			String depTask = ((ATaskInvocation)itDep.next()).getTaskName().getText();
    			ATaskInvocation taskInvoc = (ATaskInvocation)modeElements.taskInvocations.get(depTask);
    			if(taskInvoc.getParentTask()!=null){
    				String taskName = ((AParentTask)taskInvoc.getParentTask()).getTaskName().getText();
    				if(taskName.equals(parentDepTask)){
    					depFound = true;
    					break;
    				}
    			}
    		}
    		
    		if(!depFound){
    			return false;
    		}
    	}
    	
    	return true;
    }
    
    private static void errorZero(Token token) {
        throw new RuntimeException("[" + token.getLine() + "," + token.getPos()
                + "]" + " Zero period or frequency not allowed.");
    }

    private static void causalityError(TIdent startNode, TIdent endNode) {
        throw new RuntimeException("[" + startNode.getLine() + ", "
                + startNode.getPos() + "]" + " Causality error between "
                + startNode.getText() + "[" + startNode.getLine() + ", "
                + startNode.getPos() + "]" + " and " + "" + endNode.getText()
                + "[" + endNode.getLine() + ", " + endNode.getPos() + "]");
    }

    private static void errorDevide(Token comm, Token mode){
    	throw new RuntimeException("["+comm.getLine()+", "+comm.getPos()+"]"
    			+ "Communicator "+comm.getText()+" period does not devide mode "+
    			mode.getText()+" period."
    			);
    }
    
    private static void errorInstance(Token comm){
    	throw new RuntimeException("["+comm.getLine()+", "+comm.getPos()+"]"
    			+ "Communicator "+comm.getText()+ " instance is too big.");
    }
    
    private static void errorConstrains(Token task){
    	throw new RuntimeException("["+task.getLine()+", "+task.getPos()+"]"
    			+ "There is zero time to execute task "+task.getText()+ ".");
    }
    
    private static void errorDepInherit(Token task){
    	throw new RuntimeException("["+task.getLine()+", "+task.getPos()+"]"
    			+ "Dependency list for task '"+task.getText()+ "' parent is not inherit.");
    }
    
    private static void errorBounds(Token task, String msg){
    	throw new RuntimeException("["+task.getLine()+", "+task.getPos()+"]"
    			+ "Task '"+task.getText()+ "' has the "+msg);
    }
    
    private static void errorParentWcet(Token task){
    	throw new RuntimeException("["+task.getLine()+", "+task.getPos()+"]"
    			+ "Task '"+task.getText()+ "' has the 'wcet' grater then its parent.");
    }
    
    public String toString() {
        return symbolTable.toString();
    }
}
