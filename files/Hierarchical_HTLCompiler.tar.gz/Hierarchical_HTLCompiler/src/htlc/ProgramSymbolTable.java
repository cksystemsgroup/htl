/*
 * Created on October 19, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */

package htlc;
import htlc.node.ACommunicatorDeclaration;
import htlc.node.AModuleDeclaration;
import htlc.node.AProgramDeclaration;
import htlc.node.NodeCast;

import java.util.Map;

/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 *
 */
public class ProgramSymbolTable extends AbstractSymbolTable {
	
	public final AProgramDeclaration program; 
        
    public final Map communicators = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, NodeCast.instance);

    public final Map modules = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, AbstractSymbolTableCast.instance);
    
    private final SymbolTable symbolTable;

	public ProgramSymbolTable(AProgramDeclaration program, SymbolTable symbolTable){
		this.program = program;
		
		this.symbolTable = symbolTable;
	}
	
	public void outACommunicatorDeclaration(ACommunicatorDeclaration node){
    	String name=node.getCommunicatorName().getText();
    	
    	// test for declaration unicity
        if (symbolTable.declarations.put(name, node) != null) {
            errorRedefined(node.getCommunicatorName(), name);
        }
    	    	
    	//test for communicator unicity
    	if(communicators.put(name,node) != null){
    		errorRedefined(node.getCommunicatorName(), name);
    	}
    }
            
    public void outAModuleDeclaration(AModuleDeclaration node) {
        final String name = node.getModuleName().getText();

        //test for declaration unicity
        if (symbolTable.declarations.put(name, node) != null) {
            errorRedefined(node.getModuleName(), name);
        }
        
        ModuleSymbolTable moduleSymbolTable=new ModuleSymbolTable(node, symbolTable);
        node.apply(moduleSymbolTable);
        
        // test for module unicity
        if (modules.put(name, moduleSymbolTable) != null) {
            errorRedefined(node.getModuleName(), name);
        }
    }
}
