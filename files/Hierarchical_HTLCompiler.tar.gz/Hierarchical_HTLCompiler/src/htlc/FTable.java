/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package htlc;

import htlc.analysis.DepthFirstAdapter;
import htlc.node.AActualPorts;
import htlc.node.AActuatorDeviceDriver;
import htlc.node.ACommunicatorDeclaration;
import htlc.node.ACommunicatorInstance;
import htlc.node.AConcreteActualPort;
import htlc.node.AFormalPort;
import htlc.node.AFormalPorts;
import htlc.node.AModeDeclaration;
import htlc.node.AModeSwitch;
import htlc.node.AModuleDeclaration;
import htlc.node.APortDeclaration;
import htlc.node.AProgramDeclaration;
import htlc.node.AProgramDeclarationList;
import htlc.node.ASensorDeviceDriver;
import htlc.node.AStatePort;
import htlc.node.ASwitchPort;
import htlc.node.ATaskDeclaration;
import htlc.node.ATaskFunction;
import htlc.node.ATaskInvocation;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.ListIterator;
import java.util.Map;


/**
 * 
 * This class implements code generation of the functionality wrappers. A
 * functionality wrapper is a procedure without arguments. The target machine
 * will invoke and schedule wrappers.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 * 		   Daniel Iercan, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class FTable extends CodeGen {
	public static final String TYPE_STATE="state";
	public static final String TYPE_INPUT="input";
	public static final String TYPE_OUTPUT="output";
	
    private final Hashtable taskTable = new Hashtable();

    private final Hashtable driverTable = new Hashtable();

    private final Hashtable conditionTable = new Hashtable();

    private final Hashtable portTable = new Hashtable();

    private final ArrayList orderedTasks = new ArrayList();

    private final ArrayList orderedDrivers = new ArrayList();

    private final ArrayList orderedConditions = new ArrayList();

    private final ArrayList orderedPorts = new ArrayList();

    private final Hashtable taskInputParameters = new Hashtable();
    
    private final Hashtable taskOutputParameters = new Hashtable();

    private DependencyTable dependencyTable;
    
    private final boolean pureGiotto;
    
    private InheritTable inheritTable;

    private String modeName;
    
    private String programName;
    
    private String moduleName;
    
    public FTable(SymbolTable symbolTable, DependencyTable dependencyTable, InheritTable inheritTable, boolean pureGiotto) {
        super(symbolTable, "ftable", "f_table.c", "f_table.h", "f_spec.txt");

        this.dependencyTable = dependencyTable;
        this.inheritTable = inheritTable;
        this.pureGiotto = pureGiotto;
    }

    // Action code

    public void emitCFileHeader(AProgramDeclarationList node) {
        emit("Header");

        emit("Include");
    }

    public void emitCFileBody(AProgramDeclarationList node) {
        int nTasks = 0;
        int nDrivers = 0;
        int nConditions = 0;
        int nPorts = 0;

        emit("TriggerTable");

        emit("TaskTableHeader");

        for (ListIterator iterator = getOrderedTasks(); iterator.hasNext(); nTasks++) {
            final String taskName = (String) iterator.next();

            if (nTasks != 0)
                emit("TableComma");

            emit("TaskTableElement", new String[] { taskName,
                    getTaskWrapperName(taskName) });
        }

        emit("TableEnd");

        emit("DriverTableHeader");

        for (ListIterator iterator = orderedDrivers.listIterator(); iterator
                .hasNext(); nDrivers++) {
            final String driverName = (String) iterator.next();

            final Driver driver = getDriver(driverName);

            if (nDrivers != 0)
                emit("TableComma");

            emit("DriverConditionTableElement", new String[] { driverName,
                    driver.wrapperName, Integer.toString(driver.protection) });
        }

        emit("TableEnd");

        emit("ConditionTableHeader");

        for (ListIterator iterator = orderedConditions.listIterator(); iterator
                .hasNext(); nConditions++) {
            String conditionName = (String) iterator.next();

            final Condition condition = getCondition(conditionName);

            if (nConditions != 0)
                emit("TableComma");

            emit("DriverConditionTableElement", new String[] { conditionName,
                    condition.wrapperName,
                    Integer.toString(condition.protection) });
        }

        emit("TableEnd");

        
        emit("PortTableHeader");

        for (ListIterator iterator = orderedPorts.listIterator(); iterator
                .hasNext(); nPorts++) {
            final String portName = (String) iterator.next();

            final Port port = getPort(portName);

            if (nPorts != 0)
                emit("TableComma");

            emit("PortTableElement", new String[] { portName, portName,
                    port.type });
        }

        emit("TableEnd");
    }

    public void emitHFileHeader(AProgramDeclarationList node) {
        emit("Header");
    }

    public void emitHFileBody(AProgramDeclarationList node) {
        final int nTasks = taskTable.size();
        final int nDrivers = driverTable.size();
        final int nConditions = conditionTable.size();
        final int nTriggers = 1;
        final int nPorts = portTable.size();

        emit("TableSize", new String[] { Integer.toString(nDrivers),
                Integer.toString(nConditions), Integer.toString(nTasks),
                Integer.toString(nTriggers), Integer.toString(nPorts) });
    }

    public void inAProgramDeclaration(AProgramDeclaration node){
    	programName = node.getProgramName().getText();
    }
    
    public void outAProgramDeclaration(AProgramDeclaration node){
    	programName = "";
    }
    
    public void inAModuleDeclaration(AModuleDeclaration node){
    	moduleName = node.getModuleName().getText();
    }
    
    public void outAModuleDeclaration(AModuleDeclaration node){
    	moduleName = "";
    }
    
    public void outACommunicatorDeclaration(ACommunicatorDeclaration node){
    	final String commPortName = node.getCommunicatorName().getText();
    	final String commPortType = node.getTypeName().getText();
    	final String genCommName = generateCommunicatorPortName(programName, commPortName);
    	
    	if(!portTable.containsKey(genCommName)){
    		orderedPorts.add(genCommName);

            final int nPorts = portTable.size();

            final Port port = new Port(genCommName, nPorts, commPortType);

            portTable.put(genCommName, port);

            emit("PortAllocation", new String[] { commPortType,
                        genCommName });
            
            emit("CR");
            
			final String initializationDriverName = node
			  		.getInitDriver().getText();
			final String initName = generateInitName(initializationDriverName);
			
			final String generatedDriverName = generateName(genCommName,
					              initName);

	        if (!driverTable.containsKey(generatedDriverName)) {
	        	orderedDrivers.add(generatedDriverName);
	
	        	final int nDrivers = driverTable.size();
		
	        	final Driver driver = new Driver(generatedDriverName, nDrivers,
	                  0);
	
	        	driverTable.put(generatedDriverName, driver);
	
	        	emit("DriverWrapperHeader", new String[] { driver.wrapperName,Integer.toString(driverTable.size()-1) });
	
	        	emit("ImplementationBegin",
	                  new String[] { initializationDriverName });
	
	        	emit("PortParameter", new String[] { genCommName });
	
	        	emit("ImplementationEnd");
	
	        	emit("WrapperEnd");
	        }
    	}
    	else
         throw new RuntimeException("Ambiguous general communicator port name.");
    	
    }
       
    public void outATaskDeclaration(ATaskDeclaration node){
    	 final String taskName = generateTaskName(programName, moduleName, node.getTaskName().getText());
  
         if(Utils.isAbstract(node)){
        	 return;
         }
         
         if (!taskTable.containsKey(taskName)) {
             final int nTasks = taskTable.size();
 
             // 64 is sizeof(unsigned long long), which is the type of the active tasks
             // bitfield.
             if (nTasks > 63)
                 throw new RuntimeException("Too many tasks: " + nTasks + ".");
 
             orderedTasks.add(taskName);
 
             final Task task = new Task(taskName, nTasks);
 
             taskTable.put(taskName, task);
 
             // Must be called after putting task into the table because we need
             // to get the task's index
             node.apply(new GenTaskPortAllocation(taskName));
 
             emit("TaskWrapperHeader", new String[] { task.wrapperName });
             
             String function=((ATaskFunction)node.getTaskFunction()).getFunctionName().getText();
             
             emit("ImplementationBegin", new String[] { function });
             
             node.apply(new GenerateTaskParameters(taskName));
             
             emit("ImplementationEnd");
             
             if(!pureGiotto){
            	 node.apply(new GenTaskPortSend(taskName));
             }
             
             emit("TaskWrapperEnd");
         } else
             throw new RuntimeException("Ambiguous task names.");
    }

    private class GenTaskPortSend extends DepthFirstAdapter{
    	
        private String taskName;

        private String type;
        
        private boolean inAOutputFormalList=false;
        
        public GenTaskPortSend(String taskName) {
            this.taskName = taskName;
            type=TYPE_OUTPUT;
        }
        
        public void inAFormalPorts(AFormalPorts node){
        	if(((ATaskDeclaration)node.parent()).getOutputFormalPorts()==node){
        		inAOutputFormalList=true;
        	}
        	else{
        		inAOutputFormalList=false;
        	}
        }
        
        public void outAFormalPort(AFormalPort node){
        	if(inAOutputFormalList){
	        	final String portName = node.getPortName().getText();
	
	            final String generatedPortName = generateTaskPortName(
	                    taskName, type, portName);
	            
	            emit("SendPortToAll", new String[] {""+orderedPorts.indexOf(generatedPortName)});
        	}
        }
    }
    
    private class GenTaskPortAllocation extends DepthFirstAdapter {
    	    	
        private String taskName;

        private String type;
        
        private boolean inAInputFormalList=false;
        
        final private ArrayList inputParameters = new ArrayList();
        
        final private ArrayList outputParameters = new ArrayList();

        public GenTaskPortAllocation(String taskName) {
            this.taskName = taskName;
        }

        public void inATaskDeclaration(ATaskDeclaration node){
        	type=TYPE_INPUT;
        	node.getInputFormalPorts().apply(new AllocatePorts());
        	
        	type=TYPE_STATE;
        	node.getStateFormalPorts().apply(new AllocatePorts());
        	
        	type=TYPE_OUTPUT;
        	node.getOutputFormalPorts().apply(new AllocatePorts());
        }
        
        class AllocatePorts extends DepthFirstAdapter{
            private void generatePort(String generatedPortName,
                    String portType) {
                if (!portTable.containsKey(generatedPortName)) {
                    orderedPorts.add(generatedPortName);

                    final int nPorts = portTable.size();

                    final Port port = new Port(generatedPortName, nPorts,
                            portType);

                    portTable.put(generatedPortName, port);
                    
                    emit("PortAllocation", new String[] { portType,
                            generatedPortName });

                } else
                    throw new RuntimeException(
                            "Ambiguous input or state port name.");
            }

            public void outAStatePort(AStatePort node) {
                final String portName = node.getStateName().getText();
                final String portType = node.getTypeName().getText();

                final String generatedPortName = generateTaskPortName(
                        taskName, type, portName);

                inputParameters.add(generatedPortName);

                generatePort(generatedPortName, portType);
                
                emit("CR");
                
				final String initializationDriverName = node
				  		.getInitDriver().getText();
				final String initName = generateInitName(initializationDriverName);
				
				final String generatedDriverName = generateName(generatedPortName,
						              initName);

		        if (!driverTable.containsKey(generatedDriverName)) {
		        	orderedDrivers.add(generatedDriverName);
		
		        	final int nDrivers = driverTable.size();
		
		        	final int taskIndex = getTaskIndex(taskName);
		
		        	final Driver driver = new Driver(generatedDriverName, nDrivers,
		                  1 << taskIndex);
		
		        	driverTable.put(generatedDriverName, driver);
		
		        	emit("DriverWrapperHeader", new String[] { driver.wrapperName,Integer.toString(driverTable.size()-1) });
		
		        	emit("ImplementationBegin",
		                  new String[] { initializationDriverName });
		
		        	emit("PortParameter", new String[] { generatedPortName });
		
		        	emit("ImplementationEnd");
		
		        	emit("WrapperEnd");
		        } 
            }
            
            public void inAFormalPorts(AFormalPorts node){
            	if(((ATaskDeclaration)node.parent()).getInputFormalPorts()==node){
            		inAInputFormalList=true;
            	}
            	else{
            		inAInputFormalList=false;
            	}
            }
            
            public void outAFormalPort(AFormalPort node) {
                final String portName = node.getPortName().getText();
                final String portType = node.getTypeName().getText();

                final String generatedPortName = generateTaskPortName(
                        taskName, type, portName);

                if(inAInputFormalList){
                	inputParameters.add(generatedPortName);
                }
                else{
                	outputParameters.add(generatedPortName);
                }

                generatePort(generatedPortName, portType);
            }
        }
        
        public void outATaskDeclaration(ATaskDeclaration node) {
            taskInputParameters.put(taskName, inputParameters);
            taskOutputParameters.put(taskName, outputParameters);
        }
    }
    
    class GenerateTaskParameters extends DepthFirstAdapter{
    	private String taskName;

        private String type;
        
        private boolean firstParameter=true;
         
        public GenerateTaskParameters(String taskName) {
        	this.taskName = taskName;
        }

        public void inATaskDeclaration(ATaskDeclaration node){
        	type=TYPE_INPUT;
         	node.getInputFormalPorts().apply(new GenerateParameters());
         	
         	type=TYPE_STATE;
         	node.getStateFormalPorts().apply(new GenerateParameters());
         	
         	type=TYPE_OUTPUT;
         	node.getOutputFormalPorts().apply(new GenerateParameters());
        }
         
        class GenerateParameters extends DepthFirstAdapter{
 
             public void outAStatePort(AStatePort node) {
                 final String portName = node.getStateName().getText();

                 final String generatedPortName = generateTaskPortName(
                         taskName, type, portName);
                 
                 if(!firstParameter)
                	 emit("ParameterComma");
                 else
                	 firstParameter=false;
                 
                 emit("PortParameter", new String[] { generatedPortName });

             }
             
             public void outAFormalPort(AFormalPort node) {
                 final String portName = node.getPortName().getText();
                 
                 final String generatedPortName = generateTaskPortName(
                         taskName, type, portName);

                 if(!firstParameter)
                	 emit("ParameterComma");
                 else
                	 firstParameter=false;
                 
                 emit("PortParameter", new String[] { generatedPortName });
             }
         }
    }

    public void inAModeDeclaration(AModeDeclaration node){
    	modeName = node.getModeName().getText();
    }
    
    public void outATaskInvocation(ATaskInvocation node){
    	if(!Utils.isAbstract((ATaskDeclaration)((ModuleSymbolTable)((ProgramSymbolTable)symbolTable.programs.get(programName)).modules.get(moduleName)).tasks.get(node.getTaskName().getText())))
    		node.apply(new GenerateCopyDrivers(programName, moduleName, modeName, generateTaskName(programName, moduleName, node.getTaskName().getText())));
    }
    
    private String[] getCommunicatorNameAndType(String comm){
		String[] rez = new String[2];
		
		String program = programName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(comm)) {
				rez[0] = generateCommunicatorPortName(program, comm);
				rez[1] = ((ACommunicatorDeclaration)pSymbolTable.communicators.get(comm)).getTypeName().getText();
				break;
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return rez;
	}
    
    private void generateCopyDriver(String type, String source, String dest, String generatedDriverName){
		final String copyDriverName = generateCopyName(type);
        if (!driverTable.containsKey(generatedDriverName)) {
            orderedDrivers.add(generatedDriverName);

            final int nDrivers = driverTable.size();

            final Driver driver = new Driver(generatedDriverName, nDrivers, 0);

            driverTable.put(generatedDriverName, driver);

            emit("DriverWrapperHeader", new String[] { driver.wrapperName,Integer.toString(driverTable.size()-1) });
	
            emit("ImplementationBegin", new String[] { copyDriverName });

            emit("PortParameter", new String[] { source });

            emit("ParameterComma");

            emit("PortParameter", new String[] { dest });

            emit("ImplementationEnd");
            
            emit("WrapperEnd");
        } else
            throw new RuntimeException(
                "Ambiguous output port copy driver name.");
	}
    
    private String getPortSourceName(String realTaskName, int localInPortNo, String realPortName){
    	ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(programName);
		ModuleSymbolTable mSymbolTable=(ModuleSymbolTable)pSymbolTable.modules.get(moduleName);
		//AModeDeclaration modeDecl=(AModeDeclaration)mSymbolTable.modes.get(modeName);
		Map modeDep=(Map)dependencyTable.taskDependencies.get(programName+"."+moduleName+"."+modeName);
		ArrayList taskDep=(ArrayList)modeDep.get(realTaskName);
		ATaskInvocation depTaskInvoke=(ATaskInvocation)taskDep.get(localInPortNo);
		FindFormalPortIndex findFormalPortIndex=new FindFormalPortIndex(realPortName);
		depTaskInvoke.apply(findFormalPortIndex);
		
		ATaskDeclaration taskDecl=(ATaskDeclaration)mSymbolTable.tasks.get(depTaskInvoke.getTaskName().getText());
		ScopedSymbolTable scoptedTable=new ScopedSymbolTable(symbolTable);
		taskDecl.apply(scoptedTable);
		//String formalPortName = (formalPort).getPortName().getText();
		
		ArrayList depFormalOutputs=(ArrayList)taskOutputParameters.get(generateTaskName(programName,moduleName,taskDecl.getTaskName().getText()));
		return (String)depFormalOutputs.get(findFormalPortIndex.portIndex);
    }
    
    class FindFormalPortIndex extends DepthFirstAdapter{
		private String portName;
		public int portIndex=0;    		
		private boolean inAOutputList=false;
		private boolean portFound=false;
		
		public FindFormalPortIndex(String portName){
			this.portName = portName;
		}
		    		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!portFound && inAOutputList){
				if(node.getPortName().getText().equals(portName)){
					portFound = true;
				}
				else{
					portIndex++;
				}
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(!portFound && inAOutputList){
				portIndex++;
			}
		}
	}
    
    class GenerateCopyDrivers extends DepthFirstAdapter{
    	private boolean inAActualInputList=false;
    	private String programName;
    	private String moduleName;
    	private String modeName;
    	private int inputNo=0;
    	private int outputNo=0;
    	private int localInPortNo=0;
    	private ArrayList formalInputPorts;
    	private ArrayList formalOutputPorts;
    	private String realTaskName;
    	
    	public GenerateCopyDrivers(String programName, String moduleName, String modeName, String taskName){
    		
    		formalInputPorts = (ArrayList)taskInputParameters.get(taskName);
    		formalOutputPorts = (ArrayList)taskOutputParameters.get(taskName);
    		this.programName = programName;
    		this.moduleName = moduleName;
    		this.modeName = modeName;
    	}
    	
    	public void inATaskInvocation(ATaskInvocation node){
    		realTaskName=node.getTaskName().getText();
    	}
    	
    	public void inAActualPorts(AActualPorts node){
    		if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAActualInputList=true;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAActualInputList=false;
    		}
    	}
    	
    	private void generateADriver(String type, String source, String dest, String generatedName){
    		final String copyDriverName = generateCopyName(type);
    		
    		String generatedDriverName = generateName(generatedName, copyDriverName);
    		generateCopyDriver(type,source,dest,generatedDriverName);
    	}
    	
    	private void generateSDriver(String type, String source, String dest, String generatedName){
    		final String copyDriverName = generateCopyName(type);
    		
    		String generatedDriverName = generateName(generatedName, copyDriverName);
    		generateCopyDriver(type,source,dest,generatedDriverName);
    	}
    	    	
    	public void outAConcreteActualPort(AConcreteActualPort node){
    		String name = node.getPortName().getText();
    		ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(programName);
			ModuleSymbolTable mSymbolTable=(ModuleSymbolTable)pSymbolTable.modules.get(moduleName);
			APortDeclaration portDecl = (APortDeclaration)mSymbolTable.ports.get(node.getPortName().getText());
			String type=portDecl.getPortType().getText();
    		if(inAActualInputList){    			
    			generateSDriver(type, getPortSourceName(realTaskName, localInPortNo, node.getPortName().getText()), (String)formalInputPorts.get(inputNo), 
    					generateCopyDriver(programName, moduleName, modeName, realTaskName, name, inputNo, "input"));
    			inputNo++;
    			localInPortNo++;
    		}
    		else{
    			//generate init drivers
    			
    			final String initializationDriverName = portDecl.getInitDriver().getText(); 
    			final String initName = generateInitName(initializationDriverName);
    			String sufix = generateName(programName, moduleName, modeName);
    			sufix = generateName(sufix, realTaskName, node.getPortName().getText());
		
    			final String generatedDriverName = generateName(sufix,initName);
    			
		        if (!driverTable.containsKey(generatedDriverName)) {
		        	orderedDrivers.add(generatedDriverName);
		
		        	final int nDrivers = driverTable.size();
			
		        	final Driver driver = new Driver(generatedDriverName, nDrivers,
		                  0);
		
		        	driverTable.put(generatedDriverName, driver);

		        	emit("DriverWrapperHeader", new String[] { driver.wrapperName,Integer.toString(driverTable.size()-1) });

		        	emit("ImplementationBegin",
		        			new String[] { initializationDriverName });

		        	emit("PortParameter", new String[] { (String)formalOutputPorts.get(outputNo) });

		        	emit("ImplementationEnd");

		        	emit("WrapperEnd");
		        }
    			outputNo++;
    		}
    	}
    	
    	public void outACommunicatorInstance(ACommunicatorInstance node){
    		String[] commInfo=getCommunicatorNameAndType(node.getCommunicatorPortName().getText());
    		String name = node.getCommunicatorPortName().getText();
    		if(inAActualInputList){
    			generateSDriver(commInfo[1], commInfo[0], (String)formalInputPorts.get(inputNo),
    					generateCopyDriver(programName, moduleName, modeName, realTaskName, name, inputNo, "input"));
    			inputNo++;
    		}
    		else{
    			generateADriver(commInfo[1], (String)formalOutputPorts.get(outputNo), commInfo[0],
    					generateCopyDriver(programName, moduleName, modeName, realTaskName, name, outputNo, "output"));
    			outputNo++;
    		}
    	}
    }
    
    public void outASensorDeviceDriver(ASensorDeviceDriver node){
    	final String generatedDriverName = generateDevDriverName(programName, moduleName, modeName, node.getDriverName().getText());
        if (!driverTable.containsKey(generatedDriverName)) {
            orderedDrivers.add(generatedDriverName);

            final int nDrivers = driverTable.size();

            final Driver driver = new Driver(generatedDriverName, nDrivers, 0);

            driverTable.put(generatedDriverName, driver);

            emit("DriverWrapperHeader", new String[] { driver.wrapperName,Integer.toString(driverTable.size()-1) });
	
            emit("ImplementationBegin", new String[] { node.getDriverName().getText() });

            emit("PortParameter", new String[] { getCommunicatorNameAndType(node.getCommunicatorName().getText())[0] });

            emit("ImplementationEnd");
            
            emit("WrapperEnd");
        } else
            throw new RuntimeException(
                "Ambiguous output port copy driver name.");
    }
    
    public void outAActuatorDeviceDriver(AActuatorDeviceDriver node){
    	final String generatedDriverName = generateDevDriverName(programName, moduleName, modeName, node.getDriverName().getText());
        if (!driverTable.containsKey(generatedDriverName)) {
            orderedDrivers.add(generatedDriverName);

            final int nDrivers = driverTable.size();

            final Driver driver = new Driver(generatedDriverName, nDrivers, 0);

            driverTable.put(generatedDriverName, driver);

            emit("DriverWrapperHeader", new String[] { driver.wrapperName,Integer.toString(driverTable.size()-1) });
	
            emit("ImplementationBegin", new String[] { node.getDriverName().getText() });

            emit("PortParameter", new String[] { getCommunicatorNameAndType(node.getCommunicatorName().getText())[0] });

            emit("ImplementationEnd");
            
            emit("WrapperEnd");
        } else
            throw new RuntimeException(
                "Ambiguous output port copy driver name.");
    }
    
    public void outAModeSwitch(AModeSwitch node){
    	ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(programName);
    	ModuleSymbolTable mSymbolTable=(ModuleSymbolTable)pSymbolTable.modules.get(moduleName);
    	String generatedConditionName=generateConditionName(
    			generateModeName(programName, moduleName, modeName), 
    			node.getDestinationMode().getText(),
    			node.getConditionFunction().getText()); 
//    	//allocate ports
//    	node.apply(new AlocateModeSwitchPorts(generatedConditionName,mSymbolTable));
    	
    	//generate condition
    	generateCondition(node, generatedConditionName, mSymbolTable);
    }
    
    private void generateCondition(AModeSwitch node, String generatedCondName, ModuleSymbolTable mSymbolTable){
    	if (!conditionTable.containsKey(generatedCondName)) {
            orderedConditions.add(generatedCondName);

            final int nConditions = conditionTable.size();

            final Condition condition = new Condition(generatedCondName,
                    nConditions, 0);

            conditionTable.put(generatedCondName, condition);

            node.apply(new GenConditionWrapper(
                    condition.wrapperName, mSymbolTable));
        }
    }
    
    private class GenConditionWrapper extends DepthFirstAdapter {
        private String conditionWrapperName;

        private final ModuleSymbolTable moduleSymbolTable;
        
        private String destMode;
        
        public GenConditionWrapper(String conditionWrapperName, ModuleSymbolTable moduleSymbolTable) {
            this.conditionWrapperName = conditionWrapperName;
            this.moduleSymbolTable=moduleSymbolTable;
        }

        public void inAModeSwitch(AModeSwitch node) {
            emit("ConditionWrapperHeader",
                    new String[] { conditionWrapperName });
            emit("IfGuard", new String[] { node.getConditionFunction().getText() });

            destMode=node.getDestinationMode().getText();
            
            node.apply(new GenConditionImplementationParameter());
        }

        private class GenConditionImplementationParameter extends
                DepthFirstAdapter {
            private int nParameter = 0;
            private int inLocalPortNo=0;

            public void outASwitchPort(ASwitchPort node) {
                final String portName = node.getPortName().getText();

                if (nParameter != 0)
                    emit("ParameterComma");

                if (moduleSymbolTable.ports.containsKey(portName)) {
                     emit("PortParameter", new String[] { getPortSourceName(destMode,inLocalPortNo,portName) });
                    inLocalPortNo++;
                } else
                    emit("PortParameter", new String[] { getCommunicatorNameAndType(portName)[0] });

                nParameter++;
            }
        }

        public void outAModeSwitch(AModeSwitch node) {
        	emit("ImplementationEnd");
            emit("WrapperEnd");
        }
    }

    
    class AlocateModeSwitchPorts extends DepthFirstAdapter{
    	
    	private String generatedConditionName;
    	private ModuleSymbolTable moduleSymbolTable;    	
    	
    	public AlocateModeSwitchPorts(String generatedCoditionName, ModuleSymbolTable moduleSymbolTable){
    		this.generatedConditionName = generatedCoditionName;
    		this.moduleSymbolTable = moduleSymbolTable;
    	}
    	
    	public void outASwitchPort(ASwitchPort node){
    		String portRealName = node.getPortName().getText();
    		String generatedPortName = generateCommunicatorPortName(generatedConditionName, node.getPortName().getText());
    		
    		String portType;
    		
    		if(moduleSymbolTable.ports.containsKey(portRealName)){
    			portType = ((APortDeclaration)moduleSymbolTable.ports.get(portRealName)).getPortType().getText();
    		}
    		else{
    			portType = getCommunicatorNameAndType(portRealName)[1];
    		}
    		
    		 if (!portTable.containsKey(generatedPortName)) {
                 orderedPorts.add(generatedPortName);

                 final int nPorts = portTable.size();

                 final Port port = new Port(generatedPortName, nPorts,
                         portType);

                 portTable.put(generatedPortName, port);
                 
                 emit("PortAllocation", new String[] { portType,
                         generatedPortName });

             } else
                 throw new RuntimeException(
                         "Ambiguous input or state port name.");
    		
    	}
    	
    }

    // Table code

    private class Task {
        private String name;

        private int index;

        private String wrapperName;

        public Task(String name, int index) {
            this.name = name;
            this.index = index;

            this.wrapperName = generateTaskWrapperName(name);
        }

        private String generateTaskWrapperName(String taskName) {
            return "task_" + taskName;
        }
        
        public String toString(){
        	return name+" "+index;
        }
    }

    private class Driver {
        private String name;

        private int index;

        private String wrapperName;

        private int protection;

        public Driver(String name, int index, int protection) {
            this.name = name;
            this.index = index;

            this.wrapperName = generateDriverWrapperName(name);

            this.protection = protection;
        }

        private String generateDriverWrapperName(String driverName) {
            return "driver_" + driverName;
        }
        
        public String toString(){
        	return name+" "+index;
        }
    }

    private class Condition {
        private String name;

        private int index;

        private String wrapperName;

        private int protection;

        public Condition(String name, int index, int protection) {
            this.name = name;
            this.index = index;

            this.wrapperName = generateConditionWrapperName(name);

            this.protection = protection;
        }

        private String generateConditionWrapperName(String conditionName) {
            return "condition_" + conditionName;
        }
        
        public String toString(){
        	return name+" "+index;
        }
    }

    private class Port {
        private String name;

        private int index;

        private String type;

        public Port(String name, int index, String type) {
            this.name = name;
            this.index = index;
            this.type = type;
        }
        
        public String toString(){
        	return name+" "+index;
        }
    }

    // Name generation
    private String generateCommunicatorPortName(String program, String port){
    	return generateName(program, port);
    }
    
    private String generateTaskName(String program, String module, String task){
    	return generateName(program, module, task);
    }
    
    private String generateTaskPortName(String task, String type, String port){
    	return generateName(task, type, port);
    }
    
    private String generateInputStatePortName(String prefix, String postfix) {
        return generateName(prefix, postfix);
    }

    private String generateCopyName(String portType) {
        return generateName("copy", portType);
    }
    
    private String generateDevDriverName(String program, String module, String mode, String devDriver){
    	return generateName(generateName(program, module, mode), devDriver);
    }
    
    private String generateModeName(String program, String module, String mode){
    	return generateName(program, module, mode);
    }
    
    private String generateConditionName(String generatedModeName, String destMode, String condition){
    	return generateName(generatedModeName, destMode, condition);
    }
    
    private String generateCopyDriver(String program, String module, String mode, String task, String actualParam, int position, String type){
    	String name=generateName(program, module, mode);
    	name = generateName(name, task, actualParam);
    	name = generateName(name, type, Integer.toString(position));
    	
    	return name;
    }
        
    // Task access

    private Task getTask(String program, String module, String taskName) {
        return (Task) taskTable.get(generateName(program, module, taskName));
    }

    public String getTaskWrapperName(String program, String module, String taskName) {
        return getTask(program, module, taskName).wrapperName;
    }

    public int getTaskIndex(String program, String module, String taskName) {
        return getTask(program, module, taskName).index;
    }
    
    private Task getTask(String taskName) {
        return (Task) taskTable.get(taskName);
    }

    public String getTaskWrapperName(String taskName) {
        return getTask(taskName).wrapperName;
    }

    public int getTaskIndex(String taskName) {
        return getTask(taskName).index;
    }

    public ListIterator getOrderedTasks() {
        return orderedTasks.listIterator();
    }

    // Init port driver access

    private Driver getInitPortDriver(String program, String module, String mode, String task, String port, String driver) {
    	final String initializationDriverName = driver; 
		final String initName = generateInitName(initializationDriverName);
		String sufix = generateName(program, module, mode);
		sufix = generateName(sufix, task, port);
        return (Driver) driverTable.get(generateName(sufix, initName));
    }

    public String getInitPortDriverWrapperName(String program, String module, String mode, String task, String port, String driver) {
        return getInitPortDriver(program, module, mode, task, port, driver).wrapperName;
    }

    public int getInitPortDriverIndex(String program, String module, String mode, String task, String port, String driver) {
        return getInitPortDriver(program, module, mode, task, port, driver).index;
    }
    
    

    // Copy driver access

    private Driver getCopyDriver(String program, String module, String mode, String task, String actualPort, int position, String portType, String modifier) {
    	String driverName = generateCopyDriver(program, module, mode, task, actualPort, position, modifier);
    	driverName = generateName(driverName, generateCopyName(portType));
        return (Driver) driverTable.get(driverName);
    }

    public String getCopyDriverWrapperName(String program, String module, String mode, String task, String actualPort, int position, String portType, String modifier) {
        return getCopyDriver(program, module, mode, task, actualPort, position, portType, modifier).wrapperName;
    }

    public int getCopyDriverIndex(String program, String module, String mode, String task, String actualPort, int position, String portType, String modifier) {
        return getCopyDriver(program, module, mode, task, actualPort, position, portType, modifier).index;
    }

    private Driver getDeviceDriver(String program, String module, String mode, String devDrv) {
    	String driverName = generateName(program, module, mode);
    	driverName = generateName(driverName, devDrv);
        return (Driver) driverTable.get(driverName);
    }

    public String getDeviceDriverWrapperName(String program, String module, String mode, String devDrv) {
        return getDeviceDriver(program, module, mode, devDrv).wrapperName;
    }

    public int getDeviceDriverIndex(String program, String module, String mode, String devDrv) {
        return getDeviceDriver(program, module, mode, devDrv).index;
    }

	private Driver getInitStateDriver(String programName, String moduleName , String task ,String portName, String type, String initDriver){
		String genTaskName=generateTaskName(programName, moduleName, task);
		String genPortName = generateTaskPortName(genTaskName, type, portName);
		String keyPort = generateName(genPortName, generateInitName(initDriver));
    	return (Driver)driverTable.get(keyPort);
    }
    
    public String getInitStateDriverWrapperName(String programName,String module,String task, String portName, String type, String initDriver){
    	return getInitStateDriver(programName, module, task, portName, type, initDriver).wrapperName; 
    }
    
    public int getInitStateDriverIndex(String programName,String module,String task, String portName, String type, String initDriver){
    	return getInitStateDriver(programName, module, task, portName, type, initDriver).index; 
    }
    
    private Driver getInitCommDriver(String programName, String commName, String initDriver){
    	return (Driver)driverTable.get(generateName(programName, commName, generateInitName(initDriver)));
    }
    
    public String getInitCommDriverWrapperName(String programName, String commName, String initDriver){
    	return getInitCommDriver(programName, commName, initDriver).wrapperName; 
    }
    
    public int getInitCommDriverIndex(String programName, String commName, String initDriver){
    	return getInitCommDriver(programName, commName, initDriver).index; 
    }
    
    private Driver getInitStateDriver(String taskName, String prefix,
            String postfix) {
        return (Driver) driverTable.get(generateName(
                generateInputStatePortName(taskName, prefix),
                generateInitName(postfix)));
    }

    public String getInitStateDriverWrapperName(String taskName, String prefix,
            String postfix) {
        return getInitStateDriver(taskName, prefix, postfix).wrapperName;
    }

    public int getInitStateDriverIndex(String taskName, String prefix,
            String postfix) {
        return getInitStateDriver(taskName, prefix, postfix).index;
    }
    

    // Driver access

    private Driver getDriver(String generatedDriverName) {
        return (Driver) driverTable.get(generatedDriverName);
    }

    private Driver getDriver(String prefix, String postfix) {
        return getDriver(generateName(prefix, postfix));
    }

    private Driver getDriver(String prefix, String postfix, String modeName) {
        return getDriver(generateName(modeName + "_" + prefix, postfix));
    }

    public String getDriverWrapperName(String prefix, String postfix) {
        return getDriver(prefix, postfix).wrapperName;
    }

    public String getDriverWrapperName(String prefix, String postfix,
            String modeName) {
        return getDriver(prefix, postfix, modeName).wrapperName;
    }

    public int getDriverIndex(String prefix, String postfix) {
        return getDriver(prefix, postfix).index;
    }

    public int getDriverIndex(String prefix, String postfix, String modeName) {
        return getDriver(prefix, postfix, modeName).index;
    }

    // Condition access

    private Condition getCondition(String generatedConditionName) {
        return (Condition) conditionTable.get(generatedConditionName);
    }

    private Condition getCondition(String prefix, String postfix,
            String modeName) {
        return getCondition(generateName(modeName + "_" + prefix, postfix));
    }

    public String getConditionWrapperName(String prefix, String postfix,
            String modeName) {
        return getCondition(prefix, postfix, modeName).wrapperName;
    }
    
    public int getConditionIndex(String prefix, String postfix, String modeName) {
        return getCondition(prefix, postfix, modeName).index;
    }
    
    private Condition getCondition(String program, String module, String mode, String destMode, String conditionName) {
        return (Condition) conditionTable.get(generateConditionName(generateName(program, module, mode), destMode, conditionName));
    }
 
    public String getConditionWrapperName(String program, String module, String mode, String destMode, String conditionName) {
        return getCondition(program, module, mode, destMode, conditionName).wrapperName;
    }

    public int getConditionIndex(String program, String module, String mode, String destMode, String conditionName) {
        return getCondition(program, module, mode, destMode, conditionName).index;
    }

    // Port access

    private Port getPort(String portName) {
        return (Port) portTable.get(portName);
    }
}
