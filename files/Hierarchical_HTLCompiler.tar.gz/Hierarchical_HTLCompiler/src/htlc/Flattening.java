/*
 * Created on May 7, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */

package htlc;

import htlc.analysis.DepthFirstAdapter;
import htlc.node.AActuatorDeviceDriver;
import htlc.node.AActuatorDeviceDriverList;
import htlc.node.ACommunicatorDeclaration;
import htlc.node.ACommunicatorDeclarationList;
import htlc.node.AModeDeclaration;
import htlc.node.AModeDeclarationList;
import htlc.node.AModeSwitch;
import htlc.node.AModeSwitchList;
import htlc.node.AModuleDeclaration;
import htlc.node.AModuleDeclarationList;
import htlc.node.APortDeclaration;
import htlc.node.APortDeclarationList;
import htlc.node.AProgramDeclaration;
import htlc.node.ARefineProgram;
import htlc.node.ASensorDeviceDriver;
import htlc.node.ASensorDeviceDriverList;
import htlc.node.ASwitchPort;
import htlc.node.ASwitchPortList;
import htlc.node.ASwitchPorts;
import htlc.node.ATaskDeclaration;
import htlc.node.ATaskDeclarationList;
import htlc.node.ATaskInvocation;
import htlc.node.ATaskInvocationList;
import htlc.node.Node;
import htlc.node.PRefineProgram;
import htlc.node.TCommunicator;
import htlc.node.TIdent;
import htlc.node.TLBrace;
import htlc.node.TLPar;
import htlc.node.TMode;
import htlc.node.TModule;
import htlc.node.TNumber;
import htlc.node.TPeriod;
import htlc.node.TPort;
import htlc.node.TRBrace;
import htlc.node.TRPar;
import htlc.node.TSemicolon;
import htlc.node.TStart;
import htlc.node.TSwitch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 *
 */
public class Flattening extends DepthFirstAdapter {
	
	private final SymbolTable symbolTable;
		
	private File pkgDir;
	private BufferedWriter file;
	private AProgramDeclaration program;
	private AModuleDeclaration module;
	
	public Flattening(SymbolTable symbolTable){
		this.symbolTable = symbolTable;
		
		pkgDir = new File(symbolTable.pkgDir, "Flattening");

		if (!pkgDir.exists()) {
			if (!pkgDir.mkdir()) {
				throw new RuntimeException("Unable to create "
						+ pkgDir.getAbsolutePath());
			}
		}
		
		try{
		file = new BufferedWriter(
				new FileWriter(new File(pkgDir, "flatten.tsl")));
		}
		catch(IOException e){
			throw new RuntimeException("flatten.tsl file could not be created.");
		}
	}
	
	private void writeNode(Node node){
		try{
			String tmp = node.toString().replaceAll(";", ";\n");
			tmp = tmp.replaceAll("\\}","}\n");
			tmp = tmp.replaceAll("\\{","{\n");
			file.write(tmp);
			file.flush();
		}
		catch(IOException e){
			
		}
	}
	
	public void inAProgramDeclaration(AProgramDeclaration node){
		program = node;
	}
	
	public void outAProgramDeclaration(AProgramDeclaration node){
		program = null;
		try{
			writeNode(node);
			file.close();
		}
		catch(IOException e){
			
		}
	}
	
	public void inAModuleDeclaration(AModuleDeclaration node){
		module = node;
	}
	
	public void outAModuleDeclaration(AModuleDeclaration node){
		module = null;
	}
		
	public void outAModeDeclaration(AModeDeclaration node){
		if(node.getRefineProgram() != null){
			AProgramDeclaration refProgram = ((ProgramSymbolTable)symbolTable.programs.get(((ARefineProgram)node.getRefineProgram()).getProgramName().getText())).program;
		
			flattenAndCovertToSingleModule(refProgram);
			mergeModeWithProgram(program, module, node, refProgram);
		}
	}
	
	private void flattenAndCovertToSingleModule(AProgramDeclaration program){
		TestLeaf testLeaf = new TestLeaf();
		program.apply(testLeaf);
		CountModules countModules = new CountModules();
		program.apply(countModules);
		ComputeDeclarations declarations = new ComputeDeclarations(countModules.modulesCount);
		program.apply(declarations);
		
		if(testLeaf.isLeaf && countModules.modulesCount==1){
			return;
		}
		
		if(testLeaf.isLeaf){
			int[] modesIndexes = createModesIndexes(countModules.modulesCount);
			LinkedList newModes = new LinkedList();
			combineModes(declarations.modeDeclarations, newModes, modesIndexes, declarations.maxIndexes);
			
			AModuleDeclaration module = new AModuleDeclaration(
					new TModule(),new TIdent(declarations.moduleName), null, new TStart(), new TIdent(declarations.startMode),
					new TLBrace(), new APortDeclarationList(new TPort(), declarations.portDeclarations), 
					new ATaskDeclarationList(declarations.taskDeclarations), new AModeDeclarationList(newModes), new TRBrace());
			
			LinkedList modules = new LinkedList();
			modules.add(module);
			
			program.getModuleDeclarationList().replaceBy(new AModuleDeclarationList(modules));
		}
		else{
			program.apply(new FlattenAndConvertToSingleModule());
			flattenAndCovertToSingleModule(program);
		}
	}
	
	private void mergeModeWithProgram(AProgramDeclaration program1, AModuleDeclaration module, AModeDeclaration mode, AProgramDeclaration program2){
		ComputeDeclarations declarations = new ComputeDeclarations(1);
		program2.apply(declarations);
		
		//copy mode elements to all modes in program2
		CopyModeToModes modeToModes;
		program2.apply(modeToModes = new CopyModeToModes(mode));
		
		//copy comm declarations from program2 to program1
		GetCommDeclarations commDecl = new GetCommDeclarations();
		program1.apply(commDecl);
		LinkedList commList = new LinkedList();
		commList.addAll(commDecl.commDeclarations);
		program2.apply(commDecl = new GetCommDeclarations());
		commList.addAll(commDecl.commDeclarations);
		
		if(program1.getCommunicatorDeclarationList()==null)
			program1.setCommunicatorDeclarationList(new ACommunicatorDeclarationList(new TCommunicator(), commList));
		else
			program1.getCommunicatorDeclarationList().replaceBy(new ACommunicatorDeclarationList(new TCommunicator(), commList));
		
		
		//copy port, tasks, mode decl from program2 module to module
		ComputeDeclarations declarations1 = new ComputeDeclarations(1);
		module.apply(declarations1);
		LinkedList list;
		
		//add ports
		list = new LinkedList();
		list.addAll(declarations1.portDeclarations);
		list.addAll(declarations.portDeclarations);
		if(module.getPortDeclarationList()==null){
			module.setPortDeclarationList(new APortDeclarationList(new TPort(), list));
		}
		else{
			module.getPortDeclarationList().replaceBy(new APortDeclarationList(new TPort(), list));
		}
		
		//add taks
		list = new LinkedList();
		list.addAll(declarations1.taskDeclarations);
		list.addAll(declarations.taskDeclarations);
		if(module.getTaskDeclarationList()==null){
			module.setTaskDeclarationList(new ATaskDeclarationList(list));
		}
		else{
			module.getTaskDeclarationList().replaceBy(new ATaskDeclarationList(list));
		}
		
		//update referencies
		module.apply(new UpdateReferences(modeToModes.startMode, mode.getModeName().getText()));
		if(module.getStartMode().getText().equals(mode.getModeName().getText()))
			module.getStartMode().replaceBy(new TIdent(modeToModes.startMode));
		
		//add modes
		list = new LinkedList();
		LinkedList modesList = (LinkedList)declarations1.modeDeclarations.get(0);
		modesList.remove(mode);
		list.addAll(modesList);
		list.addAll(modeToModes.modes);
		if(module.getModeDeclarationList()==null){
			module.setModeDeclarationList(new AModeDeclarationList(list));
		}
		else{
			module.getModeDeclarationList().replaceBy(new AModeDeclarationList(list));
		}
			
		program2.replaceBy(null);
	}
	
	private class UpdateReferences extends DepthFirstAdapter{
		private String newModeName;
		private String oldModeName;
		
		public UpdateReferences(String newName, String oldName){
			newModeName = newName;
			oldModeName = oldName;
		}
		
		public void outAModeSwitch(AModeSwitch node){
			if(node.getDestinationMode().getText().equals(oldModeName)){
				node.getDestinationMode().replaceBy(new TIdent(newModeName));
			}
		}
	}
	
	private class GetCommDeclarations extends DepthFirstAdapter{
		public final LinkedList commDeclarations = new LinkedList();
		
		public void outACommunicatorDeclaration(ACommunicatorDeclaration node){
			commDeclarations.add(node);
		}
	}
	
	private class CopyModeToModes extends DepthFirstAdapter{
		
		public final LinkedList modes = new LinkedList();
		public String startMode;
		
		private final LinkedList sensors = new LinkedList();
		private final LinkedList actuators = new LinkedList();
		private final LinkedList invocations = new LinkedList();
		private final LinkedList switches = new LinkedList();
		
		public CopyModeToModes(AModeDeclaration mode){
			mode.apply(new FetchModeElements(sensors, actuators, invocations, switches));
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			startMode = node.getStartMode().getText();
		}
		
		public void outAModeDeclaration(AModeDeclaration node){			
			final LinkedList sensors2 = new LinkedList();
			final LinkedList actuators2 = new LinkedList();
			final LinkedList invocations2 = new LinkedList();
			final LinkedList switches2 = new LinkedList();
			
			node.apply(new FetchModeElements(sensors2, actuators2, invocations2, switches2));
			
			final LinkedList sensors3 = new LinkedList();
			final LinkedList actuators3 = new LinkedList();
			final LinkedList invocations3 = new LinkedList();
			final LinkedList switches3 = new LinkedList();
			
			sensors3.addAll(Flattening.clone((LinkedList)sensors));
			sensors3.addAll(sensors2);
			
			actuators3.addAll(Flattening.clone((LinkedList)actuators));
			actuators3.addAll(actuators2);
			
			invocations3.addAll(Flattening.clone((LinkedList)invocations));
			invocations3.addAll(invocations2);
			
			switches3.addAll(Flattening.clone((LinkedList)switches));
			switches3.addAll(switches2);
			
			node.getSensorDeviceDriverList().replaceBy(new ASensorDeviceDriverList(sensors3));
			node.getActuatorDeviceDriverList().replaceBy(new AActuatorDeviceDriverList(actuators3));
			node.getTaskInvocationList().replaceBy(new ATaskInvocationList(invocations3));
			node.getModeSwitchList().replaceBy(new AModeSwitchList(switches3));
			
			modes.add(node);
		}
		
	}
	
	private static LinkedList clone(LinkedList list){
		LinkedList clonedList = new LinkedList();
		
		Iterator it = list.iterator();
		
		while(it.hasNext()){
			clonedList.add(((Node)it.next()).clone());
		}
		
		return clonedList;
	}
	
	private class FlattenAndConvertToSingleModule extends DepthFirstAdapter{
		private AProgramDeclaration program;
		private AModuleDeclaration module;
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			program = node;
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			program = null;
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			module = node;
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			module = null;
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			if(node.getRefineProgram() != null){
				AProgramDeclaration refProgram = ((ProgramSymbolTable)(symbolTable.programs.get(
						((ARefineProgram)node.getRefineProgram()).getProgramName().getText()))).program;
				
				flattenAndCovertToSingleModule(refProgram);
				mergeModeWithProgram(program, module, node, refProgram);
			}
		}
	}
	
	//create an array of integers initialized to zero
	private int[] createModesIndexes(int size){
		int[] indexes = new int[size];
		
		for(int i=0;i<size;i++){
			indexes[i] = 0;
		}
		
		return indexes;
	}
	
	//increment the last element in the array with carrage
	private boolean incrementIndexes(int[] indexes, int[] maxIndexes){
		int i;
		
		for (i=indexes.length-1; i>-1;i--){
			if(indexes[i] == (maxIndexes[i]-1)){
				indexes[i] = 0;
			}
			else{
				indexes[i]++;
				break;
			}
		}
		
		return i!=-1;
	}
	
	private void combineModes(LinkedList programModes, LinkedList newModes, int[] indexes, int[] maxIndexes){
		ArrayList modes = new ArrayList();
		
		for(int i=0; i<indexes.length; i++){
			modes.add(((LinkedList)programModes.get(i)).get(indexes[i]));
		}
		
		newModes.add(createSingleMode(modes));
		
		if(incrementIndexes(indexes, maxIndexes)){
			combineModes(programModes, newModes, indexes, maxIndexes);
		}
	}
	
	private AModeDeclaration createSingleMode(ArrayList modes){
		String modeName="";
		final LinkedList sensors = new LinkedList();
		final LinkedList actuators = new LinkedList();
		final LinkedList invocations = new LinkedList();
		LinkedList modeSwitches = new LinkedList();
		
		Iterator it = modes.iterator();
		TNumber period = null;
		while(it.hasNext()){
			AModeDeclaration mode = (AModeDeclaration)it.next();
			
			if(period==null)
				period = mode.getModePeriod();
			
			if(!modeName.equals("")){
				modeName+="_";
			}
			modeName += mode.getModeName().getText();
		}
		
		it = modes.iterator();
		while(it.hasNext()){
			AModeDeclaration mode = (AModeDeclaration)it.next();
			
			mode.apply(new FetchModeElements(sensors, actuators, invocations, modeSwitches));
			//updateSwitches(modeName, mode.getModeName().getText(), modeSwitches);
		}
		
		LinkedList newSwitches=new LinkedList();
		combineSwitches(modeName, modeSwitches, newSwitches, modeSwitches.size());
		
		PRefineProgram refProg = null;
		AModeDeclaration newMode = new AModeDeclaration(new TMode(), new TIdent(modeName), new TPeriod(),
				period, refProg , new TLBrace(), new ASensorDeviceDriverList(clone(sensors)), new AActuatorDeviceDriverList(clone(actuators)),
				new ATaskInvocationList(clone(invocations)), new AModeSwitchList(newSwitches), new TRBrace());
		
		return newMode;
	}
	
	//get the name of the parent mode of a mode switch
	private String getModeName(AModeSwitch modeSwitch){
		return ((AModeDeclaration)modeSwitch.parent().parent()).getModeName().getText();
	}
	
//	private void updateSwitches(String newMode, String crrMode, LinkedList switches){
//		final Iterator it=switches.iterator();
//		
//		while(it.hasNext()){
//			AModeSwitch modeSwitch = (AModeSwitch)it.next();
//			String newDestMode = modeSwitch.getDestinationMode().getText();
//			newDestMode = newMode.replace(crrMode, newDestMode);
//			modeSwitch.getDestinationMode().replaceBy(new TIdent(newDestMode));
//		}
//	}
	
	private void combineSwitches(String currentMode, LinkedList initList, LinkedList newList, int length){
		
		int[] indexes=createModesIndexes(length);
		boolean sw = true;
		
		//init indexies
		for(int i=0; i<length; i++){
			indexes[i] = i;
		}
		
		while(sw){
			LinkedList switchesToCombine = new LinkedList();
					
			for(int i=0; i < length;i++){
				switchesToCombine.add(initList.get(i));
			}
			
			AModeSwitch modeSwitch = createSwitch(switchesToCombine, currentMode); 
			
			if(newList!=null)
				newList.add(modeSwitch);
			
			sw = incrementIndexes(indexes, initList.size());
		}
		
		if(length>1){
			combineSwitches(currentMode, initList, newList, length-1);
		}
	}
	
	private boolean incrementIndexes(int[] indexes, int maxIndex){
		int carrage=1;
		int lastModifyIdx=0;
		
		for(int i=indexes.length-1; i > -1; i--){
			int tmp = 0; 
			
			if(indexes[i]==(maxIndex-(indexes.length-i)) && carrage==1 )
				tmp=1;
			
			indexes[i] = indexes[i]+carrage;
			
			carrage=tmp;
			
			if(tmp==1){
				lastModifyIdx = i;
			}
		}
		
		if(lastModifyIdx==0 || indexes[0]>(maxIndex - indexes.length)){
			return false;
		}
		
		for(int i=lastModifyIdx; i<indexes.length; i++){
			indexes[i]=indexes[i-1]+1;
		}
		
		return true;
	}
	
	private AModeSwitch createSwitch(LinkedList switches, String currentMode){
		String condition = "";
		String newMode = currentMode;
		
		Iterator it = switches.iterator();
		HashSet previousModes = new HashSet();
		LinkedList switchParam = new LinkedList();
		
		while(it.hasNext()){
			AModeSwitch oldSwitch = (AModeSwitch)it.next();
			String modeName = getModeName(oldSwitch);
			oldSwitch.apply(new GetModeSwitchParameters(switchParam));
			if(!condition.equals("")){
				condition += "_";
			}
			condition += oldSwitch.getConditionFunction().getText();
			
			String destMode = oldSwitch.getDestinationMode().getText();
			
			if(!previousModes.add(destMode)){
				return null;
			}
			
			newMode = newMode.replace(modeName, destMode);
		}
		
		return new AModeSwitch(new TSwitch(), new TLPar(), new TIdent(condition), 
				new ASwitchPorts(new TLPar(), new ASwitchPortList(switchParam), 
				new TRPar()), new TRPar(), new TIdent(newMode), new TSemicolon());
	}
	
	private class GetModeSwitchParameters extends DepthFirstAdapter{
		private final LinkedList listParam;
		
		public GetModeSwitchParameters(LinkedList listParam){
			this.listParam = listParam;
		}
		
		public void outASwitchPort(ASwitchPort node){
			listParam.add(node);
		}
	}
	
	//Test if the program is a leaf
	private class TestLeaf extends DepthFirstAdapter{
		public boolean isLeaf = true;
		
		public void outAModeDeclaration(AModeDeclaration node){
			if(node.getRefineProgram()!=null){
				isLeaf = false;
			}
		}
	}
	
	//compute the number of modules in a program
	public class CountModules extends DepthFirstAdapter{
		public int modulesCount=0;
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			modulesCount++;
		}
	}
	
	//compute all declarations in a mode
	private class ComputeDeclarations extends DepthFirstAdapter{
		public final LinkedList portDeclarations = new LinkedList();
		public final LinkedList taskDeclarations = new LinkedList();
		public final LinkedList modeDeclarations = new LinkedList();
		public final int[] maxIndexes;
		public String startMode="";
		public String moduleName="";
		
		private LinkedList moduleModes;
		private int moduleIdx=0;
		
		public ComputeDeclarations(int modulesCount){
			maxIndexes = createModesIndexes(modulesCount);
		}
		
		public void outAPortDeclaration(APortDeclaration node){
			portDeclarations.add(node);
		}
		
		public void outATaskDeclaration(ATaskDeclaration node){
			taskDeclarations.add(node);
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			moduleModes = new LinkedList();
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			moduleModes.add(node);
			maxIndexes[moduleIdx]++;
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			
			moduleIdx++;
			
			if(!startMode.equals("")){
				startMode = startMode + "_";
			}
			
			startMode = startMode + node.getStartMode().getText();
			
			if(!moduleName.equals("")){
				moduleName = moduleName + "_";
			}
			
			moduleName = moduleName + node.getModuleName().getText();
			
			modeDeclarations.add(moduleModes);
		}
	}
	
	private class FetchModeElements extends DepthFirstAdapter{
		private final LinkedList sensors;
		private final LinkedList actuators;
		private final LinkedList invocations;
		private final LinkedList modeSwitches;		
		
		public FetchModeElements(LinkedList sensors, LinkedList actuators, LinkedList invocations, LinkedList modeSwitches){
			this.sensors = sensors;
			this.actuators = actuators;
			this.invocations = invocations;
			this.modeSwitches = modeSwitches;
		}
		
		public void outASensorDeviceDriver(ASensorDeviceDriver node){
			sensors.add(node);
		}
		
		public void outAActuatorDeviceDriver(AActuatorDeviceDriver node){
			actuators.add(node);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			if(node.getParentTask()!=null){
				node.getParentTask().replaceBy(null);
			}
			invocations.add(node);
		}
		
		public void outAModeSwitch(AModeSwitch node){
			modeSwitches.add(node);
		}
	}
}
