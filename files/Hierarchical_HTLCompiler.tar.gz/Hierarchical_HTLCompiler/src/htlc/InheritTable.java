/*
 * Created on October 18, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */

package htlc;
import htlc.analysis.DepthFirstAdapter;
import htlc.node.AModeDeclaration;
import htlc.node.AModuleDeclaration;
import htlc.node.AProgramDeclaration;
import htlc.node.AProgramDeclarationList;
import htlc.node.ARefineProgram;
import htlc.node.TIdent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;


/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 *
 */
public class InheritTable extends DepthFirstAdapter {
	private SymbolTable symbolTable;
	
	private String rootProgramName;
	
	public final Map modeParents=new TypedTreeMap(StringComparator.instance,
            StringCast.instance, StringCast.instance);
		
	public final Map moduleParents=new TypedTreeMap(StringComparator.instance,
            StringCast.instance, StringCast.instance);
	
	public final Map programParents=new TypedTreeMap(StringComparator.instance,
            StringCast.instance, StringCast.instance);
	
	public final Map programSubPrograms=new TypedTreeMap(StringComparator.instance,
            StringCast.instance, ArrayListCast.instance);
	
	private String currentProgramName;
	
	private String currentModuleName;
	
	public InheritTable(SymbolTable symbolTable){
		this.symbolTable = symbolTable;
	}
	
	//Action code
	
	public void inAProgramDeclaration(AProgramDeclaration node){
		currentProgramName=node.getProgramName().getText();
		if(rootProgramName == null){
			rootProgramName = currentProgramName;
		}
	}
	
	public void outAProgramDeclaration(AProgramDeclaration node){
		currentProgramName="";
	}
	
	public void inAModuleDeclaration(AModuleDeclaration node){
		currentModuleName=node.getModuleName().getText();
	}
	
	public void outAModuleDeclaration(AModuleDeclaration node){
		currentModuleName="";
	}
	
	public void outAModeDeclaration(AModeDeclaration node){
		String modeName=node.getModeName().getText();
		
		if(node.getRefineProgram()!=null){
			//the mode is refined by a program
			ARefineProgram refProgram=(ARefineProgram)node.getRefineProgram();
			String refineProgramName=refProgram.getProgramName().getText();
			
			//add to program parents Map
			if(programParents.put(refineProgramName, currentProgramName)!=null){
				errorParents("task", refProgram.getProgramName());
			}
			
			//add all modules/modes from the refine program to module/modes parents map
			if(symbolTable.programs.containsKey(refineProgramName))
				((ProgramSymbolTable)symbolTable.programs.get(refineProgramName)).program.apply(new ComputeModuleParents(currentModuleName, modeName));
			else
				errorRefineProgram(((ARefineProgram)node.getRefineProgram()).getProgramName());
		}
	}
	
	class ComputeModuleParents extends DepthFirstAdapter{
		private String moduleName;
		private String modeName;
		
		public ComputeModuleParents(String moduleName, String modeName){
			this.modeName = modeName;
			this.moduleName = moduleName;
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			String name=node.getModuleName().getText();
			
			//add to module parents Map
			if(moduleParents.put(name,moduleName)!=null){
				errorParents("module", node.getModuleName());
			}
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			String name=node.getModeName().getText();
			
			//add to mode parents Map
			if(modeParents.put(name, modeName)!=null){
				errorParents("mode", node.getModeName());
			}
		}
	}
	
	public void outAProgramDeclarationList(AProgramDeclarationList node){
		//test the number of root program
		if(symbolTable.programs.size() != (programParents.size()+1)){
			//either there is no root or there are more then one
			errorRootProgramsNo();
		}
		
		//find root program
		Iterator parents=programParents.entrySet().iterator();
		while(parents.hasNext()){
			Map.Entry entry=(Map.Entry)parents.next();
			String parentName = (String)entry.getValue();
			String subProgram = (String)entry.getKey();
			
			ArrayList subPrograms;
			
			if(programSubPrograms.containsKey(parentName)){
				subPrograms = (ArrayList)programSubPrograms.get(parentName);
			}
			else{
				subPrograms = new ArrayList();
				programSubPrograms.put(parentName, subPrograms);
			}
			subPrograms.add(subProgram);
			
			if(!programParents.containsKey(parentName)){
				//root was found
				rootProgramName = parentName;
			}
		}
	}
	
	public AModuleDeclaration getRootModule(String programName, String moduleName){
		ProgramSymbolTable programSymbolTable;
		
		while(moduleParents.containsKey(moduleName)){
			programName = (String)programParents.get(programName);
			moduleName = (String)moduleParents.get(moduleName);
		}
		
		programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(programName);
		return ((ModuleSymbolTable)programSymbolTable.modules.get(moduleName)).module;
	}
	
	//Misc code
	public String getRootProgramName(){
		return rootProgramName;
	}
	
	public AProgramDeclaration getRoorProgramDeclaration(){
		return ((ProgramSymbolTable)symbolTable.programs.get(rootProgramName)).program;
	}
	
	private void errorParents(String message, TIdent ident){
		throw new RuntimeException("["+ident.getLine()+", "+ident.getPos()+
				"] "+message+" "+ident.getText()+" has multipels parents.");
	}
	
	private static void errorRefineProgram(TIdent refProg){
		throw new RuntimeException("["+refProg.getLine()+", "+refProg.getPos()+
				"] Program "+" "+refProg.getText()+" is not declared.");
	}
	
	private void errorRootProgramsNo(){
		throw new RuntimeException("A TSL program should have one and only one root program.");
	}
}
