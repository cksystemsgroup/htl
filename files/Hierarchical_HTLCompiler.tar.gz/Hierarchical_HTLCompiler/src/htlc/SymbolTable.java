/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package htlc;

import htlc.node.AProgramDeclaration;
import htlc.node.NodeCast;

import java.io.File;
import java.util.Map;


/**
 * 
 * This class implements a symbol table.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 *         Daniel Iercan, daniel.iercan@cs.uni-salzburg.at 2005
 */
public class SymbolTable extends AbstractSymbolTable {
   
	public final Map declarations = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, NodeCast.instance);
	
    public final Map programs = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, AbstractSymbolTableCast.instance);   

    public File pkgDir;

    public SymbolTable(File pkgDir) {
        this.pkgDir = pkgDir;
    }

    // Action code

    public void outAProgramDeclaration(AProgramDeclaration node){
    	final String name = node.getProgramName().getText();
    	
    	ProgramSymbolTable programSymbolTable = new ProgramSymbolTable(node, this);
    	node.apply(programSymbolTable);
    	
    	// test for program unicity
    	if(declarations.put(name,node) != null){
    		errorRedefined(node.getProgramName(), name);
    	}
    	
    	//test for program unicity
    	if(programs.put(name,programSymbolTable) != null){
    		errorRedefined(node.getProgramName(), name);
    	}
    }
}
