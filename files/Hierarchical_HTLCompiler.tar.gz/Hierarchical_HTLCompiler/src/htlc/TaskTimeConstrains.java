/*
 * Created on May 7, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */

package htlc;
import htlc.analysis.DepthFirstAdapter;
import htlc.node.AActualPorts;
import htlc.node.ACommunicatorDeclaration;
import htlc.node.ACommunicatorInstance;
import htlc.node.ATaskInvocation;

/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 *
 */
public class TaskTimeConstrains extends DepthFirstAdapter {
	public int higherReadCommInstance=0;
	public int lowerWriteCommInstance=Integer.MAX_VALUE;
	
	public int inputParam = 0;
	public int outputParam = 0;
	
	private String programName;
	private SymbolTable symbolTable;
	private InheritTable inheritTable;
	private boolean inOutputList = false;
	
	public TaskTimeConstrains(String programName, SymbolTable symbolTable, InheritTable inheritTable){
		this.programName = programName;
		this.symbolTable = symbolTable;
		this.inheritTable = inheritTable;
	}
	
	 /**
	 * 
	 * @param name
	 * @return communicator period
	 */
	private int getCommunicatorPeriod(String name){
		int period=0;
		
		String program = programName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				period = Integer.parseInt(((ACommunicatorDeclaration) pSymbolTable.communicators
						.get(name)).getCommunicatorPeriod().getText());
				break;
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return period;
	}
	
	public void inAActualPorts(AActualPorts node) {
		if (((ATaskInvocation) node.parent()).getOutputActualPorts() == node) {
			inOutputList = true;
		}
	}

	public void outAActualPorts(AActualPorts node) {
		inOutputList = false;
	}

	public void outACommunicatorInstance(ACommunicatorInstance node) {
		int instance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
		int period = getCommunicatorPeriod(node.getCommunicatorPortName().getText());
		
		if (inOutputList){
			outputParam++;
			if(lowerWriteCommInstance > (instance*period)){
				lowerWriteCommInstance = instance*period; 
			}
		}
		else{
			inputParam++;
			if(higherReadCommInstance < (instance*period)){
				higherReadCommInstance = instance*period; 
			}
		}
	}
}
