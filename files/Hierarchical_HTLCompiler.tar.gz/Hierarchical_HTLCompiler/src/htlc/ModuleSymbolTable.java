/*
 * Created on October 19, 2005
 *
 *Copyright (c) 2005 The Regents of the University of Salzburg.
 *All rights reserved.
 *Permission is hereby granted, without written agreement and without
 *license or royalty fees, to use, copy, modify, and distribute this
 *software and its documentation for any purpose, provided that the above
 *copyright notice and the following two paragraphs appear in all copies
 *of this software.
 *
 *IN NO EVENT SHALL THE UNIVERSITY OF SALZBURG BE LIABLE TO ANY PARTY
 *FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 *ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 *THE UNIVERSITY OF SALZBURG HAS BEEN ADVISED OF THE POSSIBILITY OF
 *SUCH DAMAGE.

 *THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 *INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 *PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 *SALZBURG HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 *ENHANCEMENTS, OR MODIFICATIONS.
 */

package htlc;
import htlc.node.AModeDeclaration;
import htlc.node.AModuleDeclaration;
import htlc.node.APortDeclaration;
import htlc.node.ATaskDeclaration;
import htlc.node.NodeCast;

import java.util.Map;



/**
 * @author Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 *
 */
public class ModuleSymbolTable extends AbstractSymbolTable {
	public final AModuleDeclaration module;
		
    public final Map ports = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, NodeCast.instance);

    public final Map tasks = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, NodeCast.instance);

    public final Map modes = new TypedTreeMap(StringComparator.instance,
            StringCast.instance, NodeCast.instance);
    
    private final SymbolTable symbolTable;
    
	public ModuleSymbolTable(AModuleDeclaration module, SymbolTable symbolTable){
		this.module = module;
		this.symbolTable = symbolTable;
	}
		
	public void outAPortDeclaration(APortDeclaration node){
    	final String name = node.getPortName().getText();

    	//test for declaration unicity
        if (symbolTable.declarations.put(name, node) != null) {
            errorRedefined(node.getPortName(), name);
        }
    	    	
        // test for port unicity
        if (ports.put(name, node) != null) {
            errorRedefined(node.getPortName(), name);
        }
   }
    
   public void outATaskDeclaration(ATaskDeclaration node){
    	final String name = node.getTaskName().getText();

    	//test for declaration unicity
        if (symbolTable.declarations.put(name, node) != null) {
            errorRedefined(node.getTaskName(), name);
        }
    	    	
        // test for task unicity
        if (tasks.put(name, node) != null) {
            errorRedefined(node.getTaskName(), name);
        }
   }
       
   public void outAModeDeclaration(AModeDeclaration node) {
        final String name = node.getModeName().getText();
        
        // test for declaration unicity
        if (symbolTable.declarations.put(name, node) != null) {
            errorRedefined(node.getModeName(), name);
        }
        
        //test for mode declaration unicity
        if (modes.put(name, node) != null) {
            errorRedefined(node.getModeName(), name);
        }
   }
}
