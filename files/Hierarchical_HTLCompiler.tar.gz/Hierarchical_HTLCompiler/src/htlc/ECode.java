/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package htlc;

import htlc.DependencyTable.ModePortTable;
import htlc.analysis.DepthFirstAdapter;
import htlc.node.AActualPorts;
import htlc.node.AActuatorDeviceDriver;
import htlc.node.ACommunicatorDeclaration;
import htlc.node.ACommunicatorInstance;
import htlc.node.AConcreteActualPort;
import htlc.node.AHostDeclaration;
import htlc.node.AModeDeclaration;
import htlc.node.AModeSwitch;
import htlc.node.AModuleDeclaration;
import htlc.node.APortDeclaration;
import htlc.node.AProgramDeclaration;
import htlc.node.AProgramDeclarationList;
import htlc.node.ARefineProgram;
import htlc.node.ASensorDeviceDriver;
import htlc.node.AStatePort;
import htlc.node.ATaskDeclaration;
import htlc.node.ATaskInvocation;
import htlc.node.NodeCast;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;

import javax.naming.InitialContext;


/**
 * 
 * This class implements the e code generation for the embedded machine, which
 * is the target platform of tslc.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 *         Daniel Iercan daniel.iercan@cs.uni-salzburg.at 2005
 */
public class ECode extends CodeGen {
	private FTable functionTable;

	private InheritTable inheritTable;

	private final Hashtable modeUnits = new Hashtable();

	private ModeUnit currentModeUnit;

	private int minUnitPeriod = -1;

	private final ArrayList program = new ArrayList();

	private String currentModeName = null;
	
	private String currentProgramName = null;
	
	private String currentModuleName = null;
	
	private boolean isModuleOnHost;
	
	private ProgramSymbolTable programSymbolTable;

	private ModuleSymbolTable moduleSymbolTable;

	private Hashtable modeAddresses;

	private Hashtable programAddresses;
	
	private Hashtable moduleAddresses;
	
	private final HTable hostTable;
	
	private final boolean pureGiotto;
	
	private ComputePrecedenceSets precedenceSets;

	private static final int giottoTriggerIndex = 0;

	private static final int nopCode = 0;

	private static final int wfutureCode = 1;
	
	private static final int sfutureCode = 2;
	
	private static final int rfutureCode = 3;

	private static final int callCode = 4;

	private static final int releaseCode = 5;

	private static final int ifCode = 6;

	private static final int jumpCode = 7;

	private static final int returnCode = 8;
	
	private static final int subCode = 9;
	
	private static final int copyRegCode = 10;
	
	private static final int pushRegCode = 11;
	
	private static final int popRegCode = 12;
	
	private static final int getParentCode = 13;
	
	private static final int setParentCode = 14;
	
	private static final int setChildrenParentCode = 15;
	
	private static final int deleteChildrenCode = 16;
	
	private static final int replaceChildrenCode = 17;
	
	private static final int cleanChildrenCode = 18;
	
	private static final int copyChildrenCode = 19;
	
	private static final int R0 = 0;
	
	private static final int R1 = 1;
	
	private static final int R2 = 2;
	
	private static final int R3 = 3;
	
	private static final String INIT_SYMBOL = "INIT_";
	
	private static final String START_SYMBOL = "START_";
	
	private static final String TARGET_SYMBOL = "TARGET_";
	
	private static final String WRITE_SYMBOL = "WRITE_";
	
	private static final String READ_SYMBOL = "READ_";
	
	private static final String BODY_SYMBOL = "BODY_";
	
	private static final String UNIT_SYMBOL = "UNIT_";
	
	private static final String MODE_SYMBOL = "MODE_";
	
	private static final String SWITCH_SYMBOL = "SWITCH_";
	
	private static final String FUTURE_SYMBOL = "FUTURE_";
	
	private static final String JUMP_SYMBOL = "JUMP_";
	
	private static final String IF_SYMBOL = "IF_";
	
	private DependencyTable dependencyTable;

	public ECode(SymbolTable symbolTable, DependencyTable dependencyTable, InheritTable inheritTable, FTable functionTable, HTable hostTable, boolean pureGiotto) {
		super(symbolTable, "ecode", "e_code.c", "e_code.h", "e_spec.txt",
				"e_code.b");

		this.functionTable = functionTable;
		this.inheritTable = inheritTable;
		this.dependencyTable=dependencyTable;
		this.pureGiotto = pureGiotto;
		this.hostTable = hostTable;
	}

	// Action code

	public void emitCFileHeader(AProgramDeclarationList node) {
		emit("Header");

		emit("Include");

		node.apply(new ComputeModeUnits());

		node.apply(new GenECode());
	}

	public void emitCFileBody(AProgramDeclarationList node) {
		emit("ProgramHeader");

		int address = 0;

		for (ListIterator iterator = program.listIterator(); iterator.hasNext(); address++) {
			Instruction instruction = (Instruction) iterator.next();

			if (address != 0)
				emit("ProgramComma");

			instruction.emitCode(address);
		}

		emit("ProgramEnd");
	}

	public void emitHFileHeader(AProgramDeclarationList node) {
		emit("Header");
	}

	public void emitHFileBody(AProgramDeclarationList node) {
		emit("ProgramSize", new String[] { Integer.toString(program.size()),
				Integer.toString(program.size()), Integer.toString(countFutureInstructions()),/*Integer.toString(maxUnits), */
				Integer.toString(minUnitPeriod) });
	}
	
	private int countFutureInstructions(){
	    final Iterator it=program.iterator();
	    int counter=0;
	    while(it.hasNext()){
	    	Instruction inst = (Instruction)it.next(); 
	        if(inst.opcode==wfutureCode ||
	        		inst.opcode==rfutureCode ||
	        		inst.opcode==sfutureCode
	        		){
	            counter++;
	        }
	    }
	    return counter;
	}

	public void emitBFile(AProgramDeclarationList node) {
		emitBinaryCode(program.size());
		emitBinaryCode(minUnitPeriod);

		for (ListIterator iterator = program.listIterator(); iterator.hasNext();) {
			Instruction instruction = (Instruction) iterator.next();

			emitBinaryCode(instruction.opcode);
			emitBinaryCode(instruction.arg1);
			emitBinaryCode(instruction.arg2);
			emitBinaryCode(instruction.arg3);
			emitBinaryCode(instruction.arg4);
		}
	}

	private class ComputeModeUnits extends DepthFirstAdapter {
		private String programName;
		private String moduleName;
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			programName = node.getProgramName().getText();
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			programName = "";
		}
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			moduleName = node.getModuleName().getText();
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			moduleName = "";
		}
		
		public void inAModeDeclaration(AModeDeclaration node) {
			ModeUnit modeUnit;

			node.apply(modeUnit = new ModeUnit(programName, symbolTable, inheritTable));
			
			if(minUnitPeriod==-1){
				minUnitPeriod = modeUnit.smalestPeriod;
			}
			else{
				minUnitPeriod = ModeUnit.gcd(minUnitPeriod, modeUnit.smalestPeriod);
			}

			final String modeName = node.getModeName().getText();

			modeUnits.put(programName + "."+moduleName+"."+modeName, modeUnit);
		}
	}
	
	private class ComputeHigherReadCommInstance extends DepthFirstAdapter{
		public int higherOffset=0;
		public ACommunicatorInstance higherCommInstance;
		
		private boolean inAInputList;
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts().equals(node)){
				inAInputList = true;
			}
			else{
				inAInputList = false;
			}
		}
		
		
		public void inACommunicatorInstance(ACommunicatorInstance node){
			if(inAInputList){
				int commPeriod = getCommunicatorPeriod(node.getCommunicatorPortName().getText());
				int instance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
				
				if(commPeriod*instance > higherOffset){
					higherOffset = commPeriod*instance;
					higherCommInstance = node;
				}
			}
		}
	}
	
	private class ComputePrecedenceSets extends DepthFirstAdapter{
		
		public Map precedenceTasks = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		public Map precedenceReadSet = new TypedTreeMap(StringComparator.instance, StringCast.instance, NodeCast.instance);
		private boolean isPrecedenceTask = false;
		private boolean inAInputActualList = false;
		
		public void inATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
			String sufix = currentProgramName+"."+currentModuleName+"."+currentModeName;
			
			Map modeDpendencies = (Map)dependencyTable.taskDependencies.get(sufix);
			ArrayList taskDependencies = (ArrayList)modeDpendencies.get(taskName);
			if(taskDependencies.size()>0){
				precedenceTasks.put(taskName, node);
				isPrecedenceTask = true;
			}
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			isPrecedenceTask = false;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAInputActualList = true;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAInputActualList=false;
    		}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(inAInputActualList && isPrecedenceTask){
				precedenceReadSet.put(node.getCommunicatorPortName().getText(), node);
			}
		}
	}
	
	private ACommunicatorDeclaration getCommunicator(String name){
		String program = currentProgramName;
		
		while(program!=null){
			ProgramSymbolTable pSymbolTable=(ProgramSymbolTable)symbolTable.programs.get(program);
			
			if (pSymbolTable.communicators.containsKey(name)) {
				return (ACommunicatorDeclaration)pSymbolTable.communicators.get(name);
			}
			
			program = (String)inheritTable.programParents.get(program);
		}
		
		return null;
	}
	
	private int getCommunicatorPeriod(String name){
		ACommunicatorDeclaration comm = getCommunicator(name);		
		
		if(comm != null)
			return Integer.parseInt(comm.getCommunicatorPeriod().getText());
		else
			return 0;
	}
	
	private String getCommunicatorType(String name){
		ACommunicatorDeclaration comm = getCommunicator(name);		
		
		if(comm != null)
			return comm.getTypeName().getText();
		else
			return "";
	}
	
	private boolean isEnabled(int unitPeriod, int unit, int commPeriod, int commInstance) {
		return (unitPeriod * unit == (commPeriod * commInstance) % currentModeUnit.modePeriod);
	}
	
	private boolean isEnabled(int unitPeriod, int unit, int offset){
		return (unitPeriod * unit == offset);
	}
		
	private void fixupFuture(Instruction instruction, int address) {
		if (instruction.opcode == wfutureCode ||
				instruction.opcode == rfutureCode ||
				instruction.opcode == sfutureCode) {
			final int nextAddress = instruction.arg2;

			instruction.arg2 = address;

			if (nextAddress < -1)
				fixupFuture((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-future instruction.");
	}
	
	private void fixupIf(Instruction instruction, int address) {
		if (instruction.opcode == ifCode || instruction.opcode == wfutureCode ||
				instruction.opcode == rfutureCode ||
				instruction.opcode == sfutureCode) {
			final int nextAddress = instruction.arg2;

			instruction.arg2 = address;

			if (nextAddress < -1)
				fixupIf((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-future instruction.");
	}

	private void fixupJump(Instruction instruction, int address) {
		if (instruction.opcode == jumpCode) {
			final int nextAddress = instruction.arg1;

			instruction.arg1 = address;

			if (nextAddress < -1)
				fixupJump((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-jump instruction.");
	}

	private void fixupSub(Instruction instruction, int address) {
		if (instruction.opcode == subCode) {
			final int nextAddress = instruction.arg1;

			instruction.arg1 = address;

			if (nextAddress < -1)
				fixupSub((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-sub instruction.");
	}
	
	private class GenInitECode extends DepthFirstAdapter{
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			addSubToFixup(programAddresses,INIT_SYMBOL + node.getProgramName().getText(), "SUB to the init address of program: " + node.getProgramName().getText());
		}
		
	}
	
	private class GenProgramInitECode extends DepthFirstAdapter{
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			String programName = node.getProgramName().getText();
			fixupSubAddress(programAddresses, INIT_SYMBOL+programName);				
		}
		
		public void outACommunicatorDeclaration(ACommunicatorDeclaration node){
	    	String name = node.getCommunicatorName().getText();
	    	String initDriver = node.getInitDriver().getText();
	    	
	    	// init driver for each communicator
			final int driverIndex = functionTable.getInitCommDriverIndex(currentProgramName, name, initDriver);

			program.add(new Instruction(callCode, driverIndex,
					"Call communicator initialization driver: "
					+ functionTable.getInitCommDriverWrapperName(currentProgramName, name, initDriver)));
			
	    }
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			String moduleName = node.getModuleName().getText();

			addSubToFixup(moduleAddresses, INIT_SYMBOL + moduleName, "SUB to module " + moduleName + " initialization!");
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			program.add(new Instruction(returnCode, "Return from the program "+currentProgramName+" initialization."));
		}
	}
	
	private class GenProgramStartECode extends DepthFirstAdapter{
		
		public void inAProgramDeclaration(AProgramDeclaration node){
			String programName = node.getProgramName().getText();
			
			fixupSubAddress(programAddresses, START_SYMBOL+programName);				
		}
				
		public void outAModuleDeclaration(AModuleDeclaration node){
			String moduleName = node.getModuleName().getText();
			
			addSubToFixup(moduleAddresses, START_SYMBOL + moduleName, "SUB to module " + moduleName + " start!");
		}
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			program.add(new Instruction(returnCode, "Return from the program "+currentProgramName+" start."));
		}
	}
	
	private class GenModuleECode extends DepthFirstAdapter{
		
		private String modeName;
		private String taskName;
		private boolean inAActualInputList;
		
		public void inAModuleDeclaration(AModuleDeclaration node){
			String moduleName = node.getModuleName().getText();
			fixupSubAddress(moduleAddresses, INIT_SYMBOL + moduleName);
		}
		
		public void inAModeDeclaration(AModeDeclaration node){
			modeName = node.getModeName().getText();
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			modeName = "";
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			taskName = "";
		}
		
		public void inAActualPorts(AActualPorts node){
    		if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAActualInputList=true;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAActualInputList=false;
    		}
    	}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!inAActualInputList){
				ATaskDeclaration taskDecl = (ATaskDeclaration)moduleSymbolTable.tasks.get(taskName);
				
				if(taskDecl.getTaskFunction()!=null){
					String name = node.getPortName().getText();
			    	String initDriver = ((APortDeclaration)moduleSymbolTable.ports.get(name)).getInitDriver().getText();
			    	
			    	// init driver for each communicator
					final int driverIndex = functionTable.getInitPortDriverIndex(currentProgramName, currentModuleName, modeName, taskName, name, initDriver);
		
					program.add(new Instruction(callCode, driverIndex,
							"Call initialization driver: "
							+ functionTable.getInitPortDriverWrapperName(currentProgramName, currentModuleName, modeName, taskName, name, initDriver)));
				}
			}
		}
		
		public void inATaskDeclaration(ATaskDeclaration node){
			taskName = node.getTaskName().getText();
		}
		
		public void inAStatePort(AStatePort node){
			String name = node.getStateName().getText();
	    	String initDriver = node.getInitDriver().getText();
	    	//String type = node.getTypeName().getText();
	    	
	    	// init driver for each communicator
			final int driverIndex = functionTable.getInitStateDriverIndex(currentProgramName, currentModuleName, taskName, name, "state", initDriver);

			program.add(new Instruction(callCode, driverIndex,
					"Call initialization state driver: "
					+ functionTable.getInitStateDriverWrapperName(currentProgramName, currentModuleName, taskName, name, "state", initDriver)));
		}
		
		public void outAModuleDeclaration(AModuleDeclaration node){
			
			//generate return from module init
			program.add(new Instruction(returnCode, "Return from the module "+node.getModuleName().getText()+" init."));
			
			String moduleName = node.getModuleName().getText();
			
			fixupSubAddress(moduleAddresses, START_SYMBOL+moduleName);
						
			//generate jump to start mode
			String startMode = node.getStartMode().getText();
		
			addSubToFixup(modeAddresses, START_SYMBOL + startMode, "SUB to start address of mode "+startMode+" of module " + currentModuleName);
			
			//generate return from module start
			program.add(new Instruction(returnCode, "Return from the module "+node.getModuleName().getText()+" start."));
		}
	}
	
	private void addSubToFixup(Hashtable chains, String key, String comment){
		int fixupAddress = -(program.size()+2);
		Instruction inst = new Instruction(subCode, -1,comment);
		FixupChain fixupChain;
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			inst.arg1 = fixupChain.address;
			
			if(fixupChain.address < 0){
				fixupChain.address = fixupAddress;
			}
		}
		else{
			fixupChain = new FixupChain(fixupAddress, 0, key);
			chains.put(key, fixupChain);
		}
		
		
		program.add(inst);
	}
	
	private void addFutureToFixup(Hashtable chains, int period, int dependency, String key, String comment, int futureCode){
		int fixupAddress = -(program.size()+2);
		
		FixupChain fixupChain;
		Instruction inst = new Instruction(futureCode, giottoTriggerIndex, -1, period, dependency, 0,comment);
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			inst.arg2 = fixupChain.address;
			
			if(fixupChain.address < 0){
				fixupChain.address = fixupAddress;
			}
		}
		else{
			fixupChain = new FixupChain(fixupAddress, 0, key);
				
			chains.put(key, fixupChain);
		}
		
		program.add(inst);
	}
	
	private void addIfToFixup(Hashtable chains, int condIndex, int falseAddress, String key, String comment){
		int fixupAddress = -(program.size()+2);
		
		FixupChain fixupChain;
		Instruction inst = new Instruction(ifCode, condIndex, -1, falseAddress, comment);
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			inst.arg2 = fixupChain.address;
			
			if(fixupChain.address < 0){
				fixupChain.address = fixupAddress;
			}
		}
		else{
			fixupChain = new FixupChain(fixupAddress, key);
				
			chains.put(key, fixupChain);
		}
		
		program.add(inst);
	}
	
	private void addJumpToFixup(Hashtable chains, String key, String comment){
		int fixupAddress = -(program.size()+2);
		
		FixupChain fixupChain;
		Instruction inst = new Instruction(jumpCode, -1, comment);
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			inst.arg1 = fixupChain.address;
			
			if(fixupChain.address < 0){
				fixupChain.address = fixupAddress;
			}
		}
		else{
			fixupChain = new FixupChain(fixupAddress, key);
				
			chains.put(key, fixupChain);
		}
		
		program.add(inst);
	}
	
	private class GenModeECode extends DepthFirstAdapter{
		public void outAModeDeclaration(AModeDeclaration node){
			generateModeUnitECode(node);
		}
					
		private void generateModeUnitECode(AModeDeclaration node){
			String modeName = node.getModeName().getText();
			
			for(int u=0; u<currentModeUnit.nUnits; u++){				
				fixupFutureAddress(modeAddresses, WRITE_SYMBOL+FUTURE_SYMBOL+modeName+u);
				
				//generate commUpdate ECode
				//generate call sensor device drivers
				node.apply(new GenCommunicatorUpdate(u));
								
				//generate return
				program.add(new Instruction(returnCode, "Return from mode "+currentModeName+", unit" + u + "."));
				
				if(u==0){
					fixupFutureAddress(modeAddresses, SWITCH_SYMBOL+FUTURE_SYMBOL+modeName);
					//generate mode switch test ECode
					node.apply(new GenModeSwitchTests(u));
					
					fixupSubAddress(modeAddresses, BODY_SYMBOL+modeName);
					
					//future to unit zero after period
					addFutureToFixup(modeAddresses, 
							Integer.parseInt(node.getModePeriod().getText()), 
							0, WRITE_SYMBOL+FUTURE_SYMBOL+modeName+0, 
							"FUTURE to write mode "+modeName+" unit 0 address", wfutureCode);
					addFutureToFixup(modeAddresses, 
							Integer.parseInt(node.getModePeriod().getText()), 
							0, SWITCH_SYMBOL+FUTURE_SYMBOL+modeName, 
							"FUTURE to switch mode "+modeName+" address", sfutureCode);
					
					program.add(new Instruction(getParentCode, R0, R3, "Save the parent of R0 in R3"));
					program.add(new Instruction(replaceChildrenCode, R3, R0, R1, "Replace trigger in R0 with trigger in R1 in the children list of R3"));
					program.add(new Instruction(setChildrenParentCode, R0, R1, "Set R1 as the parent of the children in the children list of R0"));
					program.add(new Instruction(copyChildrenCode, R1, R0, "Copy children list from R0 to R1"));
					program.add(new Instruction(setParentCode, R1, R3, "Set the parent of R1 to R3"));
					program.add(new Instruction(copyRegCode, R1, R2, "Save a copy of R1 in R2"));
					
					addFutureToFixup(modeAddresses, 
							0, 
							0, READ_SYMBOL+FUTURE_SYMBOL+modeName+u, 
							"FUTURE to read mode "+modeName+" unit 0 address", rfutureCode);
					
					program.add(new Instruction(returnCode, "Return from mode body address of "+modeName));
					
				}
				
				fixupFutureAddress(modeAddresses, READ_SYMBOL+FUTURE_SYMBOL+modeName+u);
								
				if(isModuleOnHost){
					node.apply(new GenCommunicatorRead(u));
					
					//release non-prec tasks
					node.apply(new GenNonPrecedenceTaskECode(u));
				}
				
				if(u==0 && isModuleOnHost){
					//generate delay future to update comm read by prec tasks
					node.apply(new GenReadSetPrecedenceTaskTriggers(u));
					//generate delay future to release prec tasks
					node.apply(new GenPrecedenceTaskTriggers(u));
				}
				
				//generate future to next unit
				
				int nextUnit = (u+1)%currentModeUnit.nUnits;
				
				if(nextUnit > 0){
					addFutureToFixup(modeAddresses, currentModeUnit.smalestPeriod, 
							0, WRITE_SYMBOL+FUTURE_SYMBOL+modeName+nextUnit,
							"Triggered jump to next mode unit address: " + currentModeName +
							", "+nextUnit, wfutureCode);
					
					addFutureToFixup(modeAddresses, currentModeUnit.smalestPeriod, 
							0, READ_SYMBOL+FUTURE_SYMBOL+modeName+nextUnit,
							"Triggered jump to next mode unit address: " + currentModeName +
							", "+nextUnit, rfutureCode);
				}
								
				//return from action unit
				program.add(new Instruction(returnCode, "Return from mode action: "+currentModeName+", " + u + "."));
				
				if(u==0){
					//generate ECode to update comm read by prec tasks
					node.apply(new GenReadSetPrecedenceTaskECode(u));
				
					//generate ECode to release prec tasks
					node.apply(new GenPrecedenceTaskECode(u));
				}
			}
		}
	}
	
	private class GenModeStartECode extends DepthFirstAdapter{
		public void inAModeDeclaration(AModeDeclaration node){
			String modeName = node.getModeName().getText();
			
			fixupSubAddress(modeAddresses, START_SYMBOL+modeName);			
		}
		
		public void inAModeSwitch(AModeSwitch node){
			String destMode = node.getDestinationMode().getText();
			String condName = node.getConditionFunction().getText();
			
			int conditionIndex = functionTable.getConditionIndex(currentProgramName, currentModuleName,
					currentModeName, destMode, condName);
			String condWrapperName =  functionTable.getConditionWrapperName(currentProgramName, currentModuleName,
					currentModeName, destMode, condName);
			
			
			addIfToFixup(modeAddresses, conditionIndex, program.size()+1, 
					TARGET_SYMBOL + IF_SYMBOL + destMode ,"If switch condition: " + condWrapperName);			
		}
		
		public void outAModeDeclaration(AModeDeclaration node){
			String modeName = node.getModeName().getText();
			
			fixupSubAddress(modeAddresses, TARGET_SYMBOL+modeName);
			fixupIfAddress(modeAddresses, TARGET_SYMBOL + IF_SYMBOL + modeName);
			fixupJumpAddress(modeAddresses, TARGET_SYMBOL + JUMP_SYMBOL + modeName);
			
			//execute body e code for unit zero
			addSubToFixup(modeAddresses, BODY_SYMBOL+modeName, "SUB to mode " + modeName + " body address");
			
			if(node.getRefineProgram() != null){
				//increment level
				program.add(new Instruction(getParentCode, R0, R3, "Get parent of R0 into R3"));
				program.add(new Instruction(pushRegCode, R3, "Push R3 onto parents stack"));
				program.add(new Instruction(setParentCode, R0, R2, "Set R2 as parent of R0"));
				program.add(new Instruction(cleanChildrenCode, R0, "Clean the children list of R0"));
				
				//start sub program if this exits
				String subProgram = ((ARefineProgram)node.getRefineProgram()).getProgramName().getText();
				addSubToFixup(programAddresses, START_SYMBOL+subProgram,
						"START refining program: "+subProgram);
				
				//decrement level
				program.add(new Instruction(popRegCode, R3, "Pop R3 from parents stack"));
				program.add(new Instruction(setParentCode, R0, R3, "Set parent of R0 into R3"));
				program.add(new Instruction(cleanChildrenCode, R0, "Clean the children list of R0"));
			}
			
			program.add(new Instruction(returnCode, "RETURN from mode " + modeName + " start."));
		}
	}
	
	private void fixupSubAddress(Hashtable chains, String key){
		FixupChain fixupChain;
		int address = program.size();
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			final int fixupAddress = fixupChain.address;
			fixupChain.address = address;

			if (fixupAddress < -1) {
				fixupSub((Instruction) program
						.get(-(fixupAddress + 2)),
						address);
			} else if (fixupAddress == -1)
				throw new RuntimeException("Fixup error.");
			else
				throw new RuntimeException(
						"Ambiguous program name declaration.");
		} else
			chains.put(key, new FixupChain(
					address, key));
	}
	
	private void fixupFutureAddress(Hashtable chains, String key){
		FixupChain fixupChain;
		int address = program.size();
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			final int fixupAddress = fixupChain.address;

			fixupChain.address = address;
			
			if (fixupAddress < -1) {
				fixupFuture((Instruction) program
						.get(-(fixupAddress + 2)),
						address);
			} else if (fixupAddress == -1)
				throw new RuntimeException("Fixup error.");
			else
				throw new RuntimeException(
						"Ambiguous program name declaration.");
		} else
			chains.put(key, new FixupChain(
					address, key));
	}
	
	private void fixupIfAddress(Hashtable chains, String key){
		FixupChain fixupChain;
		int address = program.size();
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			final int fixupAddress = fixupChain.address;

			fixupChain.address = address;
			
			if (fixupAddress < -1) {
				fixupIf((Instruction) program
						.get(-(fixupAddress + 2)),
						address);
			} else if (fixupAddress == -1)
				throw new RuntimeException("Fixup error.");
			else
				throw new RuntimeException(
						"Ambiguous program name declaration.");
		} else
			chains.put(key, new FixupChain(
					address, key));
	}
	
	private void fixupJumpAddress(Hashtable chains, String key){
		FixupChain fixupChain;
		int address = program.size();
		
		if(chains.containsKey(key)){
			fixupChain = (FixupChain)chains.get(key);
			final int fixupAddress = fixupChain.address;

			fixupChain.address = address;
			
			if (fixupAddress < -1) {
				fixupJump((Instruction) program
						.get(-(fixupAddress + 2)),
						address);
			} else if (fixupAddress == -1)
				throw new RuntimeException("Fixup error.");
			else
				throw new RuntimeException(
						"Ambiguous program name declaration.");
		} else
			chains.put(key, new FixupChain(
					address, key));
	}
	
	private abstract class GenModeElementECode extends DepthFirstAdapter{
		protected int unit;
		
		public GenModeElementECode(int unit){
			this.unit = unit;
		}
		
	}
	
	private class GenCommunicatorUpdate extends GenModeElementECode{
		
		private String task;
		private boolean inAOutputList=false;
		private int outPos=0;
		
		public GenCommunicatorUpdate(int unit){
			super(unit);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			task = node.getTaskName().getText();
			outPos = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			task = null;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void inAConcreteActualPort(AConcreteActualPort node){
			if(inAOutputList)
				outPos++;
		}
		
		public void inACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(task)))
				return;
			if(inAOutputList){
				String name = node.getCommunicatorPortName().getText();
				int commPeriod = getCommunicatorPeriod(name);
				int commInstance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
				if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
					String type = getCommunicatorType(name);
				
					//generate code to update written communicators
					int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
							currentModeName, task, name, outPos, type, "output");
					String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
							currentModeName, task, name, outPos, type, "output");
					
					program.add(new Instruction(callCode, driverIndex,
							"Call copy driver: "
							+ driverName));					
				}
				
				outPos++;
			}
		}
		
		public void inASensorDeviceDriver(ASensorDeviceDriver node){
			
			String name = node.getCommunicatorName().getText();
			int commPeriod = getCommunicatorPeriod(name);
			int commInstance = Integer.parseInt(node.getCommunicatorInstance().getText());
			if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
				int driverIndex = functionTable.getDeviceDriverIndex(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				String driverName = functionTable.getDeviceDriverWrapperName(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				program.add(new Instruction(callCode, driverIndex,
						"Call device driver: "
						+ driverName));
			}
		}
	}
	
	private class GenCommunicatorRead extends GenModeElementECode{
		private String task;
		private boolean inAOutputList=false;
		private int inPos=0;
		
		public GenCommunicatorRead(int unit){
			super(unit);
		}
						
		public void inATaskInvocation(ATaskInvocation node){
			task = node.getTaskName().getText();
			inPos = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			task = null;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void inAConcretActualPort(AConcreteActualPort node){
			if(!inAOutputList)
				inPos++;
		}
		
		public void inACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(task)))
				return;
			if(!precedenceSets.precedenceTasks.containsKey(task)){
				if(!inAOutputList){
					String name = node.getCommunicatorPortName().getText();
					int commPeriod = getCommunicatorPeriod(name);
					int commInstance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
					if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
						String type = getCommunicatorType(name);
						
						//generate code to update written communicators
						int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
								currentModeName, task, name, inPos, type, "input");
						String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
								currentModeName, task, name, inPos, type, "input");
						
						program.add(new Instruction(callCode, driverIndex,
								"Call copy driver: "
								+ driverName));
					}
					inPos++;
				}
			}
		}
		
		public void inAActuatorDeviceDriver(AActuatorDeviceDriver node){
			String name = node.getCommunicatorName().getText();
			int commPeriod = getCommunicatorPeriod(name);
			int commInstance = Integer.parseInt(node.getCommunicatorInstance().getText());
			if( isEnabled(currentModeUnit.smalestPeriod, unit, commPeriod, commInstance)){
				int driverIndex = functionTable.getDeviceDriverIndex(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				String driverName = functionTable.getDeviceDriverWrapperName(currentProgramName, currentModuleName, 
						currentModeName, node.getDriverName().getText());
				program.add(new Instruction(callCode, driverIndex,
						"Call device driver: "
						+ driverName));
			}
		}
		
	}
	
	private class GenModeSwitchTests extends GenModeElementECode{
		
		public GenModeSwitchTests(int unit){
			super(unit);
		}
		
		public void inAModeSwitch(AModeSwitch node){
			String destMode = node.getDestinationMode().getText();
			String condName = node.getConditionFunction().getText();
			
			int conditionIndex = functionTable.getConditionIndex(currentProgramName, currentModuleName,
					currentModeName, destMode, condName);
			String condWrapperName =  functionTable.getConditionWrapperName(currentProgramName, currentModuleName,
					currentModeName, destMode, condName);
			
			program.add(new Instruction(ifCode, conditionIndex,
					program.size()+2, program.size()+1, "If switch condition: "
							+ condWrapperName));
			
			program.add(new Instruction(jumpCode, program.size()+4, "Switch is condition " + condWrapperName + " is not true!"));
			
			program.add(new Instruction(deleteChildrenCode, R0, "Switch condition is true. CANCEL triggers from child modes!"));
			program.add(new Instruction(cleanChildrenCode, R0, "Switch condition is true. Clean children list!"));
			
			addJumpToFixup(modeAddresses, TARGET_SYMBOL + JUMP_SYMBOL + destMode, "JUMP to destination mode: "+destMode);
		}
	}
	
	private class GenNonPrecedenceTaskECode extends GenModeElementECode{
		
		public GenNonPrecedenceTaskECode(int unit){
			super(unit);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
					
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(!precedenceSets.precedenceTasks.containsKey(taskName)){
				ComputeHigherReadCommInstance higherInstance = new ComputeHigherReadCommInstance();
				node.apply(higherInstance);
				
				if(isEnabled(currentModeUnit.smalestPeriod, unit, higherInstance.higherOffset)){
					final int taskIndex = functionTable.getTaskIndex(currentProgramName, currentModuleName, taskName);
					
					program.add(new Instruction(releaseCode, taskIndex, 0,
							0 , "Release task: "
									+ functionTable
											.getTaskWrapperName(currentProgramName, currentModuleName, taskName)));
				}
			}
			
		}
	}
	
	public class GenReadSetPrecedenceTaskTriggers extends GenModeElementECode{
		
		private String taskName;
		private boolean inAOutputList;
		private int inPosition;
		
		public GenReadSetPrecedenceTaskTriggers(int unit){
			super(unit);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
			inPosition = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			taskName = "";
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!inAOutputList){
				inPosition++;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName) && !inAOutputList){
				String commName = node.getCommunicatorPortName().getText();
				int period = getCommunicatorPeriod(commName);
				int instance = Integer.parseInt(node.getCommunicatorInstanceNumber().getText());
				
				String keyAddress=currentModeName+taskName+inPosition; 
				
				FixupChain fixupChain = new FixupChain(-(program.size()+2), unit, currentModeName);
				
				modeAddresses.put(keyAddress, fixupChain);
				
				program.add(new Instruction(rfutureCode, giottoTriggerIndex,
						-1, period*instance,0,0,
						"Triggered jump to E Code that will read the communicator '" + commName +"' into task '"+taskName+"' input port"));
			}
			
			if(!inAOutputList){
				inPosition++;
			}
		}
	}
	
	private class GenReadSetPrecedenceTaskECode extends GenModeElementECode{
		
		private String taskName;
		private boolean inAOutputList;
		private int inPosition;
		
		public GenReadSetPrecedenceTaskECode(int unit){
			super(unit);
		}
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
			inPosition = 0;
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			taskName = "";
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(!inAOutputList){
				inPosition++;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName) && !inAOutputList && isModuleOnHost){
				String commName = node.getCommunicatorPortName().getText();
				String keyAddress=currentModeName+taskName+inPosition; 
				
				FixupChain fixupChain = (FixupChain)modeAddresses.get(keyAddress);
				int adr = fixupChain.address;
				int realAdr = program.size();
				
				if (adr < -1) {
					fixupFuture((Instruction) program
							.get(-(adr + 2)),
							realAdr);
				} 
				else if (adr == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous module name declaration.");
				
//				program.add(new Instruction(futureCode, giottoTriggerIndex,
//						realAdr+2, 0,0,0,
//						"Triggered jump to real E Code that will update the communicator '" + commName +"' read by task '"+taskName+"'"));
//				program.add(new Instruction(returnCode, "Retrun from delay comm update: "+commName));
				//generate code to read communicators
				String type = getCommunicatorType(commName);
				int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
						currentModeName, taskName, commName, inPosition, type, "input");
				String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
						currentModeName, taskName, commName, inPosition, type, "input");
				
				program.add(new Instruction(callCode, driverIndex,
						"Call copy driver: "
						+ driverName));
				program.add(new Instruction(returnCode, "Retrun from real comm update: "+commName));
			}
			
			if(!inAOutputList){
				inPosition++;
			}
		}
	}
	
	public class GenPrecedenceTaskTriggers extends GenModeElementECode{
		
		public GenPrecedenceTaskTriggers(int unit){
			super(unit);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName)){
				ComputeHigherReadCommInstance higherInstance=new ComputeHigherReadCommInstance();
				node.apply(higherInstance);
				
				String keyAddress=currentModeName+taskName; 
				
				FixupChain fixupChain = new FixupChain(-(program.size()+2), unit, currentModeName);
				
				modeAddresses.put(keyAddress, fixupChain);
				
				long depList=0;
				
				ArrayList taskDeps=(ArrayList)((Map)dependencyTable.taskDependencies.get(currentProgramName+"."+currentModuleName+"."+currentModeName)).get(taskName);
				
				Iterator depIt = taskDeps.iterator();
				while(depIt.hasNext()){
					ATaskInvocation dep = (ATaskInvocation)depIt.next();
					int idx = functionTable.getTaskIndex(currentProgramName, currentModuleName, dep.getTaskName().getText());
					depList = depList | (0x01 << idx);
				}
				
				program.add(new Instruction(rfutureCode, giottoTriggerIndex,
						-1, higherInstance.higherOffset,(int)(depList & 0xFFFFFFFFl),(int)((depList >> 32) & 0xFFFFFFFFl),
						"Triggered jump to E Code that will release task '"+taskName+"'"));
			}
		}
	}
	
	private class GenCopyTaskOutputPorts extends DepthFirstAdapter{
		private String taskName;
		private int inPosition;
		private boolean inAOutputList;
		
		public void inATaskInvocation(ATaskInvocation node){
			taskName = node.getTaskName().getText();
			inPosition = 0;
		}
		
		public void inAActualPorts(AActualPorts node){
			if(((ATaskInvocation)node.parent()).getInputActualPorts()==node){
    			inAOutputList=false;
    		}
    		
    		if(((ATaskInvocation)node.parent()).getOutputActualPorts()==node){
    			inAOutputList=true;
    		}
		}
		
		public void outAConcreteActualPort(AConcreteActualPort node){
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(!inAOutputList){
				String portName = node.getPortName().getText();
				String type = ((APortDeclaration)moduleSymbolTable.ports.get(portName)).getPortType().getText();
				int driverIndex = functionTable.getCopyDriverIndex(currentProgramName, currentModuleName,
						currentModeName, taskName, portName, inPosition, type, "input");
				String driverName = functionTable.getCopyDriverWrapperName(currentProgramName, currentModuleName,
						currentModeName, taskName, portName, inPosition, type, "input");
				
				program.add(new Instruction(callCode, driverIndex,
						"Call copy driver: "
						+ driverName));
				inPosition++;
			}
		}
		
		public void outACommunicatorInstance(ACommunicatorInstance node){
			if(!inAOutputList){
				inPosition++;
			}
		}
	}
	
	private class GenPrecedenceTaskECode extends GenModeElementECode{
		
		public GenPrecedenceTaskECode(int unit){
			super(unit);
		}
		
		public void outATaskInvocation(ATaskInvocation node){
			String taskName = node.getTaskName().getText();
			if(Utils.isAbstract((ATaskDeclaration)moduleSymbolTable.tasks.get(taskName)))
				return;
			if(precedenceSets.precedenceTasks.containsKey(taskName) && isModuleOnHost){
				ComputeHigherReadCommInstance higherInstance=new ComputeHigherReadCommInstance();
				node.apply(higherInstance);
				
				String keyAddress=currentModeName+taskName; 
				
				FixupChain fixupChain = (FixupChain)modeAddresses.get(keyAddress);
				int adr = fixupChain.address;
				int realAdr = program.size();
				
				if (adr < -1) {
					fixupFuture((Instruction) program
							.get(-(adr + 2)),
							realAdr);
				} 
				else if (adr == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous module name declaration.");
								
//				program.add(new Instruction(futureCode, giottoTriggerIndex,
//						realAdr+2, 0,0,0,
//						"Triggered jump to E Code that will release task '"+taskName+"'"));
//				
//				program.add(new Instruction(returnCode, "Retrun from task release: "+taskName));
				
				//copy ports
				node.apply(new GenCopyTaskOutputPorts());
				
				final int taskIndex = functionTable.getTaskIndex(currentProgramName, currentModuleName, taskName);
					
				program.add(new Instruction(releaseCode, taskIndex, 0,
						0 , "Release task: "
								+ functionTable
									.getTaskWrapperName(currentProgramName, currentModuleName, taskName)));
				
				program.add(new Instruction(returnCode, "Retrun from real task release: "+taskName));
				
			}
		}
	}
	
	private class GenECode extends DepthFirstAdapter {
	
	    public void inAProgramDeclarationList(AProgramDeclarationList node){
	    	programAddresses = new Hashtable();
	    	
	    	//generate subs to init programs
	    	node.apply(new GenInitECode());
	    	
	    	Instruction inst = new Instruction(subCode, -1, "SUB to the start address of program: " + inheritTable.getRootProgramName());
			programAddresses.put(START_SYMBOL + inheritTable.getRootProgramName(),
					new FixupChain(-(program.size()+2), START_SYMBOL + inheritTable.getRootProgramName()));
			program.add(inst);
			
			program.add(new Instruction(returnCode, "RETURN from address zero E code"));
	    }
	    
	    public void outAProgramDeclarationList(AProgramDeclarationList node){
	    	programAddresses = null;
	    } 
	    
	    public void inAProgramDeclaration(AProgramDeclaration node){
	    	currentProgramName = node.getProgramName().getText();
	    	programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(currentProgramName);
	    
	    	moduleAddresses = new Hashtable();
	    	    	
	    	node.apply(new GenProgramInitECode());
	    	node.apply(new GenProgramStartECode());
	    }
	    
	    public void outAProgramDeclaration(AProgramDeclaration node){
	    	currentProgramName = null;
	    	moduleAddresses = null;
	    }

	    public void inAModuleDeclaration(AModuleDeclaration node){
	    	currentModuleName = node.getModuleName().getText();
	    	moduleSymbolTable = (ModuleSymbolTable)programSymbolTable.modules.get(currentModuleName);
	    	modeAddresses = new Hashtable();
	    	
	    	AModuleDeclaration rootModule = inheritTable.getRootModule(currentProgramName, currentModuleName);
	    	if(rootModule.getHostDeclaration()!=null){
	    		isModuleOnHost = ((AHostDeclaration)rootModule.getHostDeclaration())
	    				.getHostName().getText().equals(hostTable.currentHost);
	    	}
	    	else{
	    		isModuleOnHost = true;
	    	}
	    	
	    	if(pureGiotto){
	    		isModuleOnHost = true;
	    	}
	    	
	    	node.apply(new GenModuleECode());
	    }
	    
	    public void outAModuleDeclaration(AModuleDeclaration node){
	    	currentModuleName = null;
	    	modeAddresses = null;
	    }
	    
	    public void inAModeDeclaration(AModeDeclaration node){
	    	currentModeName = node.getModeName().getText();
	    	precedenceSets = new ComputePrecedenceSets();
	    	node.apply(precedenceSets);
	    	
	    	currentModeUnit = (ModeUnit)modeUnits.get(currentProgramName + "."+currentModuleName+"."+currentModeName);	    	
	    	
	    	node.apply(new GenModeStartECode());
	    	node.apply(new GenModeECode());
	    }
	    
	    public void outAModeDeclaration(AModeDeclaration node){
	    	currentModeName = null;
	    	currentModeUnit = null;
	    	precedenceSets = null;
	    }
	}

	// Misc code

	private class FixupChain {
		private int address = 0;

		private int unit = 0;

		private String name = null;
		
		public FixupChain(int address, String name){
			this.address = address;
			this.name = name;

		}

		public FixupChain(int address, int unit, String name) {
			this.address = address;
			this.unit = unit;
			this.name = name;
		}
	}

	private class Instruction {
		int opcode = 0;

		int arg1 = -1;

		int arg2 = -1;

		int arg3 = -1;
		
		int arg4 = -1;
		
		int arg5 = -1;

		String comment = "";

		public Instruction(int opcode) {
			this.opcode = opcode;
		}

		public Instruction(int opcode, String comment) {
			this.opcode = opcode;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1) {
			this.opcode = opcode;
			this.arg1 = arg1;
		}

		public Instruction(int opcode, int arg1, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1, int arg2, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1, int arg2, int arg3) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
		}

		public Instruction(int opcode, int arg1, int arg2, int arg3,
				String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;

			this.comment = comment;
		}
		
		public Instruction(int opcode, int arg1, int arg2, int arg3, int arg4,
				String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
			this.arg4 = arg4;

			this.comment = comment;
		}
		
		public Instruction(int opcode, int arg1, int arg2, int arg3, int arg4, int arg5, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
			this.arg4 = arg4;
			this.arg5 = arg5;

			this.comment = comment;
		}

		public void emitCode(int address) {
			switch (opcode) {
			case nopCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("NOP");
				break;
			case wfutureCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("WFUTURE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),Integer.toString(arg4),Integer.toString(arg5),
								comment });
				break;
			case rfutureCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RFUTURE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),Integer.toString(arg4),Integer.toString(arg5),
								comment });
				break;	
			case sfutureCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("SFUTURE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),Integer.toString(arg4),Integer.toString(arg5),
								comment });
				break;
			case callCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("CALL", new String[] { Integer.toString(arg1), comment });
				break;
			case releaseCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RELEASE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),
								comment });
				break;
			case ifCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("IF",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),
								comment });
				break;
			case jumpCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("JUMP", new String[] { Integer.toString(arg1), comment });
				break;
			case returnCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RETURN", new String[] { comment });
				break;
			case subCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("SUB", new String[] { Integer.toString(arg1), comment });
				break;
			case copyRegCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("COPYREG", new String[] { Integer.toString(arg1), Integer.toString(arg2) , comment });
				break;
			case pushRegCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("PUSHREG", new String[] { Integer.toString(arg1), comment });
				break;
			case popRegCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("POPREG", new String[] { Integer.toString(arg1), comment });
				break;
			case getParentCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("GETPARENT", new String[] { Integer.toString(arg1), Integer.toString(arg2) , comment });
				break;	
			case setParentCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("SETPARENT", new String[] { Integer.toString(arg1), Integer.toString(arg2) , comment });
				break;
			case setChildrenParentCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("SET_CHILDREN_PARENT", new String[] { Integer.toString(arg1), Integer.toString(arg2) , comment });
				break;
			case deleteChildrenCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("DELETE_CHILDREN", new String[] { Integer.toString(arg1), comment });
				break;	
			case replaceChildrenCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("REPLACE_CHILDREN", new String[] { Integer.toString(arg1), Integer.toString(arg2), Integer.toString(arg3), comment });
				break;
			case cleanChildrenCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("CLEAN_CHILDREN", new String[] { Integer.toString(arg1), comment });
				break;
			case copyChildrenCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("COPY_CHILDREN", new String[] { Integer.toString(arg1), Integer.toString(arg2), comment });
				break;
			}
		}
	}
}
