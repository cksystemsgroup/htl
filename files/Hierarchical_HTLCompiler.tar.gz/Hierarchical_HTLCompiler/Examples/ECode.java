/*

 Copyright (c) 2001 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 */

package tslc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ListIterator;

import tslc.analysis.DepthFirstAdapter;
import tslc.node.AActualPort;
import tslc.node.ACommunicatorDeclaration;
import tslc.node.AModeDeclaration;
import tslc.node.AModeSwitch;
import tslc.node.AModuleDeclaration;
import tslc.node.AProgramDeclaration;
import tslc.node.AProgramDeclarationList;


/**
 * 
 * This class implements the e code generation for the embedded machine, which
 * is the target platform of tslc.
 * 
 * @author Christoph Kirsch, cm@eecs.berkeley.edu
 */
public class ECode extends CodeGen {
	private FTable functionTable;

	private InheritTable inheritTable;

	private boolean pureGiotto;

	private boolean dynamicGiotto;

	private final Hashtable modeUnits = new Hashtable();

	private int maxUnits = 1;

	private int minUnitPeriod = -1;

	private int modeConnectionPeriod = -1;

	private boolean isThereAModeConnectionAnnotation = false;

	private final ArrayList program = new ArrayList();

	private String startModeName;

	private int startModeAddress;

	private String currentModeName = null;
	
	private String currentProgramName = null;
	
	private String currentModuleName = null;
	
	private ProgramSymbolTable programSymbolTable;

	private ModuleSymbolTable moduleSymbolTable;
	
	private String currentTaskName = null;

	private Hashtable modeAddresses;

	private Hashtable taskInvocationAddresses;
	
	private Hashtable programAddresses;
	
	private Hashtable moduleAddresses;

	private static final int giottoTriggerIndex = 0;

	private static final int nopCode = 0;

	private static final int futureCode = 1;

	private static final int callCode = 2;

	private static final int releaseCode = 3;

	private static final int ifCode = 4;

	private static final int jumpCode = 5;

	private static final int returnCode = 6;
	
	final private HashSet modeSwitchSensorPorts=new HashSet();
	final private HashSet taskSensorPorts=new HashSet();
	
	private DependencyTable dependencyTable;

	public ECode(SymbolTable symbolTable, DependencyTable dependencyTable, InheritTable inheritTable, FTable functionTable) {
		super(symbolTable, "ecode", "e_code.c", "e_code.h", "e_spec.txt",
				"e_code.b");

		this.functionTable = functionTable;
		this.inheritTable = inheritTable;
		this.dependencyTable=dependencyTable;
	}

	// Action code

	public void emitCFileHeader(AProgramDeclarationList node) {
		emit("Header");

		emit("Include");

		node.apply(new ComputeModeUnits());

		node.apply(new GenECode());
	}

	public void emitCFileBody(AProgramDeclarationList node) {
		emit("ProgramHeader");

		int address = 0;

		for (ListIterator iterator = program.listIterator(); iterator.hasNext(); address++) {
			Instruction instruction = (Instruction) iterator.next();

			if (address != 0)
				emit("ProgramComma");

			instruction.emitCode(address);
		}

		emit("ProgramEnd");
	}

	public void emitHFileHeader(AProgramDeclarationList node) {
		emit("Header");
	}

	public void emitHFileBody(AProgramDeclarationList node) {
		emit("ProgramSize", new String[] { Integer.toString(program.size()),
				"300", Integer.toString(countFutureInstructions()),/*Integer.toString(maxUnits), */
				Integer.toString(minUnitPeriod) });
	}
	
	private int countFutureInstructions(){
	    final Iterator it=program.iterator();
	    int counter=0;
	    while(it.hasNext()){
	        if(((Instruction)it.next()).opcode==futureCode){
	            counter++;
	        }
	    }
	    return counter;
	}

	public void emitBFile(AProgramDeclarationList node) {
		int modeCount = 0;

		Collection collection = taskInvocationAddresses.values();

		for (Iterator iterator = collection.iterator(); iterator.hasNext();) {
			FixupChain fixupChain = (FixupChain) iterator.next();

			if (fixupChain.unit == 0)
				modeCount++;
		}

		emitBinaryCode(modeCount);

		for (Iterator iterator = collection.iterator(); iterator.hasNext();) {
			FixupChain fixupChain = (FixupChain) iterator.next();

			if (fixupChain.unit == 0)
				if (fixupChain.address >= 0) {
					emitBinaryName(fixupChain.modename);
					emitBinaryCode(fixupChain.address);
				}
		}

		for (Iterator iterator = collection.iterator(); iterator.hasNext();) {
			FixupChain fixupChain = (FixupChain) iterator.next();

			if (fixupChain.unit == 0)
				if (fixupChain.address < 0) {
					emitBinaryName(fixupChain.modename);
					emitBinaryCode(fixupChain.address);
				}
		}

		emitBinaryCode(program.size());
		emitBinaryCode(minUnitPeriod);

		for (ListIterator iterator = program.listIterator(); iterator.hasNext();) {
			Instruction instruction = (Instruction) iterator.next();

			emitBinaryCode(instruction.opcode);
			emitBinaryCode(instruction.arg1);
			emitBinaryCode(instruction.arg2);
			emitBinaryCode(instruction.arg3);
			emitBinaryCode(instruction.arg4);
		}
	}

	private class ComputeModeUnits extends DepthFirstAdapter {
		public void inAModeDeclaration(AModeDeclaration node) {
			ModeUnit modeUnit;

			node.apply(modeUnit = new ModeUnit(currentProgramName, symbolTable, inheritTable));

			final String modeName = node.getModeName().getText();

			modeUnits.put(modeName, modeUnit);
		}
	}
	
	private boolean isEnabled(int unitPeriod, int unit, int commPeriod, int commInstance) {
		return (unitPeriod * unit == commPeriod * commInstance);
	}
	
	private class GenTaskOutput extends DepthFirstAdapter {
		private ArrayList outputParameters = null;

		private int unit;

		private int nUnits;
		
		private int unitPeriod;
		
		private int modePeriod;
		
		private String modeName;

		public GenTaskOutput(int unit, int nUnits, int unitPeriod, int modePeriod, String modeName) {
			this.unit = unit;
			this.nUnits = nUnits;
			this.unitPeriod=unitPeriod;
			this.modePeriod=modePeriod;
			this.modeName=modeName;
		}

//		private class ComputeTaskOutputPorts extends DepthFirstAdapter {
//			public void outAActualPort(AActualPort node) {
//				final String outputPortName = node.getPortName().getText();
//
//				outputParameters.add(outputPortName);
//			}
//		}
//		
//		public void taskTermination(ALetTaskInvocation letTask){
//		    outputParameters = new ArrayList();
//
//			final String taskName = letTask.getTaskName().getText();
//
//			final ATaskDeclaration taskDeclaration = (ATaskDeclaration) symbolTable.tasks
//					.get(taskName);
//
//			taskDeclaration.apply(new ComputeTaskOutputPorts());
//			
//			outALetTaskInvocation(letTask);
//		}
//
//		public void inALetTaskInvocation(ALetTaskInvocation node) {
//			final int frequency = Integer.parseInt(node.getLetTaskFrequency()
//					.getText());
//			final int offset = Utils.getOffset(node);
//			final int duration = Utils.getDuration(node,modePeriod);
//
//			if (isEnabled(frequency,offset+duration, unit, nUnits,unitPeriod) && !Utils.isFloatDependency(node.getTaskName().getText(),modeName,dependencyTable)) {
//				outputParameters = new ArrayList();
//
//				final String taskName = node.getTaskName().getText();
//
//				final ATaskDeclaration taskDeclaration = (ATaskDeclaration) symbolTable.tasks
//						.get(taskName);
//
//				taskDeclaration.apply(new ComputeTaskOutputPorts());
//			}
//		}
//
//		public void outALetTaskInvocation(ALetTaskInvocation node) {
//			if (outputParameters != null) {
//				final String taskName = node.getTaskName().getText();
//
//				for (ListIterator outputIterator = outputParameters
//						.listIterator(); outputIterator.hasNext();) {
//					final String outputPortName = (String) outputIterator
//							.next();
//
//					final AOutputDeclaration outputDeclaration = (AOutputDeclaration) symbolTable.outputPorts
//							.get(outputPortName);
//
//					final String outputPortType = outputDeclaration
//							.getTypeName().getText();
//
//					final int driverIndex = functionTable.getCopyDriverIndex(
//							outputPortName, outputPortType);
//
//					program.add(new Instruction(callCode, driverIndex,
//							"Call output port copy driver: "
//									+ functionTable.getCopyDriverWrapperName(
//											outputPortName, outputPortType)
//									+ " for task: "
//									+ functionTable
//											.getTaskWrapperName(taskName)));
//				}
//
//				outputParameters = null;
//			}
//		}
	}
//
//	private boolean isPortOnHost(APortMappingAnnotation portMappingAnnotation) {
//		if (!pureGiotto && (hostStartName != null)
//				&& (portMappingAnnotation != null)) {
//			final String hostName = ((AHostNameIdent) portMappingAnnotation
//					.getHostName()).getIdent().getText();
//
//			if (hostName.compareTo(hostStartName) != 0)
//				return false;
//		}
//
//		return true;
//	}

	private class GenActuatorUpdate extends DepthFirstAdapter {
		private int unit;

		private int nUnits;
		
		private int unitPeriod;
		
		private String modeName;

		public GenActuatorUpdate(int unit, int nUnits,int unitPeriod, String modeName) {
			this.unit = unit;
			this.nUnits = nUnits;
			this.unitPeriod=unitPeriod;
			this.modeName=modeName;
		}

//		public void outAActuatorUpdate(AActuatorUpdate node) {
//			final String actuatorPortName = node.getActuatorPortName()
//					.getText();
//
//			final AActuatorDeclaration actuatorDeclaration = (AActuatorDeclaration) symbolTable.actuatorPorts
//					.get(actuatorPortName);
//
//			final APortMappingAnnotation portMappingAnnotation = (APortMappingAnnotation) actuatorDeclaration
//					.getPortAnnotation();
//
//			if (pureGiotto || isPortOnHost(portMappingAnnotation)) {
//				final int frequency = Integer.parseInt(node
//						.getActuatorFrequency().getText());
//				final int offset = Utils.getOffset(node);
//
//				if (isEnabled(frequency, offset, unit, nUnits, unitPeriod)) {
//					final String driverName = node.getDriverName().getText();
//
//					final int conditionIndex = functionTable.getConditionIndex(
//							actuatorPortName, driverName, modeName);
//					final int driverIndex = functionTable.getDriverIndex(
//							actuatorPortName, driverName, modeName);
//
//					final int thenAddress = program.size() + 1;
//					final int elseAddress = program.size() + 2;
//
//					program.add(new Instruction(ifCode, conditionIndex,
//							thenAddress, elseAddress, "If actuator driver: "
//									+ functionTable.getConditionWrapperName(
//											actuatorPortName, driverName, modeName)));
//					program.add(new Instruction(callCode, driverIndex,
//							"Call actuator driver: "
//									+ functionTable.getDriverWrapperName(
//											actuatorPortName, driverName, modeName)));
//				}
//			}
//		}
	}

	private class GenActuatorDeviceUpdate extends DepthFirstAdapter {
		private int unit;

		private int nUnits;
		
		private int unitPeriod;

		public GenActuatorDeviceUpdate(int unit, int nUnits, int unitPeriod) {
			this.unit = unit;
			this.nUnits = nUnits;
			this.unitPeriod=unitPeriod;
		}

//		public void outAActuatorUpdate(AActuatorUpdate node) {
//			final String actuatorPortName = node.getActuatorPortName()
//					.getText();
//
//			final AActuatorDeclaration actuatorDeclaration = (AActuatorDeclaration) symbolTable.actuatorPorts
//					.get(actuatorPortName);
//
//			final APortMappingAnnotation portMappingAnnotation = (APortMappingAnnotation) actuatorDeclaration
//					.getPortAnnotation();
//
//			if (pureGiotto || isPortOnHost(portMappingAnnotation)) {
//				final int frequency = Integer.parseInt(node
//						.getActuatorFrequency().getText());
//				final int offset = Utils.getOffset(node);
//				
//				if (isEnabled(frequency, offset, unit, nUnits, unitPeriod)) {
//					final ADeviceDriver deviceDriver = (ADeviceDriver) actuatorDeclaration
//							.getDeviceDriver();
//
//					if (deviceDriver != null) {
//						final String deviceDriverName = deviceDriver
//								.getDeviceDriverName().getText();
//
//						final int driverIndex = functionTable.getDriverIndex(
//								actuatorPortName, deviceDriverName);
//
//						program.add(new Instruction(callCode, driverIndex,
//								"Call actuator device driver: "
//										+ functionTable.getDriverWrapperName(
//												actuatorPortName,
//												deviceDriverName)));
//					}
//				}
//			}
//		}
	}
//
//	private boolean isTaskOnHost(ALetTaskInvocation taskInvocation) {
//		if (!pureGiotto && (hostStartName != null)) {
//			final ATaskAnnotation taskAnnotation = (ATaskAnnotation) taskInvocation
//					.getTaskAnnotation();
//
//			if (taskAnnotation != null) {
//				final String hostName = ((AHostNameIdent) taskAnnotation
//						.getHostName()).getIdent().getText();
//
//				if (hostName.compareTo(hostStartName) != 0)
//					return false;
//			}
//		}
//
//		return true;
//	}
//
//	private boolean isTaskOnHost(AFloatTaskInvocation taskInvocation) {
//		if (!pureGiotto && (hostStartName != null)) {
//			final ATaskAnnotation taskAnnotation = (ATaskAnnotation) taskInvocation
//					.getTaskAnnotation();
//
//			if (taskAnnotation != null) {
//				final String hostName = ((AHostNameIdent) taskAnnotation
//						.getHostName()).getIdent().getText();
//
//				if (hostName.compareTo(hostStartName) != 0)
//					return false;
//			}
//		}
//
//		return true;
//	}
	
	private class GenSensorDeviceUpdate extends DepthFirstAdapter {
		final private HashSet sensorPorts = new HashSet();
		
		protected static final int ALL_SENSOR_PORTS=1;
		protected static final int TASK_SENSOR_PORTS=2;
		protected static final int MODE_SWITCH_SENSOR_PORTS=3; 

		protected int unit;

		protected int nUnits;
		
		protected int unitPeriod;
		
		protected int sensorType;
		
		protected String modeName;

		public GenSensorDeviceUpdate(int unit, int nUnits,int unitPeriod, String modeName) {
			this.unit = unit;
			this.nUnits = nUnits;
			this.unitPeriod=unitPeriod;
			sensorType=ALL_SENSOR_PORTS;
			this.modeName=modeName;
		}

		protected class ComputeSensorPorts extends DepthFirstAdapter {
			public void outAActualPort(AActualPort node) {
//				final String portName = node.getPortName().getText();
//
//				if (symbolTable.sensorPorts.containsKey(portName)) {
//					final ASensorDeclaration sensorDeclaration = (ASensorDeclaration) symbolTable.sensorPorts
//							.get(portName);
//
//					final APortMappingAnnotation portMappingAnnotation = (APortMappingAnnotation) sensorDeclaration
//							.getPortAnnotation();
//
//					if (pureGiotto || isPortOnHost(portMappingAnnotation))
//						sensorPorts.add(portName);
//				}
			}
		}

		public void outAModeSwitch(AModeSwitch node) {
//			final int frequency = Integer.parseInt(node
//					.getModeSwitchFrequency().getText());
//
//			if (isEnabled(frequency, unit, nUnits)) {
//				final String driverName = node.getDriverName().getText();
//
//				final ADriverDeclaration driverDeclaration = (ADriverDeclaration) symbolTable.drivers
//						.get(driverName);
//
//				driverDeclaration.apply(new ComputeSensorPorts());
//			}
		}

//		public void outALetTaskInvocation(ALetTaskInvocation node) {
//			if (pureGiotto || isTaskOnHost(node)) {
//				final int frequency = Integer.parseInt(node.getLetTaskFrequency()
//						.getText());
//
//				if (isEnabled(frequency, unit, nUnits)) {
//					if (node.getDriverName() != null) {
//						final String driverName = node.getDriverName()
//								.getText();
//
//						final ADriverDeclaration driverDeclaration = (ADriverDeclaration) symbolTable.drivers
//								.get(driverName);
//
//						driverDeclaration.apply(new ComputeSensorPorts());
//					}
//				}
//			}
//		}
		
//		public void outAFloatTaskInvocation(AFloatTaskInvocation node) {
//			if (pureGiotto || isTaskOnHost(node)) {
//				final int frequency = Integer.parseInt(node.getFloatTaskFrequency()
//						.getText());
//
//				if (isEnabled(frequency, unit, nUnits)) {
//					if (node.getDriverName() != null) {
//						final String driverName = node.getDriverName()
//								.getText();
//
//						final ADriverDeclaration driverDeclaration = (ADriverDeclaration) symbolTable.drivers
//								.get(driverName);
//
//						driverDeclaration.apply(new ComputeSensorPorts());
//					}
//				}
//			}
//		}
		
		private class ComputeExplicitSensorUpdate extends DepthFirstAdapter{
//		    public void outASensorUpdate(ASensorUpdate node){
//		        final String sensorPortName=node.getSensorPortName().getText();
//		        final int frequency=Integer.parseInt(node.getSensorFrequency().getText());
//		        final int offset=Utils.getOffset(node);
//		        
//		        if(sensorType==MODE_SWITCH_SENSOR_PORTS && !modeSwitchSensorPorts.contains(sensorPortName))
//		            return;
//		        if(sensorType==TASK_SENSOR_PORTS && !taskSensorPorts.contains(sensorPortName))
//		            return;
//		        
//		        if(isEnabled(frequency,offset,unit,nUnits,unitPeriod)){
//		            if(!sensorPorts.contains(sensorPortName))
//			            sensorPorts.add(sensorPortName);
//		        }
//		        else{
//		            if(sensorPorts.contains(sensorPortName))
//		                sensorPorts.remove(sensorPortName);
//		        }
//		        
//		        	//test to see if it is a sensor on which depends a float task
//				if(Utils.isFloatDependency(sensorPortName,modeName,dependencyTable) && offset>0)
//				    if(sensorPorts.contains(sensorPortName))
//				        sensorPorts.remove(sensorPortName);
//		    }
		}

		public void outAModeDeclaration(AModeDeclaration node) {
		    node.apply(new ComputeExplicitSensorUpdate());
			for (Iterator sensorIterator = sensorPorts.iterator(); sensorIterator
					.hasNext();) {
				final String sensorPortName = (String) sensorIterator.next();

//				final ASensorDeclaration sensorDeclaration = (ASensorDeclaration) symbolTable.sensorPorts
//						.get(sensorPortName);
//
//				final APortMappingAnnotation portMappingAnnotation = (APortMappingAnnotation) sensorDeclaration
//						.getPortAnnotation();
//
//				if (pureGiotto || isPortOnHost(portMappingAnnotation)) {
//					final ADeviceDriver deviceDriver = (ADeviceDriver) sensorDeclaration
//							.getDeviceDriver();
//
//					if (deviceDriver != null) {
//						final String deviceDriverName = deviceDriver
//								.getDeviceDriverName().getText();
//
//						final int driverIndex = functionTable.getDriverIndex(
//								sensorPortName, deviceDriverName);
//
//						program.add(new Instruction(callCode, driverIndex,
//								"Call sensor device driver: "
//										+ functionTable.getDriverWrapperName(
//												sensorPortName,
//												deviceDriverName)));
//					}
//				}
			}
		}
	}

	private class GenSensorDeviceUpdateForModeSwitches extends
			GenSensorDeviceUpdate {
		public GenSensorDeviceUpdateForModeSwitches(int unit, int nUnits,int unitPeriod, String modeName) {
			super(unit, nUnits,unitPeriod, modeName);
			sensorType=MODE_SWITCH_SENSOR_PORTS;
		}

//		public void outALetTaskInvocation(ALetTaskInvocation node) {
//			// Overwrite to empty method because here we are only interested in
//			// mode switches
//		}
//		
//		public void outAFloatTaskInvocation(AFloatTaskInvocation node) {
//			// Overwrite to empty method because here we are only interested in
//			// mode switches
//		}
	}

	private class GenSensorDeviceUpdateForTaskInvocations extends
			GenSensorDeviceUpdate {
		public GenSensorDeviceUpdateForTaskInvocations(int unit, int nUnits,int unitPeriod, String modeName) {
			super(unit, nUnits, unitPeriod, modeName);
			sensorType=TASK_SENSOR_PORTS;
		}

		public void outAModeSwitch(AModeSwitch node) {
			// Overwrite to empty method because here we are only interested in
			// task invocations
		}
	}

	private class PreemptedTasksHyperPeriod extends DepthFirstAdapter {
		private int unit;

		private int nUnits;

		public boolean preemptedTasks = false;

		public int hyperPeriod = 1;

		public PreemptedTasksHyperPeriod(String modeName, int unit) {
			this.unit = unit;

			final ModeUnit modeUnit = (ModeUnit) modeUnits.get(modeName);

			this.nUnits = modeUnit.nUnits;
		}

//		public void outALetTaskInvocation(ALetTaskInvocation node) {
//			final int frequency = Integer.parseInt(node.getLetTaskFrequency()
//					.getText());
//
//			if (!isEnabled(frequency, unit, nUnits)) {
//				preemptedTasks = true;
//
//				hyperPeriod = ModeUnit.lcm(nUnits / frequency, hyperPeriod);
//			}
//		}
//		
//		public void outAFloatTaskInvocation(AFloatTaskInvocation node) {
//			final int frequency = Integer.parseInt(node.getFloatTaskFrequency()
//					.getText());
//
//			if (!isEnabled(frequency, unit, nUnits)) {
//				preemptedTasks = true;
//
//				hyperPeriod = ModeUnit.lcm(nUnits / frequency, hyperPeriod);
//			}
//		}
	}

	private class GenModeSwitches extends DepthFirstAdapter {
		private String modeName;

		private int unit;

		private int nUnits;

		private int modePeriod;

		private PreemptedTasksHyperPeriod preemptedTasksHyperPeriod;

		private int scheduleTime;

		public GenModeSwitches(String modeName, int unit,
				PreemptedTasksHyperPeriod preemptedTasksHyperPeriod,
				int scheduleTime) {
			this.modeName = modeName;
			this.unit = unit;

			final ModeUnit modeUnit = (ModeUnit) modeUnits.get(modeName);

			this.nUnits = modeUnit.nUnits;
			this.modePeriod = modeUnit.modePeriod;

			this.preemptedTasksHyperPeriod = preemptedTasksHyperPeriod;

			this.scheduleTime = scheduleTime;
		}

		public void outAModeSwitch(AModeSwitch node) {
//			final int frequency = Integer.parseInt(node
//					.getModeSwitchFrequency().getText());
//
//			if (isEnabled(frequency, unit, nUnits)) {
//				final String targetModeName = node.getModeName().getText();
//
//				int newUnit = 0;
//				int newDelta = 0;
//
//				if (!dynamicGiotto
//						|| symbolTable.modes.containsKey(targetModeName)) {
//					// In non-dynamic Giotto
//					// symbolTable.modes.containsKey(targetModeName) is true
//					// because we checked this in TypeChecker
//					final ModeUnit modeUnit = (ModeUnit) modeUnits
//							.get(targetModeName);
//
//					final int nTargetUnits = modeUnit.nUnits;
//					final int targetModePeriod = modeUnit.modePeriod;
//
//					if (unit != 0 && preemptedTasksHyperPeriod.preemptedTasks) {
//						final int hyperPeriod = preemptedTasksHyperPeriod.hyperPeriod;
//						final int delta = (hyperPeriod - (unit % hyperPeriod))
//								* (modePeriod / nUnits);
//
//						newDelta = delta % (targetModePeriod / nTargetUnits);
//						newUnit = (nTargetUnits - ((delta - newDelta) * nTargetUnits)
//								/ targetModePeriod)
//								% nTargetUnits;
//
//						// System.out.println("mode: " + modeName + ", unit: " +
//						// unit +
//						// ", hyper: " + hyperPeriod + ", delta: " + delta +
//						// ", newDelta: " + newDelta + ", newUnit: " + newUnit);
//					}
//				}
//
//				String declaredModeName;
//
//				if (dynamicGiotto
//						&& !symbolTable.modes.containsKey(targetModeName))
//					declaredModeName = "";
//				else
//					declaredModeName = targetModeName;
//
//				final String driverName = node.getDriverName().getText();
//
//				final int conditionIndex = functionTable.getConditionIndex(
//						declaredModeName, driverName, modeName);
//				final int driverIndex = functionTable.getDriverIndex(
//						declaredModeName, driverName, modeName);
//
//				final int ifAddress = program.size();
//				final int thenAddress = ifAddress + 1;
//
//				int elseAddress = ifAddress + 3;
//
//				if (newDelta > 0)
//					elseAddress++;
//
//				program.add(new Instruction(ifCode, conditionIndex,
//						thenAddress, elseAddress, "If mode driver: "
//								+ functionTable.getConditionWrapperName(
//										declaredModeName, driverName, modeName)));
//
//				program.add(new Instruction(callCode, driverIndex,
//						"Call mode driver: "
//								+ functionTable.getDriverWrapperName(
//										declaredModeName, driverName, modeName)));
//
//				final String unitModeName = targetModeName
//						+ Integer.toString(newUnit);
//
//				if (newDelta > 0) {
//					final int futureAddress = ifAddress + 2;
//
//					// -1 indicates end of fixup chain
//					int modeAddress = -1;
//
//					if (modeAddresses.containsKey(unitModeName)) {
//						final FixupChain fixupChain = (FixupChain) modeAddresses
//								.get(unitModeName);
//						modeAddress = fixupChain.address;
//
//						if (modeAddress < 0)
//							// Negative addresses need fixup
//							// We add 2 in order to be able to handle
//							// 'jumpAddress == 0' and 'jumpAddress == 1'
//							modeAddresses.put(unitModeName, new FixupChain(
//									-(futureAddress + 2), newUnit,
//									targetModeName));
//					} else
//						modeAddresses.put(unitModeName, new FixupChain(
//								-(futureAddress + 2), newUnit, targetModeName));
//
//					if (newDelta - scheduleTime < 0)
//						throw new RuntimeException("Mode switch from mode: "
//								+ modeName + ", unit: " + unit + " to mode: "
//								+ targetModeName + ", unit: " + newUnit
//								+ " too much delayed.");
//
//					program.add(new Instruction(futureCode, giottoTriggerIndex,
//							modeAddress, newDelta - scheduleTime,0,
//							"Triggered jump from mode: " + modeName
//									+ ", unit: " + unit + " to mode: "
//									+ targetModeName + ", unit: " + newUnit));
//
//					// Generate return
//					program.add(new Instruction(returnCode,
//							"From delayed mode switch in mode: " + modeName
//									+ ", unit: " + unit));
//				} else {
//					final int jumpAddress = ifAddress + 2;
//
//					// -1 indicates end of fixup chain
//					int taskInvocationAddress = -1;
//
//					if (taskInvocationAddresses.containsKey(unitModeName)) {
//						final FixupChain fixupChain = (FixupChain) taskInvocationAddresses
//								.get(unitModeName);
//						taskInvocationAddress = fixupChain.address;
//
//						if (taskInvocationAddress < 0)
//							// Negative addresses need fixup
//							// We add 2 in order to be able to handle
//							// 'jumpAddress == 0' and 'jumpAddress == 1'
//							taskInvocationAddresses.put(unitModeName,
//									new FixupChain(-(jumpAddress + 2), newUnit,
//											targetModeName));
//					} else
//						taskInvocationAddresses.put(unitModeName,
//								new FixupChain(-(jumpAddress + 2), newUnit,
//										targetModeName));
//
//					program.add(new Instruction(jumpCode,
//							taskInvocationAddress, " Switch from mode: "
//									+ modeName + ", unit: " + unit
//									+ " to mode: " + targetModeName
//									+ ", unit: " + newUnit));
//				}
//			}
//		}
	}

	private void fixupFuture(Instruction instruction, int address) {
		if (instruction.opcode == futureCode) {
			final int nextAddress = instruction.arg2;

			instruction.arg2 = address;

			if (nextAddress < -1)
				fixupFuture((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-future instruction.");
	}

	private void fixupJump(Instruction instruction, int address) {
		if (instruction.opcode == jumpCode) {
			final int nextAddress = instruction.arg1;

			instruction.arg1 = address;

			if (nextAddress < -1)
				fixupJump((Instruction) program.get(-(nextAddress + 2)),
						address);
		} else
			throw new RuntimeException("Fixup on non-jump instruction.");
	}

//	private class GenTaskRelease extends DepthFirstAdapter {
//		private int unit;
//
//		private int nUnits;
//
//		private int modePeriod;
//		
//		private int unitPeriod;
//
//		private int releaseTime;
//		
//		private String modeName;
//
//		public GenTaskRelease(int unit, int nUnits, int modePeriod,
//				int releaseTime, String modeName) {
//			this.unit = unit;
//			this.nUnits = nUnits;
//			this.modePeriod = modePeriod;
//			this.unitPeriod=modePeriod/nUnits;
//
//			this.releaseTime = releaseTime;
//			this.modeName=modeName;
//		}

//		public void outALetTaskInvocation(ALetTaskInvocation node) {
//			if (pureGiotto || isTaskOnHost(node)) {
//				final int frequency = Integer.parseInt(node.getLetTaskFrequency()
//						.getText());
//				final int offset = Utils.getOffset(node);
//
//				if (isEnabled(frequency, offset, unit, nUnits, unitPeriod)) {
//					final String taskName = node.getTaskName().getText();
//
//					final ATaskAnnotation taskAnnotation = (ATaskAnnotation) node
//							.getTaskAnnotation();
//
//					boolean isTaskAnnotated = false;
//
//					if (!pureGiotto && (taskAnnotation != null))
//						if (taskAnnotation.getScheduleConnectionList() != null)
//							isTaskAnnotated = true;
//
//					if (node.getDriverName() != null) {
//						final String driverName = node.getDriverName()
//								.getText();
//
//						final int conditionIndex = functionTable
//								.getConditionIndex(taskName, driverName, modeName);
//						final int driverIndex = functionTable.getDriverIndex(
//								taskName, driverName,modeName);
//
//						final int thenAddress = program.size() + 1;
//						int elseAddress = program.size() + 3;
//
//						if (isTaskAnnotated)
//							// Skip release insruction for message task
//							// generated below
//							elseAddress++;
//
//						program.add(new Instruction(ifCode, conditionIndex,
//								thenAddress, elseAddress, "If task driver: "
//										+ functionTable
//												.getConditionWrapperName(
//														taskName, driverName,modeName)));
//						program.add(new Instruction(callCode, driverIndex,
//								"Call task driver: "
//										+ functionTable.getDriverWrapperName(
//												taskName, driverName,modeName)));
//					}
//
//					int relativeDeadline = modePeriod / frequency - releaseTime;
//
//					// Task annotation
//
//					if (isTaskAnnotated) {
//						final int messageIndex = functionTable.getMessageIndex(
//								currentModeName, taskName);
//
//						final int releaseMessageTime = relativeDeadline >> 1;
//
//						program.add(new Instruction(releaseCode, messageIndex,
//								0, releaseMessageTime
//										+ (relativeDeadline << 12),
//								"Release message: "
//										+ functionTable.getMessageWrapperName(
//												currentModeName, taskName)
//										+ ", release time: "
//										+ releaseMessageTime
//										+ ", relative deadline: "
//										+ relativeDeadline));
//
//						minUnitPeriod = ModeUnit.gcd(releaseMessageTime,
//								minUnitPeriod);
//
//						relativeDeadline = releaseMessageTime;
//					}
//
//					// Release task
//
//					final int taskIndex = functionTable.getTaskIndex(taskName);
//
//					// FIXME: Trivial release time: 0, only one annotation:
//					// index 0
//					program.add(new Instruction(releaseCode, taskIndex, 0,
//							0 + (relativeDeadline << 12), "Release task: "
//									+ functionTable
//											.getTaskWrapperName(taskName)
//									+ ", release time: " + "0"
//									+ ", relative deadline: "
//									+ relativeDeadline));
//				}
//			}
//		}
//	}
	
	/**
	 * Compute:
	 * <lu>
	 * <li>future sensors updates</li>
	 * <li>future let tasks terminations</li>
	 * <li>float tasks that depends on nothing</li>
	 * <li>float tasks that depends on something </li>
	 * </lu>
	 * This should be used only for AModeDeclaration nodes
	 * 
	 * @author Daniel Iercan, daniel.iercan@cs.uni-salzburg.at
	 *
	 */
//	private class ComputeFutureSets extends DepthFirstAdapter {
//		private int unit;
//
//		private int nUnits;
//
//		private int modePeriod;
//		
//		private int unitPeriod;
//		
//		private String modeName;
//		
//		public final ArrayList sensorUpdates=new ArrayList();
//	    public final ArrayList taskTerms=new ArrayList();
//	    public final ArrayList floatTaskInfo=new ArrayList();
//	    public final ArrayList floatTaskImm=new ArrayList();
//
//		public ComputeFutureSets(int unit, int nUnits, int modePeriod,String modeName) {
//			this.unit = unit;
//			this.nUnits = nUnits;
//			this.modePeriod = modePeriod;
//			this.unitPeriod=modePeriod/nUnits;
//			this.modeName=modeName;
//		}
		
//		public void outASensorUpdate(ASensorUpdate node){
//		    final String portName=node.getSensorPortName().getText();
//		    final int offset=Utils.getOffset(node);
//		    final int frequency=Integer.parseInt(node.getSensorFrequency().getText());
//		    
//		    if(isEnabled(frequency,unit,nUnits) && Utils.isFloatDependency(portName,modeName,dependencyTable) && offset>0){
//		        sensorUpdates.add(node);
//		    }
//		}
//		
//		public void outALetTaskInvocation(ALetTaskInvocation node){
//		    final String taskName=node.getTaskName().getText();
//		    final int frequency=Integer.parseInt(node.getLetTaskFrequency().getText());
//		    
//		    if(isEnabled(frequency,unit,nUnits) && Utils.isFloatDependency(taskName,modeName,dependencyTable)){
//		        taskTerms.add(node);
//		    }
//		}
//		
//		public void outAFloatTaskInvocation(AFloatTaskInvocation node){
//		    final String taskName=node.getTaskName().getText();
//		    final int frequency=Integer.parseInt(node.getFloatTaskFrequency().getText());
//		    
//		    if(isEnabled(frequency,unit,nUnits)){
//		        if(!Utils.dependsOnFloatTask(taskName,modeName,dependencyTable) && Utils.getMaxDependencyOffset(taskName,modeName,modePeriod,dependencyTable)<=0){
//		            floatTaskImm.add(node);
//		        }
//		        else
//		            floatTaskInfo.add(node);
//		    }
//		}
//	}

	private class GenProgramECode extends DepthFirstAdapter{
		
		public void outAProgramDeclaration(AProgramDeclaration node){
			String programName = node.getProgramName().getText();
			int programAddress = program.size();
			FixupChain fixupChain;
			
			if(programAddresses.containsKey(programName)){
				fixupChain = (FixupChain)programAddresses.get(programName);
				final int fixupProgramAddress = fixupChain.address;

				if (fixupProgramAddress < -1) {
					fixupJump((Instruction) program
							.get(-(fixupProgramAddress + 2)),
							programAddress);

					taskInvocationAddresses.put(unitModeName,
							new FixupChain(taskInvocationAddress, unit,
									modeName));
				} else if (fixupTaskInvocationAddress == -1)
					throw new RuntimeException("Fixup error.");
				else
					throw new RuntimeException(
							"Ambiguous mode name declaration.");
			} else
				taskInvocationAddresses.put(unitModeName, new FixupChain(
						taskInvocationAddress, unit, modeName));
				
		}
		
		public void outACommunicatorDeclaration(ACommunicatorDeclaration node){
	    	String name = node.getCommunicatorName().getText();
	    	String initDriver = node.getInitDriver().getText();
	    	
	    	// init driver for each communicator
			final int driverIndex = functionTable.getInitCommDriverIndex(currentProgramName, name, initDriver);

			program.add(new Instruction(callCode, driverIndex,
					"Call initialization driver: "
					+ functionTable.getInitCommDriverWrapperName(currentProgramName, name, initDriver)));
	    }
		
		public void outAModuleDeclaration(AModeDeclaration node){
			//generate future 0 to each module in the program
		}
		
		public void outProgramDeclaration(AProgramDeclaration node){
			program.add(new Instruction(returnCode, "Return from the program."));
		}
	}
	
	private class GenECode extends DepthFirstAdapter {
	    private boolean inModeSwitch=true;
	
	    public void inAProgramDeclarationList(AProgramDeclarationList node){
	    	programAddresses = new Hashtable();
	    }
	    
	    public void outAProgramDeclarationList(AProgramDeclarationList node){
	    	programAddresses = null;
	    } 
	    
	    public void inAProgramDeclaration(AProgramDeclaration node){
	    	currentProgramName = node.getProgramName().getText();
	    	programSymbolTable = (ProgramSymbolTable)symbolTable.programs.get(currentProgramName);
	    
	    	moduleAddresses = new Hashtable();
	    	    	
	    	node.apply(new GenProgramECode());
	    }
	    
	    public void outAProgramDeclaration(AProgramDeclaration node){
	    	currentProgramName = null;
	    	moduleAddresses = null;
	    }

	    public void inAModuleDeclaration(AModuleDeclaration node){
	    	currentModuleName = node.getModuleName().getText();
	    	modeAddresses = new Hashtable();
	    	taskInvocationAddresses = new Hashtable();
	    }
	    
	    public void outAModuleDeclaration(AModuleDeclaration node){
	    	currentModuleName = null;
	    	modeAddresses = null;
	    	taskInvocationAddresses = null;
	    }
	    
//		public void outAOutputDeclaration(AOutputDeclaration node) {
//			final String outputPortName = node.getPortName().getText();
//			final String initializationDriverName = node
//					.getInitializationDriver().getText();
//
//			final int driverIndex = functionTable.getInitOutputDriverIndex(
//					outputPortName, initializationDriverName);
//
//			program.add(new Instruction(callCode, driverIndex,
//					"Call initialization driver: "
//							+ functionTable.getInitOutputDriverWrapperName(
//									outputPortName, initializationDriverName)));
//		}
//
//		public void inATaskDeclaration(ATaskDeclaration node) {
//			currentTaskName = node.getTaskName().getText();
//		}
//
//		public void outAStatePort(AStatePort node) {
//			final String statePortName = node.getPortName().getText();
//			final String initializationDriverName = node
//					.getInitializationDriver().getText();
//
//			final int driverIndex = functionTable.getInitStateDriverIndex(
//					currentTaskName, statePortName, initializationDriverName);
//
//			program.add(new Instruction(callCode, driverIndex,
//					"Call initialization driver: "
//							+ functionTable.getInitStateDriverWrapperName(
//									currentTaskName, statePortName,
//									initializationDriverName)));
//		}
//
//		public void outATaskDeclaration(ATaskDeclaration node) {
//			currentTaskName = null;
//		}
//
//		public void inAModeDeclarationSequence(AModeDeclarationSequence node) {
//			final String modeName = node.getModeName().getText();
//
//			startModeName = modeName;
//
//			final int jumpAddress = program.size();
//
//			// -1 indicates end of fixup chain
//			int modeAddress = -1;
//
//			startModeAddress = -(jumpAddress + 2);
//
//			program.add(new Instruction(jumpCode, modeAddress,
//					"Jump to start mode: " + startModeName));
//
//			modeAddresses = new Hashtable();
//			taskInvocationAddresses = new Hashtable();
//		}
//
//		public void inAModeDeclaration(AModeDeclaration node) {
//			currentModeName = node.getModeName().getText();
//			modeSwitchSensorPorts.clear();
//			taskSensorPorts.clear();
//		}
//
//		private boolean isAnnotationEnabledForHost(
//				AModeConnectionAnnotation modeConnectionAnnotation) {
//			if (!pureGiotto && (hostStartName != null)) {
//				final String hostName = ((AHostNameIdent) modeConnectionAnnotation
//						.getHostName()).getIdent().getText();
//
//				if (hostName.compareTo(hostStartName) == 0)
//					return true;
//			}
//
//			return false;
//		}
//		
//		protected class ComputeSensorPorts extends DepthFirstAdapter {
//			public void outAActualPort(AActualPort node) {
//				final String portName = node.getPortName().getText();
//
//				if (symbolTable.sensorPorts.containsKey(portName)) {
//					final ASensorDeclaration sensorDeclaration = (ASensorDeclaration) symbolTable.sensorPorts
//							.get(portName);
//
//					final APortMappingAnnotation portMappingAnnotation = (APortMappingAnnotation) sensorDeclaration
//							.getPortAnnotation();
//
//					if (pureGiotto || isPortOnHost(portMappingAnnotation)){
//					    if(inModeSwitch){
//					        modeSwitchSensorPorts.add(portName);
//					    }
//					    else{
//					        taskSensorPorts.add(portName);
//					    }
//					}
//				}
//			}
//		}
//
//		public void outAModeSwitch(AModeSwitch node) {
//			final int frequency = Integer.parseInt(node
//					.getModeSwitchFrequency().getText());
//			
//			final String driverName = node.getDriverName().getText();
//
//			final ADriverDeclaration driverDeclaration = (ADriverDeclaration) symbolTable.drivers
//					.get(driverName);
//
//			inModeSwitch=true;
//			driverDeclaration.apply(new ComputeSensorPorts());
//		}
//
//		public void outALetTaskInvocation(ALetTaskInvocation node) {
//			if (pureGiotto || isTaskOnHost(node)) {
//				final int frequency = Integer.parseInt(node.getLetTaskFrequency()
//						.getText());
//
//				if (node.getDriverName() != null) {
//					final String driverName = node.getDriverName()
//							.getText();
//
//					final ADriverDeclaration driverDeclaration = (ADriverDeclaration) symbolTable.drivers
//							.get(driverName);
//
//					inModeSwitch=false;
//					driverDeclaration.apply(new ComputeSensorPorts());
//				}
//			}
//		}
//
//		public void outAFloatTaskInvocation(AFloatTaskInvocation node) {
//			if (pureGiotto || isTaskOnHost(node)) {
//				final int frequency = Integer.parseInt(node.getFloatTaskFrequency()
//						.getText());
//
//				if (node.getDriverName() != null) {
//					final String driverName = node.getDriverName()
//							.getText();
//
//					final ADriverDeclaration driverDeclaration = (ADriverDeclaration) symbolTable.drivers
//							.get(driverName);
//
//					inModeSwitch=false;
//					driverDeclaration.apply(new ComputeSensorPorts());
//				}
//			}
//		}
//		
//		public void outAModeDeclaration(AModeDeclaration node) {
//			final String modeName = node.getModeName().getText();
//			final ModeUnit modeUnit = (ModeUnit) modeUnits.get(modeName);
//
//			final int modePeriod = modeUnit.modePeriod;
//			final int nUnits = modeUnit.nUnits;
//			final int unitPeriod = modePeriod / nUnits;
//
//			final int modeAddressZero = program.size();
//
//			if (modeName.compareTo(startModeName) == 0)
//				fixupJump((Instruction) program.get(-(startModeAddress + 2)),
//						modeAddressZero);
//
//			for (int unit = 0; unit < nUnits; unit++) {
//				// Fixup of mode switch futures (only necessary for non-harmonic
//				// mode switching)
//				final String unitModeName = modeName + Integer.toString(unit);
//
//				final int modeAddress = program.size();
//
//				if (modeAddresses.containsKey(unitModeName)) {
//					final FixupChain fixupChain = (FixupChain) modeAddresses
//							.get(unitModeName);
//					final int fixupModeAddress = fixupChain.address;
//
//					if (fixupModeAddress < -1) {
//						fixupFuture((Instruction) program
//								.get(-(fixupModeAddress + 2)), modeAddress);
//
//						modeAddresses.put(unitModeName, new FixupChain(
//								modeAddress, unit, modeName));
//					} else if (fixupModeAddress == -1)
//						throw new RuntimeException("Fixup error.");
//					else
//						throw new RuntimeException(
//								"Ambiguous mode name declaration.");
//				} else
//					modeAddresses.put(unitModeName, new FixupChain(modeAddress,
//							unit, modeName));
//
//				// Generate task output port update calls
//				node.apply(new GenTaskOutput(unit, nUnits,unitPeriod,modePeriod, modeName));
//
//				// Generate actuator update calls
//				node.apply(new GenActuatorUpdate(unit, nUnits, unitPeriod,modeName));
//
//				// Generate actuator device driver calls
//				node.apply(new GenActuatorDeviceUpdate(unit, nUnits, unitPeriod));
//				
//				if(pureGiotto)
//				    node.apply(new GenSensorDeviceUpdateForModeSwitches(unit, nUnits,unitPeriod,modeName));
//				else
//				    node.apply(new GenSensorDeviceUpdate(unit, nUnits,unitPeriod,modeName));
//
//				if (!pureGiotto && (node.getModeConnectionAnnotation() != null)) {
//					final AModeConnectionAnnotation modeConnectionAnnotation = (AModeConnectionAnnotation) node
//							.getModeConnectionAnnotation();
//
//					if (modeConnectionAnnotation.getScheduleConnectionList() != null) {
//						if (isAnnotationEnabledForHost(modeConnectionAnnotation)) {
//							final int messageIndex = functionTable
//									.getMessageIndex(currentModeName);
//
//							program
//									.add(new Instruction(
//											releaseCode,
//											messageIndex,
//											0,
//											0 + (modeConnectionPeriod << 12),
//											"Release message: "
//													+ functionTable
//															.getMessageWrapperName(currentModeName)
//													+ ", release time: " + "0"
//													+ ", relative deadline: "
//													+ modeConnectionPeriod));
//						}
//					}
//				}
//
//				int scheduleTime;
//
//				if (!pureGiotto && isThereAModeConnectionAnnotation) {
//					final int modeSwitchesAddress = program.size() + 2;
//
//					program.add(new Instruction(futureCode, giottoTriggerIndex,
//							modeSwitchesAddress, modeConnectionPeriod,0,
//							"Triggered jump to mode switches in mode: "
//									+ modeName + ", unit: " + unit));
//
//					// Generate return
//					program.add(new Instruction(returnCode,
//							"From output, actuator, sensor update in mode: "
//									+ modeName + ", unit: " + unit));
//
//					scheduleTime = modeConnectionPeriod;
//				} else
//					scheduleTime = 0;
//
//				// Compute hyper period of preempted tasks
//				PreemptedTasksHyperPeriod preemptedTasksHyperPeriod;
//
//				node
//						.apply(preemptedTasksHyperPeriod = new PreemptedTasksHyperPeriod(
//								modeName, unit));
//
//				// Generate mode switch checks
//				node.apply(new GenModeSwitches(modeName, unit,
//						preemptedTasksHyperPeriod, scheduleTime));
//
//				// Fixup of mode switch jumps
//				final int taskInvocationAddress = program.size();
//
//				if (taskInvocationAddresses.containsKey(unitModeName)) {
//					final FixupChain fixupChain = (FixupChain) taskInvocationAddresses
//							.get(unitModeName);
//					final int fixupTaskInvocationAddress = fixupChain.address;
//
//					if (fixupTaskInvocationAddress < -1) {
//						fixupJump((Instruction) program
//								.get(-(fixupTaskInvocationAddress + 2)),
//								taskInvocationAddress);
//
//						taskInvocationAddresses.put(unitModeName,
//								new FixupChain(taskInvocationAddress, unit,
//										modeName));
//					} else if (fixupTaskInvocationAddress == -1)
//						throw new RuntimeException("Fixup error.");
//					else
//						throw new RuntimeException(
//								"Ambiguous mode name declaration.");
//				} else
//					taskInvocationAddresses.put(unitModeName, new FixupChain(
//							taskInvocationAddress, unit, modeName));
//
//				//sensor updates
//				if(pureGiotto)
//				    node.apply(new GenSensorDeviceUpdateForTaskInvocations(unit, nUnits,unitPeriod,modeName));
//				
//				// Generate task scheduling
//				node.apply(new GenTaskRelease(unit, nUnits, modePeriod,
//						scheduleTime,modeName));
//				
//				ComputeFutureSets futureSets;
//				node.apply(futureSets=new ComputeFutureSets(unit,nUnits,modePeriod,modeName));
//
//				//release float task that do not depend on any thing or depend 
//				//on sensors with zero offsets
//				final Iterator itImm=futureSets.floatTaskImm.iterator();
//				while(itImm.hasNext()){
//				    final AFloatTaskInvocation floatImm=(AFloatTaskInvocation)itImm.next();
//				    releaseFloatTask(floatImm,modePeriod,scheduleTime,modeName);
//				}
//				
//				//genereate future sensors updates
//				Iterator itSensor=futureSets.sensorUpdates.iterator();
//				while(itSensor.hasNext()){
//				    final ASensorUpdate sensorUpdate=(ASensorUpdate)itSensor.next();
//				    final int sensorUpdateAddress=program.size();
//				    final String sensorPortName=sensorUpdate.getSensorPortName().getText();
//				    final FixupChain sensorAdrChain=new FixupChain(-sensorUpdateAddress-2,unit,modeName);
//				    final int offset=Utils.getOffset(sensorUpdate);
//				    
//				    modeAddresses.put(modeName+":sensor_update"+sensorPortName,sensorAdrChain);
//				    
//				    program
//					.add(new Instruction(futureCode,
//							giottoTriggerIndex, -1,
//							offset,0,
//							"Triggered jump to sensor update: " + sensorPortName));
//				}
//				
//				// genereate future task termination
//				Iterator itTask=futureSets.taskTerms.iterator();
//				while(itTask.hasNext()){
//				    final ALetTaskInvocation letTask=(ALetTaskInvocation)itTask.next();
//				    final int letTaskAddress=program.size();
//				    final String taskName=letTask.getTaskName().getText();
//				    final FixupChain letTaskAdrChain=new FixupChain(-letTaskAddress-2,unit,modeName);
//				    final int offset=Utils.getOffset(letTask);
//				    final int duration=Utils.getDuration(letTask,modePeriod);
//				    
//				    modeAddresses.put(modeName+":let_task_term"+taskName,letTaskAdrChain);
//				    
//				    program
//					.add(new Instruction(futureCode,
//							giottoTriggerIndex, -1,
//							offset+duration,0,
//							"Triggered jump to LET task termination: " + taskName));
//				}
//				
//				// genereate future fro float task release
//				Iterator itFloatInfo=futureSets.floatTaskInfo.iterator();
//				while(itFloatInfo.hasNext()){
//				    final AFloatTaskInvocation floatTask=(AFloatTaskInvocation)itFloatInfo.next();
//				    final int floatTaskAddress=program.size();
//				    final String taskName=floatTask.getTaskName().getText();
//				    final FixupChain floatTaskAdrChain=new FixupChain(-floatTaskAddress-2,unit,modeName);
//				    final int maxOffset=Utils.getMaxDependencyOffset(taskName,modeName,modePeriod,dependencyTable);
//				    
//				    modeAddresses.put(modeName+":float_task"+taskName,floatTaskAdrChain);
//				    
//				    program
//					.add(new Instruction(futureCode,
//							giottoTriggerIndex, -1,
//							maxOffset,(int)computeDependency(taskName,modeName),
//							"Triggered jump to float task release: " + taskName));
//				}
//				
//				// Generate jump to next unit
//				if (unit == nUnits - 1)
//					program
//							.add(new Instruction(futureCode,
//									giottoTriggerIndex, modeAddressZero,
//									unitPeriod - scheduleTime,0,
//									"Triggered jump to mode: " + modeName
//											+ ", unit: 0"));
//				else {
//					int nextUnitAddress = -1;
//					final String nextUnitModeName = modeName + Integer.toString(unit+1);
//
//					final int nextModeAddress = -(program.size()+2);
//
//					final FixupChain fixupChain;
//					
//					if (modeAddresses.containsKey(nextUnitModeName)) {
//						fixupChain = (FixupChain) modeAddresses
//								.get(nextUnitModeName);
//						if(fixupChain.address<0)
//						    nextUnitAddress=fixupChain.address;
//						fixupChain.address=nextModeAddress;
//					}
//					else{
//					    fixupChain=new FixupChain(nextModeAddress,unit+1,modeName);
//					    modeAddresses.put(nextUnitModeName,fixupChain);
//					}
//
//					program.add(new Instruction(futureCode, giottoTriggerIndex,
//							nextUnitAddress, unitPeriod - scheduleTime,0,
//							"Triggered jump to mode: " + modeName + ", unit: "
//									+ Integer.toString(unit + 1)));
//				}
//
//				// Generate return
//				program.add(new Instruction(returnCode, "From mode: "
//						+ modeName + ", unit: " + unit));
//				
//				//genereate sensors updates code
//				itSensor=futureSets.sensorUpdates.iterator();
//				while(itSensor.hasNext()){
//				    final ASensorUpdate sensorUp=(ASensorUpdate)itSensor.next();
//				    final int sensorUpdateAddress=program.size();
//				    final String sensorPortName=sensorUp.getSensorPortName().getText();
//				    final FixupChain sensorAdrChain=(FixupChain)modeAddresses.get(modeName+":sensor_update"+sensorPortName);
//				    final int offset=Utils.getOffset(sensorUp);
//				    
//				    //resolve address
//				    final Instruction instruction=(Instruction)program.get(-(sensorAdrChain.address+2));
//				    fixupFuture(instruction,sensorUpdateAddress);
//				    sensorAdrChain.address=sensorUpdateAddress;
//				    
//				    sensorUpdate(sensorUp);
//				    
//				    program.add(new Instruction(returnCode, "From sensor update: "
//							+ sensorPortName));
//				}
//				
//				// genereate future task termination
//				itTask=futureSets.taskTerms.iterator();
//				while(itTask.hasNext()){
//				    final ALetTaskInvocation letTask=(ALetTaskInvocation)itTask.next();
//				    final int letTaskAddress=program.size();
//				    final String taskName=letTask.getTaskName().getText();
//				    final FixupChain letTaskAdrChain=(FixupChain)modeAddresses.get(modeName+":let_task_term"+taskName);
//				    final int offset=Utils.getOffset(letTask);
//				    final int duration=Utils.getDuration(letTask,modePeriod);
//				    
//				    //resolve address
//				    final Instruction instruction=(Instruction)program.get(-(letTaskAdrChain.address+2));
//				    fixupFuture(instruction,letTaskAddress);
//				    letTaskAdrChain.address=letTaskAddress;
//				    
//				    new GenTaskOutput(unit,nUnits,unitPeriod,modePeriod,modeName).taskTermination(letTask);
//				    
//				    program.add(new Instruction(returnCode, "From LET task termination: "
//							+ taskName));
//				}
//				
//				// genereate future fro float task release
//				itFloatInfo=futureSets.floatTaskInfo.iterator();
//				while(itFloatInfo.hasNext()){
//				    final AFloatTaskInvocation floatTask=(AFloatTaskInvocation)itFloatInfo.next();
//				    final int floatTaskAddress=program.size();
//				    final String taskName=floatTask.getTaskName().getText();
//				    final FixupChain floatTaskAdrChain=(FixupChain)modeAddresses.get(modeName+":float_task"+taskName);
//				    
//				    //resolve address
//				    final Instruction instruction=(Instruction)program.get(-(floatTaskAdrChain.address+2));
//				    fixupFuture(instruction,floatTaskAddress);
//				    floatTaskAdrChain.address=floatTaskAddress;
//				    
//				    releaseFloatTask(floatTask,modePeriod,scheduleTime, modeName);
//				    
//				    program.add(new Instruction(returnCode, "From float task release: "
//							+ taskName));
//				}
//			}
//
//			currentModeName = null;
//		}
		
//		private long computeDependency(String task,String mode){
//		    long dependency=0;
//		    
//		    final Map modeInputDep=(Map)dependencyTable.modesInputDependencies.get(mode);
//	        final ArrayList dependencies=(ArrayList)modeInputDep.get(task);
//		    
//		    Iterator it=dependencies.iterator();
//		    
//		    while(it.hasNext()){
//		        tslc.node.Node n=(tslc.node.Node)it.next();
//		        if(n instanceof AFloatTaskInvocation){
//		            final String taskName=((AFloatTaskInvocation)n).getTaskName().getText();
//		            dependency=dependency | (1 << (functionTable.getTaskIndex(taskName)));
//		        }
//		    }
//		    
//		    return dependency;
//		}
//		
//		private void sensorUpdate(ASensorUpdate node){
//		    final String sensorPortName = node.getSensorPortName().getText();
//
//			final ASensorDeclaration sensorDeclaration = (ASensorDeclaration) symbolTable.sensorPorts
//					.get(sensorPortName);
//
//			final APortMappingAnnotation portMappingAnnotation = (APortMappingAnnotation) sensorDeclaration
//					.getPortAnnotation();
//
//			if (pureGiotto || isPortOnHost(portMappingAnnotation)) {
//				final ADeviceDriver deviceDriver = (ADeviceDriver) sensorDeclaration
//						.getDeviceDriver();
//
//				if (deviceDriver != null) {
//					final String deviceDriverName = deviceDriver
//							.getDeviceDriverName().getText();
//
//					final int driverIndex = functionTable.getDriverIndex(
//							sensorPortName, deviceDriverName);
//					
//					program.add(new Instruction(callCode, driverIndex,
//							"Call sensor device driver: "
//									+ functionTable.getDriverWrapperName(
//											sensorPortName,
//											deviceDriverName)));
//				}
//			}
//		}
//		
//		private void releaseFloatTask(AFloatTaskInvocation node, int modePeriod,int releaseTime, String modeName){
//		    final int frequency=Integer.parseInt(node.getFloatTaskFrequency().getText());
//		    final String taskName = node.getTaskName().getText();
//
//			final ATaskAnnotation taskAnnotation = (ATaskAnnotation) node
//					.getTaskAnnotation();
//
//			boolean isTaskAnnotated = false;
//
//			if (!pureGiotto && (taskAnnotation != null))
//				if (taskAnnotation.getScheduleConnectionList() != null)
//					isTaskAnnotated = true;
//
//			if (node.getDriverName() != null) {
//				final String driverName = node.getDriverName()
//						.getText();
//
//				final int conditionIndex = functionTable
//						.getConditionIndex(taskName, driverName, modeName);
//				final int driverIndex = functionTable.getDriverIndex(
//						taskName, driverName, modeName);
//
//				final int thenAddress = program.size() + 1;
//				int elseAddress = program.size() + 3;
//
//				if (isTaskAnnotated)
//					// Skip release insruction for message task
//					// generated below
//					elseAddress++;
//
//				program.add(new Instruction(ifCode, conditionIndex,
//						thenAddress, elseAddress, "If task driver: "
//								+ functionTable
//										.getConditionWrapperName(
//												taskName, driverName, modeName)));
//				program.add(new Instruction(callCode, driverIndex,
//						"Call task driver: "
//								+ functionTable.getDriverWrapperName(
//										taskName, driverName,modeName)));
//			}
//
//			int relativeDeadline = modePeriod / frequency - releaseTime;
//
//			// Task annotation
//
//			if (isTaskAnnotated) {
//				final int messageIndex = functionTable.getMessageIndex(
//						currentModeName, taskName);
//
//				final int releaseMessageTime = relativeDeadline >> 1;
//
//				program.add(new Instruction(releaseCode, messageIndex,
//						0, releaseMessageTime
//								+ (relativeDeadline << 12),
//						"Release message: "
//								+ functionTable.getMessageWrapperName(
//										currentModeName, taskName)
//								+ ", release time: "
//								+ releaseMessageTime
//								+ ", relative deadline: "
//								+ relativeDeadline));
//
//				minUnitPeriod = ModeUnit.gcd(releaseMessageTime,
//						minUnitPeriod);
//
//				relativeDeadline = releaseMessageTime;
//			}
//
//			// Release task
//
//			final int taskIndex = functionTable.getTaskIndex(taskName);
//
//			// FIXME: Trivial release time: 0, only one annotation:
//			// index 0
//			program.add(new Instruction(releaseCode, taskIndex, 0,
//					0 + (relativeDeadline << 12), "Release task: "
//							+ functionTable
//									.getTaskWrapperName(taskName)
//							+ ", release time: " + "0"
//							+ ", relative deadline: "
//							+ relativeDeadline));
//		}
	}

	// Misc code

	private class FixupChain {
		private int address = 0;

		private int unit = 0;

		private String modename = null;

		public FixupChain(int address, int unit, String modename) {
			this.address = address;
			this.unit = unit;

			this.modename = modename;
		}
	}

	private class Instruction {
		int opcode = 0;

		int arg1 = -1;

		int arg2 = -1;

		int arg3 = -1;
		
		int arg4 = -1;

		String comment = "";

		public Instruction(int opcode) {
			this.opcode = opcode;
		}

		public Instruction(int opcode, String comment) {
			this.opcode = opcode;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1) {
			this.opcode = opcode;
			this.arg1 = arg1;
		}

		public Instruction(int opcode, int arg1, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1, int arg2, String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;

			this.comment = comment;
		}

		public Instruction(int opcode, int arg1, int arg2, int arg3) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
		}

		public Instruction(int opcode, int arg1, int arg2, int arg3,
				String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;

			this.comment = comment;
		}
		
		public Instruction(int opcode, int arg1, int arg2, int arg3, int arg4,
				String comment) {
			this.opcode = opcode;
			this.arg1 = arg1;
			this.arg2 = arg2;
			this.arg3 = arg3;
			this.arg4=arg4;

			this.comment = comment;
		}

		public void emitCode(int address) {
			switch (opcode) {
			case nopCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("NOP");
				break;
			case futureCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("FUTURE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),Integer.toString(arg4),
								comment });
				break;
			case callCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("CALL", new String[] { Integer.toString(arg1), comment });
				break;
			case releaseCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RELEASE",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),
								comment });
				break;
			case ifCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("IF",
						new String[] { Integer.toString(arg1),
								Integer.toString(arg2), Integer.toString(arg3),
								comment });
				break;
			case jumpCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("JUMP", new String[] { Integer.toString(arg1), comment });
				break;
			case returnCode:
				emit("Comment", new String[] { Integer.toString(address) });
				emit("RETURN", new String[] { comment });
				break;
			}
		}
	}
}
