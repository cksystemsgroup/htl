Author: Daniel Iercan, diercan@cs.uni-salzburg.at

This is the soucre code for TSL Compiler.

Directories descriptions:
	- src directory contains the TSL compiler soucre code
	- dist directory contains the TSL comiler jar file
	- examples directory contains a few tsl program examples
	- lib directory contains sablecc jar file
	
How to build:
	- you need Ant installed on your computer (http://ant.apache.org/bindownload.cgi)
	- if you want to generate the parser, lexer ... type: ant gen_grammar
	- if you want to build the compiler (the grammar will be generated automaticaly ) type: ant build
	- if you want to run the compiler type: ant run
	- if you want to create the jar file for the compiler type: ant build_jar
	- if the project structure is as follows:
		[work_dir]/TSL_EMachine
		[work_dir]/TSLCompiler
		then you can use ant cpy_dist_jar_2_emachine to build the jar file and copy it to the emachine

How to clean:
	- clean all: ant clean_all
	- clean grammar: ant clean_grammar
	- clean generated class files: and clean

For more informations you can look at build.xml file.